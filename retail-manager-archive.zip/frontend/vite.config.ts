import { defineConfig } from "vite";
import react from "@vitejs/plugin-react-swc";
import path from "path";
import fs from "fs";
import { componentTagger } from "lovable-tagger";
import basicSsl from "@vitejs/plugin-basic-ssl";

const enableHttps = process.env.VITE_DEV_HTTPS === "true";

// https://vitejs.dev/config/
export default defineConfig(({ mode }) => {
  // Determine HTTPS configuration  
  let httpsConfig: { key: Buffer; cert: Buffer } | undefined = undefined;
  let useBasicSslPlugin = false;
  
  if (enableHttps) {
    // prefer mkcert-generated certs when available in project root
    const cert = [
      "localhost+2.pem",
      "localhost.pem",
      "dev-localhost-8080+2.pem",
      "dev-localhost-8080.pem",
    ].find((f) => fs.existsSync(f));
    const key = cert ? (cert.includes("-key") ? cert : cert.replace(/\.pem$/, "-key.pem")) : undefined;
    
    if (cert && key && fs.existsSync(cert) && fs.existsSync(key)) {
      httpsConfig = {
        key: fs.readFileSync(key),
        cert: fs.readFileSync(cert),
      };
    } else {
      // Fall back to basicSsl plugin
      useBasicSslPlugin = true;
    }
  }

  return {
    base: mode === 'production' ? './' : '/', // Important for Electron
    server: {
      host: "::",
      port: 8080,
      https: httpsConfig,
    },
    plugins: [
      react(),
      (enableHttps && useBasicSslPlugin) && basicSsl(),
      mode === "development" && componentTagger()
    ].filter(Boolean),
    resolve: {
      alias: {
        "@": path.resolve(__dirname, "./src"),
      },
    },
  };
});
