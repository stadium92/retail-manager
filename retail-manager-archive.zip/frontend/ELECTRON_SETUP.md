# Building Desktop Executables with Electron

## Quick Setup Guide

### Step 1: Install Electron Dependencies

```bash
npm install --save-dev electron electron-builder
npm install electron-is-dev
```

### Step 2: Create Electron Main Process

Create `electron/main.js`:

```javascript
const { app, BrowserWindow } = require('electron');
const path = require('path');
const isDev = require('electron-is-dev');

function createWindow() {
  const win = new BrowserWindow({
    width: 1280,
    height: 720,
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
      enableRemoteModule: false,
    },
    icon: path.join(__dirname, '../public/icon.png'), // Optional: add icon
  });

  // Load the app
  const startUrl = isDev
    ? 'http://localhost:8080'
    : `file://${path.join(__dirname, '../dist/index.html')}`;
  
  win.loadURL(startUrl);

  // Open DevTools in development
  if (isDev) {
    win.webContents.openDevTools();
  }
}

app.whenReady().then(createWindow);

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') {
    app.quit();
  }
});

app.on('activate', () => {
  if (BrowserWindow.getAllWindows().length === 0) {
    createWindow();
  }
});
```

### Step 3: Update package.json

Add these scripts and config:

```json
{
  "main": "electron/main.js",
  "scripts": {
    "electron": "electron .",
    "electron:dev": "concurrently \"npm run dev\" \"wait-on http://localhost:8080 && electron .\"",
    "electron:build": "npm run build && electron-builder",
    "electron:build:win": "npm run build && electron-builder --win"
  },
  "build": {
    "appId": "com.retailmanager.app",
    "productName": "Retail Manager",
    "directories": {
      "output": "release"
    },
    "files": [
      "dist/**/*",
      "electron/**/*",
      "node_modules/**/*"
    ],
    "win": {
      "target": [
        {
          "target": "nsis",
          "arch": ["x64", "ia32"]
        }
      ],
      "icon": "build/icon.ico"
    },
    "nsis": {
      "oneClick": false,
      "allowToChangeInstallationDirectory": true,
      "createDesktopShortcut": true,
      "createStartMenuShortcut": true
    }
  }
}
```

### Step 4: Install Additional Dev Dependencies

```bash
npm install --save-dev concurrently wait-on
```

### Step 5: Build for macOS or Windows

```bash
# Build the React app + LocalBridge backend and create installer
npm run electron:build

# Or Windows-only build
npm run electron:build:win
```

The installer will be in the `release` folder.

---

## Running LocalBridge with Electron

The Electron app auto-starts the LocalBridge backend on launch and shuts it down when the app exits.

LocalBridge runtime settings:
- `LOCALBRIDGE_PORT` (default: 8787)
- `LOCALBRIDGE_AUTOSTART=0` to disable auto-start
- `JWT_SECRET` (optional override)

LocalBridge data path:
- Uses the Electron user data directory: `~/Library/Application Support/Retail Manager/local-bridge/data` on macOS.

---

## Alternative: Tauri (Lighter, Better Performance)

Tauri creates smaller executables and uses less memory - perfect for low-end hardware.

### Tauri Setup:

```bash
npm install --save-dev @tauri-apps/cli
npm install @tauri-apps/api
```

Create `src-tauri/tauri.conf.json` and configure.

**Recommendation:** Start with Electron (easier), switch to Tauri if bundle size is an issue.
