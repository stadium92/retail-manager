import { useState, useEffect } from 'react';
import { OfflineInventoryService } from '@/services/OfflineInventoryService';
import { OfflineStoreService } from '@/services/OfflineStoreService';
import { InventoryItem, Store } from '@/types';
import { LocalBridgeSyncService } from '@/services/LocalBridgeSyncService';
import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Plus, Edit, Trash2, Package, AlertTriangle, Search, Download, FileText, FileSpreadsheet, File, ScanBarcode, WifiOff, RefreshCw } from 'lucide-react';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { ExportService } from '@/services/ExportService';
import { useTranslation } from 'react-i18next';
import { useToast } from '@/hooks/use-toast';
import { useFormatters } from '@/utils/formatting';
import { Skeleton } from '@/components/ui/skeleton';
import { Badge } from '@/components/ui/badge';
import { ImageUpload } from '@/components/shared/ImageUpload';
import { useSelection } from '@/hooks/useSelection';
import { BarcodeScanner } from '@/components/shared/BarcodeScanner';

export default function InventoryPage() {
  const { toast } = useToast();
  const { t } = useTranslation();
  const { formatCurrency } = useFormatters();
  const [items, setItems] = useState<InventoryItem[]>([]);
  const [stores, setStores] = useState<Store[]>([]);
  const [loading, setLoading] = useState(true);
  const [formOpen, setFormOpen] = useState(false);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [selectedItem, setSelectedItem] = useState<InventoryItem | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [isScanning, setIsScanning] = useState(false);
  const [isScanningForSku, setIsScanningForSku] = useState(false);
  const [selectedStoreFilter, setSelectedStoreFilter] = useState<string>('all');
  const [isOffline, setIsOffline] = useState(!navigator.onLine);
  const [syncing, setSyncing] = useState(false);
  const [serviceKey, setServiceKey] = useState('');
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    sku: '',
    price: '',
    cost: '',
    quantity: '',
    low_stock_threshold: '',
    store_id: '',
    image_url: '',
  });

  useEffect(() => {
    const handleOnline = () => setIsOffline(false);
    const handleOffline = () => setIsOffline(true);
    const handleDataUpdated = (e: CustomEvent) => {
      if (e.detail?.type === 'inventory' || e.detail?.type === 'stores') {
        loadData();
      }
    };
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    window.addEventListener('localDbDataUpdated', handleDataUpdated as EventListener);
    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
      window.removeEventListener('localDbDataUpdated', handleDataUpdated as EventListener);
    };
  }, []);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setLoading(true);
    // Use offline-first services
    const [inventoryRes, storesRes] = await Promise.all([
      OfflineInventoryService.getInventory(undefined, { notify: false }),
      OfflineStoreService.getStores({ notify: false }),
    ]);

    if (inventoryRes.error) {
      toast({
        title: t('common.error'),
        description: t('inventory.errors.loadInventory'),
        variant: 'destructive',
      });
    } else {
      setItems(inventoryRes.data || []);
    }

    if (storesRes.error) {
      toast({
        title: t('common.error'),
        description: t('inventory.errors.loadStores'),
        variant: 'destructive',
      });
    } else {
      setStores(storesRes.data || []);
    }

    setLoading(false);
  };


  const handleSyncPush = async () => {
    if (!navigator.onLine) {
      toast({
        title: t('common.offline') || 'Offline',
        description: t('common.offlineModeMessage') || 'Connexion internet requise',
        variant: 'destructive',
      });
      return;
    }
    if (!serviceKey) {
      toast({
        title: t('common.error') || 'Error',
        description: 'Clé Supabase requise',
        variant: 'destructive',
      });
      return;
    }
    setSyncing(true);
    const result = await LocalBridgeSyncService.pushPendingMutations(serviceKey);
    if (result.failed > 0) {
      toast({
        title: t('common.error') || 'Error',
        description: `Synchronisation partielle: ${result.pushed} OK, ${result.failed} échecs`,
        variant: 'destructive',
      });
    } else {
      toast({
        title: t('common.success') || 'Success',
        description: `Synchronisation terminée: ${result.pushed} opérations`,
      });
    }
    setSyncing(false);
  };

  const handleRefresh = async () => {
    if (!navigator.onLine) {
      toast({
        title: t('common.offline') || 'Offline',
        description: t('common.offlineModeMessage') || 'Cannot refresh while offline',
        variant: 'destructive',
      });
      return;
    }
    setSyncing(true);
    await loadData();
    setSyncing(false);
  };

  const handleOpenForm = (item?: InventoryItem) => {
    if (item) {
      setSelectedItem(item);
      setFormData({
        name: item.name,
        description: item.description || '',
        sku: item.sku || '',
        price: item.price.toString(),
        cost: item.cost?.toString() || '',
        quantity: item.quantity.toString(),
        low_stock_threshold: item.low_stock_threshold?.toString() || '10',
        store_id: item.store_id,
        image_url: item.image_url || '',
      });
    } else {
      setSelectedItem(null);
      setFormData({
        name: '',
        description: '',
        sku: '',
        price: '',
        cost: '',
        quantity: '',
        low_stock_threshold: '10',
        store_id: stores[0]?.id || '',
        image_url: '',
      });
    }
    setFormOpen(true);
  };

  const handleCloseForm = () => {
    setFormOpen(false);
    setSelectedItem(null);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    const data = {
      name: formData.name,
      description: formData.description || undefined,
      sku: formData.sku || undefined,
      price: parseFloat(formData.price),
      cost: formData.cost ? parseFloat(formData.cost) : undefined,
      quantity: parseInt(formData.quantity),
      low_stock_threshold: formData.low_stock_threshold
        ? parseInt(formData.low_stock_threshold)
        : undefined,
      store_id: formData.store_id,
      image_url: formData.image_url || undefined,
    };

    if (selectedItem) {
      const { error } = await OfflineInventoryService.updateItem(selectedItem.id, data);
      if (error) {
        toast({
          title: t('common.error'),
          description: t('inventory.errors.updateItem'),
          variant: 'destructive',
        });
      } else {
        // Update local state immediately
        setItems(prev => prev.map(item =>
          item.id === selectedItem.id ? { ...item, ...data, updated_at: new Date().toISOString() } : item
        ));
        toast({ title: t('common.success'), description: t('inventory.success.updateItem') });
        handleCloseForm();
      }
    } else {
      const { data: newItem, error } = await OfflineInventoryService.createItem(data);
      if (error) {
        toast({
          title: t('common.error'),
          description: t('inventory.errors.createItem'),
          variant: 'destructive',
        });
      } else {
        // Add to local state immediately
        if (newItem) {
          setItems(prev => [...prev, newItem]);
        }
        toast({ title: t('common.success'), description: t('inventory.success.createItem') });
        handleCloseForm();
      }
    }
  };

  const handleDelete = async () => {
    if (!selectedItem) return;

    const { error } = await OfflineInventoryService.deleteItem(selectedItem.id);
    if (error) {
      toast({
        title: t('common.error'),
        description: t('inventory.errors.deleteItem'),
        variant: 'destructive',
      });
    } else {
      // Update local state immediately
      setItems(prev => prev.filter(item => item.id !== selectedItem.id));
      toast({ title: t('common.success'), description: t('inventory.success.deleteItem') });
    }
    setDeleteDialogOpen(false);
    setSelectedItem(null);
  };

  const openDeleteDialog = (item: InventoryItem) => {
    setSelectedItem(item);
    setDeleteDialogOpen(true);
  };

  const filteredItems = items.filter((item) => {
    const matchesSearch = item.name.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesStore =
      selectedStoreFilter === 'all' || item.store_id === selectedStoreFilter;
    return matchesSearch && matchesStore;
  });

  const selection = useSelection(filteredItems);

  const handleBulkDelete = async () => {
    if (selection.selectedCount === 0) return;

    const deletePromises = selection.selectedItems.map(item =>
      OfflineInventoryService.deleteItem(item.id)
    );

    const results = await Promise.all(deletePromises);
    const errors = results.filter(r => r.error);

    if (errors.length > 0) {
      toast({
        title: t('common.error'),
        description: t('inventory.errors.bulkDelete', { count: errors.length }),
        variant: 'destructive',
      });
    } else {
      toast({
        title: t('common.success'),
        description: t('inventory.success.bulkDelete', { count: selection.selectedCount }),
      });
    }

    selection.clearSelection();
    loadData();
  };

  const isLowStock = (item: InventoryItem) => {
    return item.quantity <= (item.low_stock_threshold || 10);
  };

  if (loading) {
    return (
      <div className="mobile-container py-4 px-4 lg:px-6 space-y-6">
        <div>
          <Skeleton className="h-8 w-48" />
        </div>
        <Card>
          <CardHeader>
            <Skeleton className="h-6 w-32" />
          </CardHeader>
          <CardContent>
            <Skeleton className="h-64 w-full" />
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="mobile-container py-4 px-4 lg:px-6 space-y-6">
      {isOffline && (
        <div className="flex items-center gap-2 p-3 bg-amber-100 dark:bg-amber-900/30 text-amber-800 dark:text-amber-200 rounded-lg">
          <WifiOff className="h-4 w-4" />
          <span className="text-sm">{t('common.offlineMode') || 'Offline mode - showing cached data'}</span>
        </div>
      )}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">{t('inventory.title')}</h1>
          <p className="text-muted-foreground">{t('inventory.manageInventory')}</p>
        </div>
        <div className="flex gap-2">
<div className="flex flex-col gap-2">
            <Input
              type="password"
              placeholder="Clé Supabase (Service Role)"
              value={serviceKey}
              onChange={(e) => setServiceKey(e.target.value)}
            />
            <Button
              variant="outline"
              size="sm"
              onClick={handleSyncPush}
              disabled={syncing || isOffline || !serviceKey}
            >
              <RefreshCw className={`h-4 w-4 mr-2 ${syncing ? 'animate-spin' : ''}`} />
              Synchroniser les changements locaux
            </Button>
          </div>

          <Button
            variant="outline"
            size="sm"
            onClick={handleRefresh}
            disabled={syncing || isOffline}
          >
            <RefreshCw className={`h-4 w-4 mr-2 ${syncing ? 'animate-spin' : ''}`} />
            {t('common.refresh') || 'Refresh'}
          </Button>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline">
                <Download className="h-4 w-4 mr-2" />
                {t('export.title')}
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem
                onClick={() => {
                  const exportData = ExportService.formatInventoryForExport(filteredItems);
                  ExportService.exportToCSV(exportData, 'inventory');
                  toast({ title: t('export.success') });
                }}
              >
                <FileText className="h-4 w-4 mr-2" />
                {t('export.csv')}
              </DropdownMenuItem>
              <DropdownMenuItem
                onClick={() => {
                  const exportData = ExportService.formatInventoryForExport(filteredItems);
                  ExportService.exportToExcel(exportData, 'inventory', t('inventory.export.sheetName'));
                  toast({ title: t('export.success') });
                }}
              >
                <FileSpreadsheet className="h-4 w-4 mr-2" />
                {t('export.excel')}
              </DropdownMenuItem>
              <DropdownMenuItem
                onClick={() => {
                  const exportData = ExportService.formatInventoryForExport(filteredItems);
                  const columns = [
                    { header: t('inventory.export.columns.name'), dataKey: 'Name' },
                    { header: t('inventory.export.columns.sku'), dataKey: 'SKU' },
                    { header: t('inventory.export.columns.quantity'), dataKey: 'Quantity' },
                    { header: t('inventory.export.columns.price'), dataKey: 'Price' },
                    { header: t('inventory.export.columns.store'), dataKey: 'Store' },
                  ];
                  ExportService.exportToPDF(exportData, 'inventory', t('inventory.export.reportTitle'), columns);
                  toast({ title: t('export.success') });
                }}
              >
                <File className="h-4 w-4 mr-2" />
                {t('export.pdf')}
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
          <Button onClick={() => handleOpenForm()}>
            <Plus className="h-4 w-4 mr-2" />
            {t('inventory.addItem')}
          </Button>
        </div>
      </div>

      {stores.length === 0 ? (
        <Card>
          <CardContent className="py-12 text-center">
            <Package className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
            <p className="text-muted-foreground">
              {t('inventory.noStoresMessage')}
            </p>
          </CardContent>
        </Card>
      ) : (
        <>
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder={t('inventory.searchPlaceholder')}
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-9 pr-10"
              />
              <Button
                type="button"
                variant="ghost"
                size="icon"
                className="absolute right-1 top-1 h-8 w-8 text-muted-foreground hover:text-primary"
                onClick={() => setIsScanning(true)}
              >
                <ScanBarcode className="h-4 w-4" />
              </Button>
            </div>
            <Select value={selectedStoreFilter} onValueChange={setSelectedStoreFilter}>
              <SelectTrigger className="w-full sm:w-[200px]">
                <SelectValue placeholder={t('inventory.filterByStore')} />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">{t('inventory.allStores')}</SelectItem>
                {stores.map((store) => (
                  <SelectItem key={store.id} value={store.id}>
                    {store.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {selection.hasSelection && (
            <Card className="border-primary">
              <CardContent className="py-3">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium">
                    {t('inventory.itemsSelected', { count: selection.selectedCount })}
                  </span>
                  <div className="flex gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={selection.clearSelection}
                    >
                      {t('common.clear')}
                    </Button>
                    <Button
                      variant="destructive"
                      size="sm"
                      onClick={handleBulkDelete}
                    >
                      <Trash2 className="h-4 w-4 mr-2" />
                      {t('common.deleteSelected')}
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Package className="h-5 w-5" />
                {t('inventory.itemsTitle')}
              </CardTitle>
              <CardDescription>
                {t('inventory.summary', { total: filteredItems.length, lowStock: filteredItems.filter(isLowStock).length })}
              </CardDescription>
            </CardHeader>
            <CardContent>
              {filteredItems.length === 0 ? (
                <div className="text-center py-12">
                  <Package className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                  <p className="text-muted-foreground">
                    {t('inventory.emptyState')}
                  </p>
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead className="w-12">
                          <Checkbox
                            checked={selection.isAllSelected}
                            onCheckedChange={selection.toggleAll}
                          />
                        </TableHead>
                        <TableHead>{t('inventory.table.name')}</TableHead>
                        <TableHead>{t('inventory.table.store')}</TableHead>
                        <TableHead>{t('inventory.table.sku')}</TableHead>
                        <TableHead>{t('inventory.table.quantity')}</TableHead>
                        <TableHead>{t('inventory.table.price')}</TableHead>
                        <TableHead>{t('inventory.table.status')}</TableHead>
                        <TableHead className="text-right">{t('inventory.table.actions')}</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredItems.map((item) => {
                        const itemStore = stores.find(s => s.id === item.store_id);
                        return (
                          <TableRow key={item.id}>
                            <TableCell>
                              <Checkbox
                                checked={selection.isSelected(item.id)}
                                onCheckedChange={() => selection.toggleSelect(item.id)}
                              />
                            </TableCell>
                            <TableCell className="font-medium">{item.name}</TableCell>
                            <TableCell>
                              <Badge
                                variant="outline"
                                className="cursor-pointer hover:bg-accent"
                                onClick={() => window.location.href = `/master/stores/${item.store_id}`}
                              >
                                {itemStore?.name || t('common.unknown')}
                              </Badge>
                            </TableCell>
                            <TableCell>{item.sku || '-'}</TableCell>
                            <TableCell>{item.quantity}</TableCell>
                            <TableCell>{formatCurrency(Number(item.price))}</TableCell>
                            <TableCell>
                              {isLowStock(item) ? (
                                <Badge variant="destructive" className="gap-1">
                                  <AlertTriangle className="h-3 w-3" />
                                  {t('inventory.status.lowStock')}
                                </Badge>
                              ) : (
                                <Badge variant="secondary">{t('inventory.status.inStock')}</Badge>
                              )}
                            </TableCell>
                            <TableCell className="text-right space-x-2">
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => handleOpenForm(item)}
                              >
                                <Edit className="h-4 w-4" />
                              </Button>
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => openDeleteDialog(item)}
                              >
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            </TableCell>
                          </TableRow>
                        );
                      })}
                    </TableBody>
                  </Table>
                </div>
              )}
            </CardContent>
          </Card>
        </>
      )}

      {/* Form Dialog */}
      <Dialog open={formOpen} onOpenChange={setFormOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>
              {selectedItem ? t('inventory.editItem') : t('inventory.createItem')}
            </DialogTitle>
            <DialogDescription>
              {selectedItem
                ? t('inventory.editItemDescription')
                : t('inventory.createItemDescription')}
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={handleSubmit}>
            <div className="space-y-4 max-h-[60vh] overflow-y-auto px-1">
              <div className="grid grid-cols-2 gap-4">
                <div className="col-span-2">
                  <Label htmlFor="name">{t('inventory.fields.name')}</Label>
                  <Input
                    id="name"
                    value={formData.name}
                    onChange={(e) =>
                      setFormData({ ...formData, name: e.target.value })
                    }
                    required
                  />
                </div>
                <div className="col-span-2">
                  <Label>{t('inventory.fields.image')}</Label>
                  <ImageUpload
                    currentImageUrl={formData.image_url}
                    onImageUploaded={(url) =>
                      setFormData({ ...formData, image_url: url })
                    }
                    onImageRemoved={() =>
                      setFormData({ ...formData, image_url: '' })
                    }
                    folder="inventory"
                  />
                </div>
                <div className="col-span-2">
                  <Label htmlFor="description">{t('inventory.fields.description')}</Label>
                  <Textarea
                    id="description"
                    value={formData.description}
                    onChange={(e) =>
                      setFormData({ ...formData, description: e.target.value })
                    }
                  />
                </div>
                <div>
                  <Label htmlFor="sku">{t('inventory.fields.sku')}</Label>
                  <div className="flex gap-2">
                    <Input
                      id="sku"
                      value={formData.sku}
                      onChange={(e) =>
                        setFormData({ ...formData, sku: e.target.value })
                      }
                      className="flex-1"
                    />
                    <Button
                      type="button"
                      variant="outline"
                      size="icon"
                      onClick={() => setIsScanningForSku(true)}
                    >
                      <ScanBarcode className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
                <div>
                  <Label htmlFor="store">{t('inventory.fields.store')}</Label>
                  <Select
                    value={formData.store_id}
                    onValueChange={(value) =>
                      setFormData({ ...formData, store_id: value })
                    }
                    required
                  >
                    <SelectTrigger id="store">
                      <SelectValue placeholder={t('inventory.selectStore')} />
                    </SelectTrigger>
                    <SelectContent>
                      {stores.map((store) => (
                        <SelectItem key={store.id} value={store.id}>
                          {store.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="quantity">{t('inventory.fields.quantity')}</Label>
                  <Input
                    id="quantity"
                    type="number"
                    min="0"
                    value={formData.quantity}
                    onChange={(e) =>
                      setFormData({ ...formData, quantity: e.target.value })
                    }
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="low_stock">{t('inventory.fields.lowStockThreshold')}</Label>
                  <Input
                    id="low_stock"
                    type="number"
                    min="0"
                    value={formData.low_stock_threshold}
                    onChange={(e) =>
                      setFormData({
                        ...formData,
                        low_stock_threshold: e.target.value,
                      })
                    }
                  />
                </div>
                <div>
                  <Label htmlFor="price">{t('inventory.fields.price')}</Label>
                  <Input
                    id="price"
                    type="number"
                    min="0"
                    step="0.01"
                    value={formData.price}
                    onChange={(e) =>
                      setFormData({ ...formData, price: e.target.value })
                    }
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="cost">{t('inventory.fields.cost')}</Label>
                  <Input
                    id="cost"
                    type="number"
                    min="0"
                    step="0.01"
                    value={formData.cost}
                    onChange={(e) =>
                      setFormData({ ...formData, cost: e.target.value })
                    }
                  />
                </div>
              </div>
            </div>
            <DialogFooter className="mt-6">
              <Button type="button" variant="outline" onClick={handleCloseForm}>
                {t('common.cancel')}
              </Button>
              <Button type="submit">
                {selectedItem ? t('common.update') : t('common.create')}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* Barcode Scanner for Search */}
      <BarcodeScanner
        isScanning={isScanning}
        onResult={(code) => setSearchQuery(code)}
        onClose={() => setIsScanning(false)}
      />

      {/* Barcode Scanner for SKU Field */}
      <BarcodeScanner
        isScanning={isScanningForSku}
        onResult={(code) => setFormData({ ...formData, sku: code })}
        onClose={() => setIsScanningForSku(false)}
      />
    </div>
  );
}
