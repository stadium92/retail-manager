import { useState, useEffect } from 'react';
import { TeamService, TeamMember } from '@/services/TeamService';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Users, User, Download, FileText, FileSpreadsheet, File, Search, WifiOff } from 'lucide-react';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { ExportService } from '@/services/ExportService';
import { useTranslation } from 'react-i18next';
import { useToast } from '@/hooks/use-toast';
import { Skeleton } from '@/components/ui/skeleton';
import { Badge } from '@/components/ui/badge';

export default function WorkersPage() {
  const { toast } = useToast();
  const { t } = useTranslation();
  const [workers, setWorkers] = useState<TeamMember[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [isOffline, setIsOffline] = useState(!navigator.onLine);

  useEffect(() => {
    const handleOnline = () => setIsOffline(false);
    const handleOffline = () => setIsOffline(true);
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  useEffect(() => {
    loadWorkers();
  }, []);

  const loadWorkers = async () => {
    setLoading(true);
    
    // Use offline-capable TeamService
    const { data, error } = await TeamService.getWorkers();

    if (error) {
      toast({
        title: t('common.error'),
        description: t('common.failedToLoad'),
        variant: 'destructive',
      });
      setLoading(false);
      return;
    }

    setWorkers(data || []);
    setLoading(false);
  };

  const filteredWorkers = workers.filter((worker) => {
    const searchLower = searchQuery.toLowerCase();
    return (
      worker.full_name?.toLowerCase().includes(searchLower) ||
      worker.email?.toLowerCase().includes(searchLower) ||
      worker.phone?.toLowerCase().includes(searchLower)
    );
  });

  if (loading) {
    return (
      <div className="mobile-container py-4 px-4 lg:px-6 space-y-6">
        <div>
          <Skeleton className="h-8 w-48" />
        </div>
        <Card>
          <CardHeader>
            <Skeleton className="h-6 w-32" />
          </CardHeader>
          <CardContent>
            <Skeleton className="h-64 w-full" />
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="mobile-container py-4 px-4 lg:px-6 space-y-6">
      {isOffline && (
        <div className="flex items-center gap-2 p-3 bg-amber-100 dark:bg-amber-900/30 text-amber-800 dark:text-amber-200 rounded-lg">
          <WifiOff className="h-4 w-4" />
          <span className="text-sm">{t('common.offlineMode') || 'Offline mode - showing cached data'}</span>
        </div>
      )}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">{t('workers.title')}</h1>
          <p className="text-muted-foreground">{t('workers.manageWorkers')}</p>
        </div>
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="outline">
              <Download className="h-4 w-4 mr-2" />
              {t('export.title')}
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            <DropdownMenuItem
              onClick={() => {
                const exportData = ExportService.formatWorkersForExport(workers);
                ExportService.exportToCSV(exportData, 'workers');
                toast({ title: t('export.success') });
              }}
            >
              <FileText className="h-4 w-4 mr-2" />
              {t('export.csv')}
            </DropdownMenuItem>
            <DropdownMenuItem
              onClick={() => {
                const exportData = ExportService.formatWorkersForExport(workers);
                ExportService.exportToExcel(exportData, 'workers', 'Workers');
                toast({ title: t('export.success') });
              }}
            >
              <FileSpreadsheet className="h-4 w-4 mr-2" />
              {t('export.excel')}
            </DropdownMenuItem>
            <DropdownMenuItem
              onClick={() => {
                const exportData = ExportService.formatWorkersForExport(workers);
                const columns = [
                  { header: 'Name', dataKey: 'Name' },
                  { header: 'Email', dataKey: 'Email' },
                  { header: 'Phone', dataKey: 'Phone' },
                  { header: 'Sales Count', dataKey: 'Sales Count' },
                  { header: 'Revenue', dataKey: 'Total Revenue' },
                ];
                ExportService.exportToPDF(exportData, 'workers', 'Workers Report', columns);
                toast({ title: t('export.success') });
              }}
            >
              <File className="h-4 w-4 mr-2" />
              {t('export.pdf')}
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>

      <div className="relative">
        <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
        <Input
          placeholder={t('workers.searchPlaceholder')}
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="pl-9"
        />
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Users className="h-5 w-5" />
            {t('workers.allWorkers')}
          </CardTitle>
          <CardDescription>
            {t('workers.totalWorkers')}: {filteredWorkers.length} {searchQuery && t('workers.filteredFrom', { total: workers.length })}
          </CardDescription>
        </CardHeader>
        <CardContent>
          {filteredWorkers.length === 0 ? (
            <div className="text-center py-12">
              <User className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
              <p className="text-muted-foreground">
                {searchQuery ? t('workers.noWorkersMatch') : t('workers.noWorkersFound')}
              </p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>{t('workers.name')}</TableHead>
                    <TableHead>{t('workers.store')}</TableHead>
                    <TableHead>{t('workers.email')}</TableHead>
                    <TableHead>{t('workers.phone')}</TableHead>
                    <TableHead>{t('workers.salesCount')}</TableHead>
                    <TableHead>{t('workers.totalRevenue')}</TableHead>
                    <TableHead>{t('workers.status')}</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredWorkers.map((worker) => (
                    <TableRow key={worker.id}>
                      <TableCell className="font-medium">
                        {worker.full_name || 'N/A'}
                      </TableCell>
                      <TableCell>
                        {worker.store_id ? (
                          <Badge 
                            variant="outline"
                            className="cursor-pointer hover:bg-accent"
                            onClick={() => window.location.href = `/master/stores/${worker.store_id}`}
                          >
                            {worker.store_name || t('workers.store')}
                          </Badge>
                        ) : (
                          <span className="text-muted-foreground">-</span>
                        )}
                      </TableCell>
                      <TableCell>{worker.email || '-'}</TableCell>
                      <TableCell>{worker.phone || '-'}</TableCell>
                      <TableCell>{worker.sales_count || 0}</TableCell>
                      <TableCell>
                        <Badge variant="secondary">
                          ${(worker.total_revenue || 0).toFixed(2)}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <Badge variant={worker.is_active ? 'default' : 'secondary'}>
                          {worker.is_active ? 'Active' : 'Inactive'}
                        </Badge>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}