import { useRef, useEffect } from "react";
import { cn } from "@/lib/utils";
import { CartItem } from "@/stores/usePOSStore";
import { Input } from "@/components/ui/input";

interface POSGridProps {
    items: CartItem[];
    activeRow: number;
    onRowClick: (index: number) => void;
    onUpdateQuantity: (index: number, qty: number) => void;
}

export function POSGrid({ items, activeRow, onRowClick, onUpdateQuantity }: POSGridProps) {
    const activeRef = useRef<HTMLTableRowElement>(null);

    // Auto-scroll to active row
    useEffect(() => {
        if (activeRef.current) {
            activeRef.current.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
        }
    }, [activeRow]);

    if (items.length === 0) {
        return (
            <div className="flex-1 flex items-center justify-center text-muted-foreground">
                <div className="text-center">
                    <h3 className="text-xl font-semibold">Prêt à Scanner</h3>
                    <p>Scannez un produit ou utilisez la Recherche (Cmd+K).</p>
                </div>
            </div>
        );
    }

    return (
        <div className="flex-1 overflow-auto">
            <table className="w-full text-sm">
                <thead className="bg-muted/50 sticky top-0 z-10 text-xs uppercase font-medium text-muted-foreground">
                    <tr>
                        <th className="px-4 py-3 text-left w-[40%]">Désignation</th>
                        <th className="px-4 py-3 text-right">Prix</th>
                        <th className="px-4 py-3 text-center w-[120px]">Qté</th>
                        <th className="px-4 py-3 text-right">Total</th>
                    </tr>
                </thead>
                <tbody className="divide-y">
                    {items.map((item, idx) => {
                        const isActive = idx === activeRow;
                        return (
                            <tr
                                key={`${item.product.id}-${idx}`}
                                ref={isActive ? activeRef : null}
                                className={cn(
                                    "cursor-pointer hover:bg-muted/30 transition-colors",
                                    isActive && "bg-accent text-accent-foreground hover:bg-accent"
                                )}
                                onClick={() => onRowClick(idx)}
                            >
                                <td className="px-4 py-2 font-medium">
                                    <div className="flex flex-col">
                                        <span>{item.product.name}</span>
                                        <span className="text-xs text-muted-foreground opacity-70">
                                            {item.product.sku}
                                        </span>
                                    </div>
                                </td>
                                <td className="px-4 py-2 text-right tabular-nums">
                                    {item.product.unit_price.toLocaleString()}
                                </td>
                                <td className="px-4 py-1 text-center" onClick={(e) => e.stopPropagation()}>
                                    <Input
                                        type="number"
                                        className={cn(
                                            "h-8 w-20 text-center mx-auto",
                                            isActive ? "bg-background text-foreground" : "bg-transparent border-transparent hover:border-input"
                                        )}
                                        value={item.quantity}
                                        onChange={(e) => onUpdateQuantity(idx, parseInt(e.target.value) || 0)}
                                        onFocus={() => onRowClick(idx)}
                                    />
                                </td>
                                <td className="px-4 py-2 text-right font-bold tabular-nums">
                                    {item.total.toLocaleString()}
                                </td>
                            </tr>
                        );
                    })}
                </tbody>
            </table>
        </div>
    );
}
