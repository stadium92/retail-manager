import { useState } from "react";
import { format } from "date-fns";
import {
    Dialog,
    DialogContent,
    DialogHeader,
    DialogTitle,
    DialogFooter,
    DialogDescription
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Check, Printer, FileText, CreditCard, Banknote } from "lucide-react";
import { usePOSStore } from "@/stores/usePOSStore";

interface CheckoutModalProps {
    open: boolean;
    onOpenChange: (open: boolean) => void;
    onConfirm: (data: CheckoutData) => Promise<void>;
    isLoading?: boolean;
}

export interface CheckoutData {
    paymentMethod: 'cash' | 'card' | 'credit';
    saleType: 'detail' | 'gros' | 'proforma';
    customerName?: string;
    customerPhone?: string;
    amountData: {
        total: number;
        received: number;
        change: number;
    };
}

export function CheckoutModal({ open, onOpenChange, onConfirm, isLoading }: CheckoutModalProps) {
    const { getTotal } = usePOSStore();
    const total = getTotal();

    const [saleType, setSaleType] = useState<'detail' | 'gros' | 'proforma'>('detail');
    const [paymentMethod, setPaymentMethod] = useState<'cash' | 'card' | 'credit'>('cash');
    const [receivedAmount, setReceivedAmount] = useState<string>('');
    const [customerName, setCustomerName] = useState('');
    const [customerPhone, setCustomerPhone] = useState('');

    const received = parseFloat(receivedAmount) || 0;
    const change = Math.max(0, received - total);

    const handleConfirm = () => {
        onConfirm({
            paymentMethod,
            saleType,
            customerName,
            customerPhone,
            amountData: {
                total,
                received,
                change
            }
        });
    };

    const isProforma = saleType === 'proforma';

    return (
        <Dialog open={open} onOpenChange={onOpenChange}>
            <DialogContent className="sm:max-w-[500px]">
                <DialogHeader>
                    <DialogTitle className="text-2xl font-bold flex items-center gap-2">
                        {isProforma ? <FileText className="w-6 h-6 text-amber-500" /> : <Check className="w-6 h-6 text-green-500" />}
                        {isProforma ? "Créer Proforma" : "Finaliser la Vente"}
                    </DialogTitle>
                    <DialogDescription>
                        Montant Total : <span className="font-bold text-primary text-lg">{total.toLocaleString()} FCFA</span>
                    </DialogDescription>
                </DialogHeader>

                <div className="grid gap-4 py-4">

                    {/* Sale Type Selection */}
                    <div className="space-y-2">
                        <Label>Type de Vente</Label>
                        <div className="flex gap-2 p-1 bg-muted rounded-lg">
                            <Button
                                variant={saleType === 'detail' ? 'default' : 'ghost'}
                                className="flex-1 h-8 text-xs"
                                onClick={() => setSaleType('detail')}
                            >
                                Détail
                            </Button>
                            <Button
                                variant={saleType === 'gros' ? 'default' : 'ghost'}
                                className="flex-1 h-8 text-xs"
                                onClick={() => setSaleType('gros')}
                            >
                                Gros
                            </Button>
                            <Button
                                variant={saleType === 'proforma' ? 'secondary' : 'ghost'}
                                className={`flex-1 h-8 text-xs ${saleType === 'proforma' ? 'bg-amber-100 text-amber-900 font-bold' : ''}`}
                                onClick={() => setSaleType('proforma')}
                            >
                                Proforma
                            </Button>
                        </div>
                    </div>

                    {!isProforma && (
                        <div className="space-y-2">
                            <Label>Mode de Paiement</Label>
                            <Tabs value={paymentMethod} onValueChange={(v) => setPaymentMethod(v as any)} className="w-full">
                                <TabsList className="grid w-full grid-cols-3">
                                    <TabsTrigger value="cash"><Banknote className="w-4 h-4 mr-2" />Espèces</TabsTrigger>
                                    <TabsTrigger value="card"><CreditCard className="w-4 h-4 mr-2" />Carte</TabsTrigger>
                                    <TabsTrigger value="credit">Crédit</TabsTrigger>
                                </TabsList>
                            </Tabs>
                        </div>
                    )}

                    {/* Customer Details (Optional for Retail, Recommended for Proforma) */}
                    <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-2">
                            <Label htmlFor="customer">Nom Client</Label>
                            <Input
                                id="customer"
                                placeholder="Optionnel"
                                value={customerName}
                                onChange={(e) => setCustomerName(e.target.value)}
                            />
                        </div>
                        <div className="space-y-2">
                            <Label htmlFor="phone">Téléphone</Label>
                            <Input
                                id="phone"
                                placeholder="Optionnel"
                                value={customerPhone}
                                onChange={(e) => setCustomerPhone(e.target.value)}
                            />
                        </div>
                    </div>

                    {/* Cash Calculation (Only for Cash Payment) */}
                    {paymentMethod === 'cash' && !isProforma && (
                        <div className="bg-muted/50 p-4 rounded-md space-y-4 border">
                            <div className="space-y-2">
                                <Label>Montant Reçu</Label>
                                <div className="relative">
                                    <Input
                                        type="number"
                                        className="pl-8 text-lg font-bold"
                                        placeholder="0"
                                        value={receivedAmount}
                                        onChange={(e) => setReceivedAmount(e.target.value)}
                                        autoFocus
                                    />
                                    <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground">$</span>
                                </div>
                            </div>

                            <div className="flex justify-between items-center pt-2 border-t">
                                <span className="font-medium">Monnaie à Rendre :</span>
                                <span className={`text-xl font-bold ${change < 0 ? "text-destructive" : "text-green-600"}`}>
                                    {change.toLocaleString()} FCFA
                                </span>
                            </div>
                        </div>
                    )}
                </div>

                <DialogFooter className="gap-2 sm:gap-0">
                    <Button variant="outline" onClick={() => onOpenChange(false)}>Annuler</Button>
                    <Button
                        onClick={handleConfirm}
                        disabled={isLoading || (paymentMethod === 'cash' && !isProforma && received < total)}
                        className={isProforma ? "bg-amber-600 hover:bg-amber-700 text-white" : ""}
                    >
                        {isLoading ? "Traitement..." : isProforma ? "Générer Proforma" : "Confirmer Vente"}
                    </Button>
                </DialogFooter>
            </DialogContent>
        </Dialog>
    );
}
