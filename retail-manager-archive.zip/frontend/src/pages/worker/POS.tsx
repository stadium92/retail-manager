import { useEffect, useState } from 'react';
import { usePOSStore } from '@/stores/usePOSStore';
import { useBarcodeScanner } from '@/hooks/useBarcodeScanner';
import { POSLayout } from './components/POSLayout';
import { POSGrid } from './components/POSGrid';
import { ProductInfoPanel } from './components/ProductInfoPanel';
import { OfflineSalesService } from '@/services/OfflineSalesService';
import { useToast } from '@/hooks/use-toast';
import { Product } from '@/types';
import { supabase } from '@/integrations/supabase/client';
import { CheckoutModal } from './components/CheckoutModal';
import { Button } from '@/components/ui/button';
import { getDataClient } from '@/lib/dataClient';
import { OfflineAuthService } from '@/services/OfflineAuthService';

export default function POSPage() {
    const {
        cart,
        activeRow,
        addItem,
        setActiveRow,
        updateQuantity,
        removeItem
    } = usePOSStore();

    const { toast } = useToast();
    const [products, setProducts] = useState<Product[]>([]);
    const [isLoading, setIsLoading] = useState(true);
    const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);
    const [isProcessing, setIsProcessing] = useState(false);

    const { isLocalFirst, localBridgeBaseUrl } = getDataClient();
    const useLocalBridge = isLocalFirst;

    // Load products for lookup from products table
    useEffect(() => {
        const loadProducts = async () => {
            if (useLocalBridge) {
                const headers = await OfflineAuthService.getAuthHeaders();
                if (!headers) {
                    setIsLoading(false);
                    return;
                }
                const response = await fetch(`${localBridgeBaseUrl}/rest/v1/products`, { headers });
                const payload = await response.json().catch(() => []);
                if (response.ok && payload) {
                    const mappedProducts: Product[] = (payload || []).map((item: any) => ({
                        id: item.id,
                        store_id: item.store_id,
                        name: item.name,
                        description: item.description,
                        sku: item.sku,
                        barcode: item.barcode,
                        unit_price: Number(item.unit_price) || 0,
                        cost_price: Number(item.cost_price) || 0,
                        quantity: item.quantity,
                        min_quantity: item.min_quantity,
                        image_url: item.image_url,
                        created_at: item.created_at,
                        updated_at: item.updated_at,
                    }));
                    setProducts(mappedProducts);
                }
                setIsLoading(false);
                return;
            }

            const { data } = await supabase
                .from('products')
                .select('*');

            if (data) {
                // Map products to Product interface
                const mappedProducts: Product[] = data.map(item => ({
                    id: item.id,
                    store_id: item.store_id,
                    name: item.name,
                    description: item.description,
                    sku: item.sku,
                    unit_price: Number(item.unit_price) || 0,
                    cost_price: Number(item.cost_price) || 0,
                    quantity: item.quantity,
                    min_quantity: item.min_quantity,
                    image_url: item.image_url,
                    created_at: item.created_at,
                    updated_at: item.updated_at,
                }));
                setProducts(mappedProducts);
            }
            setIsLoading(false);
        };
        loadProducts();
    }, [localBridgeBaseUrl, useLocalBridge]);

    // Handle Barcode Scan
    useBarcodeScanner({
        onScan: (code) => {
            const product = products.find(p => p.barcode === code || p.sku === code);
            if (product) {
                addItem(product);
                toast({
                    title: "Item Added",
                    description: `${product.name}`,
                    duration: 1000,
                });
            } else {
                toast({
                    variant: "destructive",
                    title: "Product Not Found",
                    description: `Barcode: ${code}`,
                });
            }
        }
    });

    // Handle Keyboard Navigation
    useEffect(() => {
        const handleKeyDown = (e: KeyboardEvent) => {
            // F2 to Checkout
            if (e.key === 'F2') {
                e.preventDefault();
                if (cart.length > 0) setIsCheckoutOpen(true);
                return;
            }

            // Grid Navigation
            if (!isCheckoutOpen && cart.length > 0) {
                if (e.key === 'ArrowDown') {
                    e.preventDefault();
                    setActiveRow(Math.min(activeRow + 1, cart.length - 1));
                } else if (e.key === 'ArrowUp') {
                    e.preventDefault();
                    setActiveRow(Math.max(activeRow - 1, 0));
                } else if (e.key === 'Delete' || (e.key === 'Backspace' && e.metaKey)) {
                    if (activeRow >= 0) removeItem(activeRow);
                }
            }
        };

        window.addEventListener('keydown', handleKeyDown);
        return () => window.removeEventListener('keydown', handleKeyDown);
    }, [cart.length, activeRow, setActiveRow, removeItem, isCheckoutOpen]);

    const handleCheckout = async (data: {
        amountData: { total: number };
        paymentMethod: 'cash' | 'card' | 'mobile' | 'credit';
        saleType: 'detail' | 'gros' | 'proforma';
        customerName?: string;
        customerPhone?: string;
    }) => {
        // Map 'mobile' to 'cash' for DB compatibility
        const dbPaymentMethod = data.paymentMethod === 'mobile' ? 'cash' : data.paymentMethod;
        setIsProcessing(true);
        try {
            const { data: { user } } = await supabase.auth.getUser();
            const storeId = user?.user_metadata?.store_id;
            if (!storeId) {
                toast({ variant: "destructive", title: "Error", description: "Worker not assigned to a store." });
                return;
            }

            const { error } = await OfflineSalesService.createSale({
                store_id: storeId,
                worker_id: user?.id || '',
                items: cart,
                total_price: data.amountData.total,
                payment_method: dbPaymentMethod,
                sale_type: data.saleType,
                customer_name: data.customerName,
                customer_phone: data.customerPhone
            });

            if (error) throw error;

            toast({
                title: data.saleType === 'proforma' ? "Proforma Created" : "Sale Completed",
                description: `Total: ${data.amountData.total.toLocaleString()} FCFA`,
            });

            usePOSStore.getState().clearCart();
            setIsCheckoutOpen(false);

        } catch (err) {
            console.error(err);
            toast({ variant: "destructive", title: "Checkout Failed", description: "Could not save sale." });
        } finally {
            setIsProcessing(false);
        }
    };

    return (
        <POSLayout>
            <div className="grid grid-cols-12 h-full gap-4 p-4">
                {/* Main POS Grid - 8 Cols */}
                <div className="col-span-8 bg-card rounded-lg border shadow-sm flex flex-col overflow-hidden">
                    <POSGrid
                        items={cart}
                        activeRow={activeRow}
                        onRowClick={setActiveRow}
                        onUpdateQuantity={updateQuantity}
                    />
                </div>

                {/* Right Sidebar - 4 Cols */}
                <div className="col-span-4 flex flex-col gap-4">
                    <ProductInfoPanel
                        product={activeRow >= 0 ? cart[activeRow]?.product : undefined}
                    />

                    {/* Cart Stats / Checkout Actions */}
                    <div className="bg-card rounded-lg border p-4 shadow-sm flex-1 flex flex-col justify-between">
                        <div>
                            <h3 className="font-bold text-lg mb-4">Cart Summary</h3>
                            <div className="flex justify-between text-2xl font-bold mt-4">
                                <span>Total</span>
                                <span>{usePOSStore.getState().getTotal().toLocaleString()} FCFA</span>
                            </div>
                            <p className="text-xs text-muted-foreground mt-2">
                                {cart.reduce((acc, item) => acc + item.quantity, 0)} items in cart
                            </p>
                        </div>

                        <div className="grid gap-2">
                            <Button
                                size="lg"
                                className="w-full text-lg h-12"
                                onClick={() => setIsCheckoutOpen(true)}
                                disabled={cart.length === 0}
                            >
                                Pay / Finalize (F2)
                            </Button>
                            <Button
                                variant="outline"
                                onClick={() => usePOSStore.getState().clearCart()}
                                disabled={cart.length === 0}
                            >
                                Clear Cart
                            </Button>
                        </div>
                    </div>
                </div>
            </div>

            <CheckoutModal
                open={isCheckoutOpen}
                onOpenChange={setIsCheckoutOpen}
                onConfirm={handleCheckout}
                isLoading={isProcessing}
            />
        </POSLayout>
    );
}
