import { useState, useEffect, useCallback } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { usePOSStore, CartItem } from '@/stores/usePOSStore';
import { POSGrid } from '@/components/pos/POSGrid';
import { POSCommandBar } from '@/components/pos/POSCommandBar';
import { POSSidebar } from '@/components/pos/POSSidebar';
import { POSTotals } from '@/components/pos/POSTotals';
import { BarcodeScanner } from '@/components/shared/BarcodeScanner';
import { InventoryItem } from '@/types';
import { supabase } from '@/integrations/supabase/client';
import { SalesService } from '@/services/SalesService';
import { toast } from '@/hooks/use-toast';
import { Button } from '@/components/ui/button';
import { LogOut, Zap } from 'lucide-react';
import { getDataClient } from '@/lib/dataClient';
import { OfflineAuthService } from '@/services/OfflineAuthService';

export default function StrategicPOS() {
  const { user } = useAuth();
  const { 
    cart, 
    setCommandOpen, 
    addToCart, 
    clearCart,
    completeTransaction,
    setPaymentModalOpen,
  } = usePOSStore();
  
  const [products, setProducts] = useState<InventoryItem[]>([]);
  const [storeId, setStoreId] = useState<string>('');
  const [isLoading, setIsLoading] = useState(true);
  const [isScanning, setIsScanning] = useState(false);
  const [selectedItem, setSelectedItem] = useState<CartItem | null>(null);
  const { isLocalFirst, localBridgeBaseUrl } = getDataClient();
  const useLocalBridge = isLocalFirst;

  // Fetch worker's store
  useEffect(() => {
    const fetchStore = async () => {
      if (!user) return;
      if (useLocalBridge) {
        const storeId = user.user_metadata?.store_id;
        if (storeId) setStoreId(storeId);
        return;
      }
      const { data } = await supabase
        .from('user_roles')
        .select('store_id')
        .eq('user_id', user.id)
        .in('role', ['worker', 'master'])
        .single();
      if (data?.store_id) setStoreId(data.store_id);
    };
    fetchStore();
  }, [user, useLocalBridge]);

  // Fetch products from products table
  useEffect(() => {
    const fetchProducts = async () => {
      if (!storeId) return;
      setIsLoading(true);
      if (useLocalBridge) {
        const headers = await OfflineAuthService.getAuthHeaders();
        if (!headers) {
          setIsLoading(false);
          return;
        }
        const params = new URLSearchParams({ store_id: storeId });
        const response = await fetch(`${localBridgeBaseUrl}/rest/v1/products?${params.toString()}`, { headers });
        const payload = await response.json().catch(() => []);
        if (response.ok && payload) {
          const mappedProducts: InventoryItem[] = (payload || []).map((item: any) => ({
            id: item.id,
            name: item.name,
            description: item.description || undefined,
            sku: item.sku || undefined,
            price: Number(item.unit_price) || 0,
            cost: Number(item.cost_price) || 0,
            quantity: item.quantity,
            low_stock_threshold: item.min_quantity || undefined,
            category_id: item.category || undefined,
            store_id: item.store_id,
            image_url: item.image_url || undefined,
            created_at: item.created_at,
            updated_at: item.updated_at,
          }));
          setProducts(mappedProducts);
        }
        setIsLoading(false);
        return;
      }
      const { data } = await supabase
        .from('products')
        .select('*')
        .eq('store_id', storeId)
        .order('name');
      // Map products to InventoryItem format for compatibility
      if (data) {
        const mappedProducts: InventoryItem[] = data.map(item => ({
          id: item.id,
          name: item.name,
          description: item.description || undefined,
          sku: item.sku || undefined,
          price: Number(item.unit_price) || 0,
          cost: Number(item.cost_price) || 0,
          quantity: item.quantity,
          low_stock_threshold: item.min_quantity || undefined,
          category_id: item.category || undefined,
          store_id: item.store_id,
          image_url: item.image_url || undefined,
          created_at: item.created_at,
          updated_at: item.updated_at,
        }));
        setProducts(mappedProducts);
      }
      setIsLoading(false);
    };
    fetchProducts();
  }, [storeId, localBridgeBaseUrl, useLocalBridge]);

  const handlePayment = useCallback(async () => {
    const transaction = completeTransaction('cash');
    if (!transaction) return;

    // Create sale with items using the new schema
    const saleData = {
      store_id: storeId,
      worker_id: user?.id,
      customer_name: transaction.customerName,
      customer_phone: transaction.customerPhone,
      sale_type: 'detail' as const,
      total_price: transaction.grandTotal,
      payment_method: 'cash',
      payment_status: 'paid' as const,
    };

    const saleItems = transaction.items.map(item => ({
      product_id: item.product.id,
      product_name: item.product.name,
      quantity: item.quantity,
      unit_price: item.unitPrice,
      total: item.lineTotal,
    }));

    const { error } = await SalesService.createSaleWithItems(saleData, saleItems);
    
    if (error) {
      toast({ title: 'Erreur', description: 'Échec de l\'enregistrement', variant: 'destructive' });
      return;
    }
    
    toast({ title: 'Vente enregistrée', description: `Total: ${transaction.grandTotal} XAF` });
  }, [completeTransaction, storeId, user?.id, toast]);

  // Keyboard shortcuts
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'F2') {
        e.preventDefault();
        setIsScanning(true);
      } else if (e.key === 'F4') {
        e.preventDefault();
        if (cart.length > 0) handlePayment();
      } else if (e.key === 'Escape') {
        setIsScanning(false);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [cart.length, handlePayment]);

  const handleScanResult = useCallback((result: string) => {
    const product = products.find(p => p.sku?.toLowerCase() === result.toLowerCase());
    if (product) {
      addToCart(product);
      toast({ title: 'Produit ajouté', description: product.name });
    } else {
      toast({ title: 'Produit non trouvé', description: `SKU: ${result}`, variant: 'destructive' });
    }
    setIsScanning(false);
  }, [products, addToCart]);

  

  const handleLogout = async () => {
    await supabase.auth.signOut();
  };

  return (
    <div className="h-screen flex flex-col bg-background bg-grid overflow-hidden">
      {/* Header */}
      <header className="h-14 px-4 flex items-center justify-between border-b border-border/50 glass-card rounded-none">
        <div className="flex items-center gap-3">
          <Zap className="h-6 w-6 text-primary" />
          <h1 className="text-xl font-bold">Strategic POS</h1>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-sm text-muted-foreground">{user?.email}</span>
          <Button variant="ghost" size="icon" onClick={handleLogout}>
            <LogOut className="h-4 w-4" />
          </Button>
        </div>
      </header>

      {/* Main Content */}
      <div className="flex-1 flex gap-4 p-4 overflow-hidden">
        {/* Left: Grid + Totals */}
        <div className="flex-1 flex flex-col gap-4 min-w-0">
          <POSGrid onRowSelect={setSelectedItem} />
          <POSTotals 
            onPayment={handlePayment} 
            onScan={() => setIsScanning(true)} 
            onClear={clearCart}
          />
        </div>

        {/* Right: Sidebar */}
        <POSSidebar selectedItem={selectedItem} className="w-72 shrink-0" />
      </div>

      {/* Command Bar */}
      <POSCommandBar products={products} isLoading={isLoading} />
      
      {/* Barcode Scanner */}
      <BarcodeScanner 
        isScanning={isScanning} 
        onResult={handleScanResult} 
        onClose={() => setIsScanning(false)} 
      />
    </div>
  );
}
