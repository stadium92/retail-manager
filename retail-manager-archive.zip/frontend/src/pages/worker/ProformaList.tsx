import { useEffect, useState, useRef } from "react";
import { OfflineSalesService } from "@/services/OfflineSalesService";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { POSLayout } from "./components/POSLayout";
import {
    Table,
    TableBody,
    TableCell,
    TableHead,
    TableHeader,
    TableRow
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { FileText, Printer, ShoppingCart } from "lucide-react";
import { format } from "date-fns";
import { usePOSStore } from "@/stores/usePOSStore";
import { useNavigate } from "react-router-dom";
import { useReactToPrint } from "react-to-print";
import { InvoiceTemplate, InvoiceData } from "@/components/printing/InvoiceTemplate";

export default function ProformaList() {
    const [proformas, setProformas] = useState<any[]>([]);
    const [isLoading, setIsLoading] = useState(true);
    const { toast } = useToast();
    const navigate = useNavigate();
    const { addItem, clearCart, setCustomer } = usePOSStore();

    // Print Ref & State
    const printRef = useRef<HTMLDivElement>(null);
    const [selectedInvoice, setSelectedInvoice] = useState<InvoiceData | null>(null);

    // Setup Print Handler
    const handlePrint = useReactToPrint({
        contentRef: printRef,
    });

    const loadProformas = async () => {
        setIsLoading(true);
        try {
            const { data: { user } } = await supabase.auth.getUser();
            if (!user?.user_metadata?.store_id) return;

            const data = await OfflineSalesService.getProformas(user.user_metadata.store_id);
            setProformas(data);
        } catch (error) {
            console.error(error);
            toast({ variant: "destructive", title: "Erreur", description: "Échec du chargement des proformas" });
        } finally {
            setIsLoading(false);
        }
    };

    useEffect(() => {
        loadProformas();
    }, []);

    const handleConvertToSale = (proforma: any) => {
        // 1. Clear current cart
        clearCart();

        // 2. Add items
        if (proforma.items && Array.isArray(proforma.items)) {
            proforma.items.forEach((item: any) => {
                if (item.product) {
                    addItem(item.product, item.quantity);
                }
            });
        }

        // 3. Set Customer
        if (proforma.customer_name) {
            usePOSStore.setState({ customerId: proforma.customer_name });
        }

        toast({ title: "Proforma Chargé", description: "Articles ajoutés au panier. Prêt pour l'encaissement." });
        navigate('/worker/pos');
    };

    const onPrintClick = (proforma: any) => {
        const invoiceData: InvoiceData = {
            id: proforma.id,
            storeName: "Magasin principal", // Should ideally be dynamic
            workerName: "Vendeur", // Should ideally be user name
            customerName: proforma.customer_name,
            customerPhone: proforma.customer_phone,
            created_at: proforma.created_at,
            items: proforma.items,
            total_price: proforma.total_price,
            type: 'proforma'
        };
        setSelectedInvoice(invoiceData);

        setTimeout(() => {
            handlePrint();
        }, 100);
    };

    return (
        <POSLayout>
            <div className="p-8 max-w-6xl mx-auto">
                <div className="flex justify-between items-center mb-6">
                    <h1 className="text-2xl font-bold flex items-center gap-2">
                        <FileText className="w-8 h-8 text-amber-500" />
                        Factures Proforma
                    </h1>
                    <Button onClick={loadProformas} variant="outline">Actualiser</Button>
                </div>

                <div className="bg-card rounded-lg border shadow-sm">
                    <Table>
                        <TableHeader>
                            <TableRow>
                                <TableHead>Date</TableHead>
                                <TableHead>Client</TableHead>
                                <TableHead>Articles</TableHead>
                                <TableHead className="text-right">Total</TableHead>
                                <TableHead className="text-right">Actions</TableHead>
                            </TableRow>
                        </TableHeader>
                        <TableBody>
                            {proformas.length === 0 ? (
                                <TableRow>
                                    <TableCell colSpan={5} className="text-center h-24 text-muted-foreground">
                                        Aucune facture proforma trouvée.
                                    </TableCell>
                                </TableRow>
                            ) : (
                                proformas.map((p) => (
                                    <TableRow key={p.id}>
                                        <TableCell>{format(new Date(p.created_at), 'dd/MM/yyyy HH:mm')}</TableCell>
                                        <TableCell className="font-medium">{p.customer_name || 'Anonyme'}</TableCell>
                                        <TableCell>{p.items?.length || 0} articles</TableCell>
                                        <TableCell className="text-right font-bold">{p.total_price?.toLocaleString()} FCFA</TableCell>
                                        <TableCell className="text-right">
                                            <div className="flex justify-end gap-2">
                                                <Button size="sm" variant="outline" onClick={() => onPrintClick(p)}>
                                                    <Printer className="w-4 h-4 mr-1" /> Imprimer
                                                </Button>
                                                <Button size="sm" onClick={() => handleConvertToSale(p)}>
                                                    <ShoppingCart className="w-4 h-4 mr-1" /> Convertir
                                                </Button>
                                            </div>
                                        </TableCell>
                                    </TableRow>
                                ))
                            )}
                        </TableBody>
                    </Table>
                </div>
            </div>

            {/* Hidden Print Template */}
            <div style={{ display: "none" }}>
                {selectedInvoice && <InvoiceTemplate ref={printRef} data={selectedInvoice} />}
            </div>
        </POSLayout>
    );
}
