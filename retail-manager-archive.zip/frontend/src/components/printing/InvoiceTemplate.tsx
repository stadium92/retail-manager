import React, { forwardRef } from 'react';
import { format } from "date-fns";
import { CartItem } from '@/stores/usePOSStore';

export interface InvoiceData {
    id: string;
    storeName: string;
    storeAddress?: string;
    workerName: string;
    customerName?: string;
    customerPhone?: string;
    created_at: string;
    items: CartItem[];
    total_price: number;
    type: 'detail' | 'gros' | 'proforma';
}

export const InvoiceTemplate = forwardRef<HTMLDivElement, { data: InvoiceData }>(({ data }, ref) => {
    const isProforma = data.type === 'proforma';

    return (
        <div ref={ref} className="p-8 max-w-[800px] mx-auto bg-white text-black font-sans hidden print:block">
            {/* Header */}
            <div className="flex justify-between items-start border-b pb-4 mb-4">
                <div>
                    <h1 className="text-2xl font-bold uppercase tracking-wider">{data.storeName}</h1>
                    <p className="text-sm text-gray-600">{data.storeAddress || "Magasin Retail"}</p>
                    <p className="text-sm text-gray-600">Tel: +223 00 00 00 00</p>
                </div>
                <div className="text-right">
                    <h2 className="text-xl font-bold text-gray-800 uppercase">
                        {isProforma ? "FACTURE PROFORMA" : "TICKET DE CAISSE"}
                    </h2>
                    <p className="text-sm text-gray-500">#{data.id.slice(0, 8)}</p>
                    <p className="text-sm mt-1">{format(new Date(data.created_at), 'dd/MM/yyyy HH:mm')}</p>
                </div>
            </div>

            {/* Bill To */}
            <div className="mb-6">
                <h3 className="text-xs uppercase font-bold text-gray-500 mb-1">FACTURÉ À:</h3>
                <p className="font-bold">{data.customerName || "Client Comptoir"}</p>
                {data.customerPhone && <p className="text-sm">{data.customerPhone}</p>}
            </div>

            {/* Items Table */}
            <table className="w-full text-sm mb-6">
                <thead>
                    <tr className="border-b-2 border-black">
                        <th className="text-left py-2">Désignation</th>
                        <th className="text-right py-2">Prix U.</th>
                        <th className="text-center py-2">Qté</th>
                        <th className="text-right py-2">Total</th>
                    </tr>
                </thead>
                <tbody>
                    {data.items.map((item, idx) => (
                        <tr key={idx} className="border-b border-gray-100">
                            <td className="py-2">
                                <span className="font-medium block">{item.product.name}</span>
                                <span className="text-xs text-gray-500">{item.product.sku}</span>
                            </td>
                            <td className="text-right py-2">{item.product.unit_price.toLocaleString()}</td>
                            <td className="text-center py-2">{item.quantity}</td>
                            <td className="text-right py-2">{item.total.toLocaleString()}</td>
                        </tr>
                    ))}
                </tbody>
            </table>

            {/* Totals */}
            <div className="flex justify-end mb-8">
                <div className="w-48">
                    <div className="flex justify-between py-1 border-t border-black mt-2 font-bold text-lg">
                        <span>Total</span>
                        <span>{data.total_price.toLocaleString()} FCFA</span>
                    </div>
                </div>
            </div>

            {/* Footer / Disclaimer */}
            <div className="text-center text-xs text-gray-500 mt-12 border-t pt-4">
                {isProforma ? (
                    <p className="italic font-medium text-black">
                        ** Ce document est une Facture Proforma et non un reçu fiscal. Validité : 10 jours **
                    </p>
                ) : (
                    <p>Merci de votre visite !</p>
                )}
                <p className="mt-2">Généré par RetailManager System</p>
            </div>
        </div>
    );
});

InvoiceTemplate.displayName = "InvoiceTemplate";
