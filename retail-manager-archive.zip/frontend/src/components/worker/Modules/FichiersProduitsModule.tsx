import { useState, useEffect, useMemo } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Search, Plus, Edit2, Trash2, Package, Barcode, History } from 'lucide-react';
import { getDataClient } from '@/lib/dataClient';
import { useMasterDataStore, ProductMaster, ProductFamily, Supplier } from '@/stores/useMasterDataStore';
import { toast } from '@/hooks/use-toast';
import { OfflineAuthService } from '@/services/OfflineAuthService';

interface FichiersProduitsModuleProps {
  storeId: string;
}

type ProductInsertPayload = {
  name: string;
  store_id: string;
  sku?: string | null;
  barcode?: string | null;
  description?: string | null;
  cost_price?: number;
  unit_price?: number;
  wholesale_price?: number;
  min_quantity?: number;
  category?: string | null;
  quantity?: number;
};

interface LocalBridgeProduct {
  id: string;
  store_id: string;
  name: string;
  sku?: string | null;
  barcode?: string | null;
  description?: string | null;
  cost_price?: number | null;
  unit_price?: number | null;
  wholesale_price?: number | null;
  min_quantity?: number | null;
  quantity?: number | null;
  category?: string | null;
  image_url?: string | null;
  created_at: string;
  updated_at: string;
}

interface LocalBridgeProductFamily {
  id: string;
  store_id: string;
  name: string;
  description?: string | null;
  parent_id?: string | null;
  created_at: string;
  updated_at: string;
}

const mapLocalBridgeProduct = (product: LocalBridgeProduct): ProductMaster => ({
  id: product.id,
  name: product.name,
  sku: product.sku || undefined,
  barcode: product.barcode || undefined,
  description: product.description || undefined,
  purchase_price: product.cost_price ?? undefined,
  selling_price_detail: product.unit_price ?? undefined,
  selling_price_wholesale: product.wholesale_price ?? undefined,
  min_stock_alert: product.min_quantity ?? undefined,
  current_stock: product.quantity ?? 0,
  unit_type: 'Pièce',
  family_id: product.category || undefined,
  brand: '',
  expiry_date: undefined,
  last_sale_date: undefined,
  last_purchase_date: undefined,
  preferred_supplier_id: undefined,
  store_id: product.store_id,
  image_url: product.image_url || undefined,
  created_at: product.created_at,
  updated_at: product.updated_at,
  selling_price_3: undefined,
  selling_price_4: undefined,
});

const mapLocalBridgeFamily = (family: LocalBridgeProductFamily): ProductFamily => ({
  id: family.id,
  name: family.name,
  description: family.description || undefined,
  parent_id: family.parent_id || undefined,
  store_id: family.store_id,
  created_at: family.created_at,
  updated_at: family.updated_at,
});

export function FichiersProduitsModule({ storeId }: FichiersProduitsModuleProps) {
  const { supabase, isLocalFirst: isLocalFirstMode, localBridgeBaseUrl } = getDataClient();
  const { products, setProducts, families, setFamilies, suppliers, setSuppliers, setLoading } = useMasterDataStore();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedFamily, setSelectedFamily] = useState<string>('all');
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState<ProductMaster | null>(null);
  const [isSaving, setIsSaving] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    sku: '',
    barcode: '',
    description: '',
    purchase_price: 0,
    selling_price_detail: 0,
    selling_price_wholesale: 0,
    selling_price_3: 0,
    selling_price_4: 0,
    min_stock_alert: 0,
    unit_type: 'Pièce',
    family_id: '',
    brand: '',
    preferred_supplier_id: '',
  });

  const useLocalBridge = isLocalFirstMode;

  const localBridgeRequest = async <T,>(path: string, init: RequestInit = {}) => {
    if (!useLocalBridge) {
      throw new Error('LocalBridge mode is not enabled.');
    }

    const headers = await OfflineAuthService.getAuthHeaders();
    if (!headers) {
      throw new Error('LocalBridge session expired. Please sign in again.');
    }

    const response = await fetch(`${localBridgeBaseUrl}${path}`, {
      ...init,
      headers: {
        'Content-Type': 'application/json',
        ...(init.headers || {}),
        ...headers,
      },
    });

    let payload: any = null;
    if (response.status !== 204) {
      try {
        payload = await response.json();
      } catch (error) {
        // Non-JSON response (e.g., empty body)
      }
    }

    if (!response.ok) {
      const message = payload?.message || 'LocalBridge request failed';
      throw new Error(message);
    }

    return payload as T;
  };

  // Fetch all data on mount
  useEffect(() => {
    if (storeId) {
      fetchProducts();
      fetchFamilies();
      fetchSuppliers();
    }
  }, [storeId]);

  const fetchProducts = async () => {
    setLoading(true);
    if (!storeId) {
      setLoading(false);
      return;
    }

    if (useLocalBridge) {
      try {
        const params = new URLSearchParams();
        params.set('store_id', storeId);
        const data = await localBridgeRequest<LocalBridgeProduct[]>(`/rest/v1/products?${params.toString()}`);
        setProducts(data.map(mapLocalBridgeProduct));
      } catch (error) {
        console.error('LocalBridge fetchProducts error:', error);
        toast({
          title: 'Offline Products',
          description: error instanceof Error ? error.message : 'Failed to load products from LocalBridge.',
          variant: 'destructive',
        });
      } finally {
        setLoading(false);
      }
      return;
    }

    const { data, error } = await supabase
      .from('products')
      .select('*')
      .eq('store_id', storeId)
      .order('name');
    
    if (data && !error) {
      const mapped: ProductMaster[] = data.map((p) => ({
        id: p.id,
        name: p.name,
        sku: p.sku,
        barcode: p.barcode,
        description: p.description,
        purchase_price: p.cost_price,
        selling_price_detail: p.unit_price,
        selling_price_wholesale: p.wholesale_price,
        min_stock_alert: p.min_quantity,
        current_stock: p.quantity,
        unit_type: 'Pièce',
        family_id: p.category,
        brand: '',
        image_url: p.image_url,
        store_id: p.store_id,
        created_at: p.created_at,
        updated_at: p.updated_at,
      }));
      setProducts(mapped);
    }
    setLoading(false);
  };

  const fetchFamilies = async () => {
    if (!storeId) return;

    if (useLocalBridge) {
      try {
        const params = new URLSearchParams();
        params.set('store_id', storeId);
        const data = await localBridgeRequest<LocalBridgeProductFamily[]>(`/rest/v1/product_families?${params.toString()}`);
        setFamilies(data.map(mapLocalBridgeFamily));
      } catch (error) {
        console.error('LocalBridge fetchFamilies error:', error);
        toast({
          title: 'Offline Families',
          description: error instanceof Error ? error.message : 'Failed to load product families from LocalBridge.',
          variant: 'destructive',
        });
      }
      return;
    }

    const { data, error } = await supabase
      .from('product_families')
      .select('*')
      .eq('store_id', storeId)
      .order('name');

    if (data && !error) {
      setFamilies(data as ProductFamily[]);
    }
  };

  const fetchSuppliers = async () => {
    if (!storeId) return;
    // Cast as any - suppliers table may not be in types yet
    const { data, error } = await (supabase as any)
      .from('suppliers')
      .select('*')
      .eq('store_id', storeId)
      .order('name');

    if (data && !error) {
      setSuppliers(data as Supplier[]);
    }
  };

  const callWorkerCreateProductRpc = async (productData: ProductInsertPayload) => {
    if (useLocalBridge) {
      try {
        const data = await localBridgeRequest<LocalBridgeProduct>('/rpc/worker_create_product', {
          method: 'POST',
          body: JSON.stringify({
            p_store_id: productData.store_id,
            p_name: productData.name,
            p_description: productData.description ?? null,
            p_sku: productData.sku ?? null,
            p_barcode: productData.barcode ?? null,
            p_category: productData.category ?? null,
            p_unit_price: productData.unit_price ?? 0,
            p_cost_price: productData.cost_price ?? null,
            p_wholesale_price: productData.wholesale_price ?? null,
            p_min_quantity: productData.min_quantity ?? 0,
            p_quantity: productData.quantity ?? 0,
          }),
        });
        return { data };
      } catch (error) {
        return {
          error: {
            message: error instanceof Error ? error.message : 'LocalBridge product creation failed',
          },
        };
      }
    }

    try {
      const { data, error } = await supabase.rpc('worker_create_product', {
        p_store_id: productData.store_id,
        p_name: productData.name,
        p_description: productData.description ?? null,
        p_sku: productData.sku ?? null,
        p_barcode: productData.barcode ?? null,
        p_category: productData.category ?? null,
        p_unit_price: productData.unit_price ?? 0,
        p_cost_price: productData.cost_price ?? null,
        p_wholesale_price: productData.wholesale_price ?? null,
        p_min_quantity: productData.min_quantity ?? 0,
        p_quantity: productData.quantity ?? 0,
      });

      if (error) {
        console.warn('worker_create_product RPC error', error);
        return { error };
      }

      if (!data) {
        console.warn('worker_create_product RPC returned no data');
        return { error: { message: 'Aucune réponse du serveur' } };
      }

      return { data };
    } catch (error) {
      console.warn('worker_create_product RPC invocation failed', error);
      return { error };
    }
  };

  const createProductWithEdgeFallback = async (productData: ProductInsertPayload) => {
    if (useLocalBridge) {
      return callWorkerCreateProductRpc(productData);
    }

    const rpcResult = await callWorkerCreateProductRpc(productData);
    if (!rpcResult.error && rpcResult.data) {
      return rpcResult;
    }

    if (rpcResult.error) {
      console.warn('RPC fallback triggered for product insert', rpcResult.error);
    }

    const { data, error } = await supabase
      .from('products')
      .insert([productData])
      .select()
      .single();

    if (error) {
      return { error };
    }

    return { data };
  };

  const filteredProducts = useMemo(() => {
    return products.filter((p) => {
      const matchesSearch = p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        p.sku?.toLowerCase().includes(searchQuery.toLowerCase()) ||
        p.barcode?.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesFamily = selectedFamily === 'all' || p.family_id === selectedFamily;
      return matchesSearch && matchesFamily;
    });
  }, [products, searchQuery, selectedFamily]);

  const handleSave = async () => {
    if (isSaving) return;
    if (!formData.name.trim()) {
      toast({ title: 'Erreur', description: 'Le nom est requis', variant: 'destructive' });
      return;
    }

    if (!storeId) {
      toast({ title: 'Erreur', description: 'Aucun magasin assigné', variant: 'destructive' });
      return;
    }

    setIsSaving(true);

    const productData = {
      name: formData.name.trim(),
      sku: formData.sku.trim() || null,
      barcode: formData.barcode.trim() || null,
      description: formData.description.trim() || null,
      cost_price: Number(formData.purchase_price) || 0,
      unit_price: Number(formData.selling_price_detail) || 0,
      wholesale_price: Number(formData.selling_price_wholesale) || 0,
      min_quantity: Number(formData.min_stock_alert) || 0,
      category: formData.family_id || null,
      store_id: storeId,
    };

    try {
      if (editingProduct) {
        if (useLocalBridge) {
          try {
            await localBridgeRequest<LocalBridgeProduct>(`/rest/v1/products/${editingProduct.id}`, {
              method: 'PATCH',
              body: JSON.stringify(productData),
            });
            toast({ title: 'Succès', description: 'Produit mis à jour (offline).' });
            await fetchProducts();
            return;
          } catch (error) {
            toast({
              title: 'Erreur',
              description: error instanceof Error ? error.message : 'Mise à jour locale impossible',
              variant: 'destructive',
            });
            return;
          }
        }

        const { error } = await supabase
          .from('products')
          .update(productData)
          .eq('id', editingProduct.id);

        if (error) {
          toast({ title: 'Erreur', description: error.message, variant: 'destructive' });
          return;
        }

        toast({ title: 'Succès', description: 'Produit mis à jour' });
        await fetchProducts();
      } else {
        const insertPayload = { ...productData, quantity: 0 };
        const result = await createProductWithEdgeFallback(insertPayload);

        if ('error' in result && result.error) {
          toast({ title: 'Erreur', description: (result.error as any).message || 'Impossible de créer le produit', variant: 'destructive' });
          return;
        }

        toast({ title: 'Succès', description: 'Produit créé' });
        await fetchProducts();
      }

      setIsDialogOpen(false);
      resetForm();
    } finally {
      setIsSaving(false);
    }
  };

  const handleEdit = (product: ProductMaster) => {
    setEditingProduct(product);
    setFormData({
      name: product.name,
      sku: product.sku || '',
      barcode: product.barcode || '',
      description: product.description || '',
      purchase_price: product.purchase_price || 0,
      selling_price_detail: product.selling_price_detail || 0,
      selling_price_wholesale: product.selling_price_wholesale || 0,
      selling_price_3: product.selling_price_3 || 0,
      selling_price_4: product.selling_price_4 || 0,
      min_stock_alert: product.min_stock_alert || 0,
      unit_type: product.unit_type || 'Pièce',
      family_id: product.family_id || '',
      brand: product.brand || '',
      preferred_supplier_id: product.preferred_supplier_id || '',
    });
    setIsDialogOpen(true);
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Supprimer ce produit ?')) return;

    if (useLocalBridge) {
      try {
        await localBridgeRequest(`/rest/v1/products/${id}`, { method: 'DELETE' });
        toast({ title: 'Produit supprimé (offline)' });
        await fetchProducts();
      } catch (error) {
        toast({
          title: 'Erreur',
          description: error instanceof Error ? error.message : 'Suppression locale impossible',
          variant: 'destructive',
        });
      }
      return;
    }

    const { error } = await supabase.from('products').delete().eq('id', id);
    if (error) {
      toast({ title: 'Erreur', description: error.message, variant: 'destructive' });
    } else {
      toast({ title: 'Produit supprimé' });
      await fetchProducts();
    }
  };

  const resetForm = () => {
    setEditingProduct(null);
    setFormData({
      name: '', sku: '', barcode: '', description: '',
      purchase_price: 0, selling_price_detail: 0, selling_price_wholesale: 0,
      selling_price_3: 0, selling_price_4: 0, min_stock_alert: 0,
      unit_type: 'Pièce', family_id: '', brand: '', preferred_supplier_id: '',
    });
  };

  const generateBarcode = () => {
    const code = `PRD${Date.now().toString(36).toUpperCase()}`;
    setFormData((f) => ({ ...f, barcode: code }));
  };

  const marginPercent = formData.purchase_price > 0 
    ? (((formData.selling_price_detail - formData.purchase_price) / formData.purchase_price) * 100).toFixed(1)
    : '0';

  return (
    <div className="h-full flex flex-col p-4 gap-4">
      {/* Header */}
      <div className="flex items-center gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Rechercher par nom, SKU, code-barres..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-9"
          />
        </div>
        <Select value={selectedFamily} onValueChange={setSelectedFamily}>
          <SelectTrigger className="w-48">
            <SelectValue placeholder="Famille" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Toutes les familles</SelectItem>
            {families.map((f) => (
              <SelectItem key={f.id} value={f.id}>{f.name}</SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Button onClick={() => { resetForm(); setIsDialogOpen(true); }}>
          <Plus className="h-4 w-4 mr-2" /> Nouveau Produit
        </Button>
      </div>

      {/* Products Table */}
      <Card className="flex-1 overflow-hidden">
        <CardContent className="p-0 h-full overflow-auto">
          <Table>
            <TableHeader className="sticky top-0 bg-card z-10">
              <TableRow>
                <TableHead className="w-12">#</TableHead>
                <TableHead>Nom</TableHead>
                <TableHead>SKU</TableHead>
                <TableHead>Famille</TableHead>
                <TableHead className="text-right">P. Achat</TableHead>
                <TableHead className="text-right">P. Détail</TableHead>
                <TableHead className="text-right">P. Gros</TableHead>
                <TableHead className="text-right">Stock</TableHead>
                <TableHead className="text-center">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredProducts.map((product, idx) => {
                const family = families.find((f) => f.id === product.family_id);
                const isLowStock = product.current_stock <= (product.min_stock_alert || 0);
                return (
                  <TableRow key={product.id} className="cursor-pointer hover:bg-muted/50">
                    <TableCell className="text-muted-foreground">{idx + 1}</TableCell>
                    <TableCell className="font-medium">{product.name}</TableCell>
                    <TableCell className="text-muted-foreground">{product.sku || '-'}</TableCell>
                    <TableCell>
                      {family ? <Badge variant="outline">{family.name}</Badge> : '-'}
                    </TableCell>
                    <TableCell className="text-right">{(product.purchase_price || 0).toLocaleString()}</TableCell>
                    <TableCell className="text-right font-medium">{(product.selling_price_detail || 0).toLocaleString()}</TableCell>
                    <TableCell className="text-right">{(product.selling_price_wholesale || 0).toLocaleString()}</TableCell>
                    <TableCell className="text-right">
                      <Badge variant={isLowStock ? 'destructive' : 'secondary'}>
                        {product.current_stock}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-center">
                      <div className="flex justify-center gap-1">
                        <Button variant="ghost" size="icon" onClick={() => handleEdit(product)}>
                          <Edit2 className="h-4 w-4" />
                        </Button>
                        <Button variant="ghost" size="icon" onClick={() => handleDelete(product.id)}>
                          <Trash2 className="h-4 w-4 text-destructive" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                );
              })}
              {filteredProducts.length === 0 && (
                <TableRow>
                  <TableCell colSpan={9} className="text-center py-8 text-muted-foreground">
                    <Package className="h-12 w-12 mx-auto mb-2 opacity-50" />
                    Aucun produit trouvé
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* Product Dialog */}
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Package className="h-5 w-5" />
              {editingProduct ? 'Modifier le Produit' : 'Nouveau Produit'}
            </DialogTitle>
          </DialogHeader>

          <Tabs defaultValue="general" className="mt-4">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="general">Général</TabsTrigger>
              <TabsTrigger value="pricing">Tarification</TabsTrigger>
              <TabsTrigger value="stock">Stock</TabsTrigger>
            </TabsList>

            <TabsContent value="general" className="space-y-4 mt-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Nom *</Label>
                  <Input
                    value={formData.name}
                    onChange={(e) => setFormData((f) => ({ ...f, name: e.target.value }))}
                    placeholder="Nom du produit"
                  />
                </div>
                <div className="space-y-2">
                  <Label>SKU / Référence</Label>
                  <Input
                    value={formData.sku}
                    onChange={(e) => setFormData((f) => ({ ...f, sku: e.target.value }))}
                    placeholder="REF-001"
                  />
                </div>
                <div className="space-y-2">
                  <Label>Code-barres</Label>
                  <div className="flex gap-2">
                    <Input
                      value={formData.barcode}
                      onChange={(e) => setFormData((f) => ({ ...f, barcode: e.target.value }))}
                      placeholder="1234567890123"
                    />
                    <Button type="button" variant="outline" size="icon" onClick={generateBarcode}>
                      <Barcode className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
                <div className="space-y-2">
                  <Label>Famille</Label>
                  <Select
                    value={formData.family_id}
                    onValueChange={(v) => setFormData((f) => ({ ...f, family_id: v }))}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Sélectionner..." />
                    </SelectTrigger>
                    <SelectContent>
                      {families.map((fam) => (
                        <SelectItem key={fam.id} value={fam.id}>{fam.name}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>Unité</Label>
                  <Select
                    value={formData.unit_type}
                    onValueChange={(v) => setFormData((f) => ({ ...f, unit_type: v }))}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Pièce">Pièce</SelectItem>
                      <SelectItem value="Kg">Kilogramme</SelectItem>
                      <SelectItem value="L">Litre</SelectItem>
                      <SelectItem value="M">Mètre</SelectItem>
                      <SelectItem value="Carton">Carton</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>Marque</Label>
                  <Input
                    value={formData.brand}
                    onChange={(e) => setFormData((f) => ({ ...f, brand: e.target.value }))}
                    placeholder="Marque..."
                  />
                </div>
              </div>
              <div className="space-y-2">
                <Label>Description</Label>
                <Input
                  value={formData.description}
                  onChange={(e) => setFormData((f) => ({ ...f, description: e.target.value }))}
                  placeholder="Description du produit..."
                />
              </div>
            </TabsContent>

            <TabsContent value="pricing" className="space-y-4 mt-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Prix d'Achat</Label>
                  <Input
                    type="number"
                    value={formData.purchase_price}
                    onChange={(e) => setFormData((f) => ({ ...f, purchase_price: Number(e.target.value) }))}
                  />
                </div>
                <div className="space-y-2">
                  <Label>Prix Détail</Label>
                  <Input
                    type="number"
                    value={formData.selling_price_detail}
                    onChange={(e) => setFormData((f) => ({ ...f, selling_price_detail: Number(e.target.value) }))}
                  />
                </div>
                <div className="space-y-2">
                  <Label>Prix Gros</Label>
                  <Input
                    type="number"
                    value={formData.selling_price_wholesale}
                    onChange={(e) => setFormData((f) => ({ ...f, selling_price_wholesale: Number(e.target.value) }))}
                  />
                </div>
                <div className="space-y-2">
                  <Label>Prix 3</Label>
                  <Input
                    type="number"
                    value={formData.selling_price_3}
                    onChange={(e) => setFormData((f) => ({ ...f, selling_price_3: Number(e.target.value) }))}
                  />
                </div>
                <div className="space-y-2">
                  <Label>Prix 4</Label>
                  <Input
                    type="number"
                    value={formData.selling_price_4}
                    onChange={(e) => setFormData((f) => ({ ...f, selling_price_4: Number(e.target.value) }))}
                  />
                </div>
              </div>
              <Card className="bg-muted/50">
                <CardContent className="p-4">
                  <div className="flex justify-between items-center">
                    <span className="text-muted-foreground">Marge calculée:</span>
                    <span className="text-xl font-bold text-primary">{marginPercent}%</span>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="stock" className="space-y-4 mt-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Stock Minimum (Alerte)</Label>
                  <Input
                    type="number"
                    value={formData.min_stock_alert}
                    onChange={(e) => setFormData((f) => ({ ...f, min_stock_alert: Number(e.target.value) }))}
                  />
                </div>
              </div>
              {editingProduct && (
                <Card className="bg-muted/50">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm flex items-center gap-2">
                      <History className="h-4 w-4" /> Derniers Mouvements
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="text-sm text-muted-foreground">
                    Historique à venir...
                  </CardContent>
                </Card>
              )}
            </TabsContent>
          </Tabs>

          <div className="flex justify-end gap-2 mt-6">
            <Button variant="outline" onClick={() => setIsDialogOpen(false)}>Annuler</Button>
            <Button onClick={handleSave} disabled={isSaving}>
              {isSaving ? 'Enregistrement...' : editingProduct ? 'Enregistrer' : 'Créer'}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
