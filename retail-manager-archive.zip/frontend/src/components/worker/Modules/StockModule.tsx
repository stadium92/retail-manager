import { useState, useEffect, useMemo } from 'react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Label } from '@/components/ui/label';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { 
  Package, Search, Download, Filter, CheckCircle, 
  AlertTriangle, XCircle, History, Save, RotateCcw,
  WifiOff, RefreshCw
} from 'lucide-react';
import { format } from 'date-fns';
import { fr } from 'date-fns/locale';
import { cn } from '@/lib/utils';
import { toast } from 'sonner';
import { OfflineDataService, StockMovement } from '@/services/OfflineDataService';
import { useMasterDataStore } from '@/stores/useMasterDataStore';
import { LocalDatabase } from '@/services/LocalDatabase';

interface StockModuleProps {
  storeId: string;
  mode: 'fiche-stock' | 'mouvements-stock' | 'listing-stock' | 'regularisation-stock' | 
        'valorisation-stock' | 'inventaire-stock';
}

interface Product {
  id: string;
  name: string;
  sku: string | null;
  quantity: number;
  unit_price: number;
  cost_price: number | null;
  min_quantity: number | null;
  category: string | null;
  expiry_date: string | null;
  updated_at: string;
}

interface InventoryCount {
  productId: string;
  productName: string;
  systemStock: number;
  physicalStock: number;
  difference: number;
}

type StockFilter = 'all' | 'in_stock' | 'out_of_stock' | 'expired';

const formatCurrency = (amount: number) => amount.toLocaleString('fr-FR') + ' F';

export function StockModule({ storeId, mode }: StockModuleProps) {
  const [products, setProducts] = useState<Product[]>([]);
  const [movements, setMovements] = useState<StockMovement[]>([]);
  const [movementsMessage, setMovementsMessage] = useState<string | null>(null);
  const [inventoryCounts, setInventoryCounts] = useState<InventoryCount[]>([]);
  const [selectedProductId, setSelectedProductId] = useState<string>('');
  const [searchQuery, setSearchQuery] = useState('');
  const [filter, setFilter] = useState<StockFilter>('all');
  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const [isOffline, setIsOffline] = useState(!navigator.onLine);
  
  // Regularisation state
  const [regProductId, setRegProductId] = useState<string>('');
  const [regAdjustmentType, setRegAdjustmentType] = useState<'add' | 'subtract'>('add');
  const [regQuantity, setRegQuantity] = useState<number>(0);
  const [regReason, setRegReason] = useState<string>('');

  // Get products from Zustand store for offline access
  const storeProducts = useMasterDataStore(state => state.products);

  // Listen for online/offline changes
  useEffect(() => {
    const handleOnline = () => setIsOffline(false);
    const handleOffline = () => setIsOffline(true);
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  // Fetch products from Zustand store (offline-capable)
  useEffect(() => {
    const fetchData = async () => {
      if (!storeId) return;
      setIsLoading(true);

      try {
        // Get products from Zustand store (offline-capable)
        const offlineProducts = storeProducts
          .filter(p => p.store_id === storeId)
          .map(p => ({
            id: p.id,
            name: p.name,
            sku: p.sku || null,
            quantity: p.current_stock,
            unit_price: p.selling_price_detail || 0,
            cost_price: p.purchase_price || null,
            min_quantity: p.min_stock_alert || null,
            category: p.family_id || null,
            expiry_date: p.expiry_date || null,
            updated_at: p.updated_at,
          }));
        setProducts(offlineProducts);

        // Initialize inventory counts
        if (mode === 'inventaire-stock' && offlineProducts.length > 0) {
          setInventoryCounts(offlineProducts.map(p => ({
            productId: p.id,
            productName: p.name,
            systemStock: p.quantity,
            physicalStock: p.quantity,
            difference: 0,
          })));
        }

        // Get stock movements
        if (mode === 'mouvements-stock') {
          const { movements: movData, offlineMessage } = await OfflineDataService.getStockMovements(storeId);
          setMovements(movData);
          if (offlineMessage) {
            setMovementsMessage(offlineMessage);
          }
        }
      } catch (error) {
        console.error('Error fetching data:', error);
        toast.error('Erreur lors du chargement des données');
      }

      setIsLoading(false);
    };

    fetchData();
  }, [storeId, mode, storeProducts]);

  // Filter products
  const filteredProducts = useMemo(() => {
    return products.filter(p => {
      const matchesSearch = 
        p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        p.sku?.toLowerCase().includes(searchQuery.toLowerCase());
      
      if (!matchesSearch) return false;

      switch (filter) {
        case 'in_stock': return p.quantity > 0;
        case 'out_of_stock': return p.quantity <= 0;
        case 'expired': return p.expiry_date && new Date(p.expiry_date) < new Date();
        default: return true;
      }
    });
  }, [products, searchQuery, filter]);

  // Calculate stats
  const stats = useMemo(() => {
    const total = products.length;
    const inStock = products.filter(p => p.quantity > 0).length;
    const outOfStock = products.filter(p => p.quantity <= 0).length;
    const lowStock = products.filter(p => p.quantity > 0 && p.quantity <= (p.min_quantity || 10)).length;
    const totalValue = products.reduce((sum, p) => sum + (p.quantity * (p.cost_price || p.unit_price)), 0);
    const totalSaleValue = products.reduce((sum, p) => sum + (p.quantity * p.unit_price), 0);
    
    return { total, inStock, outOfStock, lowStock, totalValue, totalSaleValue };
  }, [products]);

  // Selected product for fiche-stock
  const selectedProduct = useMemo(() => 
    products.find(p => p.id === selectedProductId), [products, selectedProductId]);

  // Product movements (mock data based on selected product)
  const productMovements = useMemo(() => {
    if (!selectedProduct) return [];
    return [
      { date: 'Aujourd\'hui', type: 'Vente', qty: -3, balance: selectedProduct.quantity },
      { date: 'Hier', type: 'Vente', qty: -5, balance: selectedProduct.quantity + 3 },
      { date: '15/01/2024', type: 'Achat', qty: 20, balance: selectedProduct.quantity + 8 },
      { date: '10/01/2024', type: 'Vente', qty: -8, balance: selectedProduct.quantity - 12 },
      { date: '05/01/2024', type: 'Ajustement', qty: -2, balance: selectedProduct.quantity - 4 },
    ];
  }, [selectedProduct]);

  // Update physical stock count
  const updatePhysicalStock = (productId: string, value: number) => {
    setInventoryCounts(counts => counts.map(c => {
      if (c.productId === productId) {
        return { ...c, physicalStock: value, difference: value - c.systemStock };
      }
      return c;
    }));
  };

  // Validate inventory - works offline
  const handleValidateInventory = async () => {
    const itemsWithDifference = inventoryCounts.filter(c => c.difference !== 0);
    if (itemsWithDifference.length === 0) {
      toast.info('Aucune différence à ajuster');
      return;
    }

    setIsSaving(true);
    try {
      for (const item of itemsWithDifference) {
        await OfflineDataService.updateProductStock(item.productId, item.physicalStock, 'Inventaire');
      }
      toast.success(`${itemsWithDifference.length} produit(s) ajusté(s)`);
      
      // Update local state
      setProducts(prev => prev.map(p => {
        const adjusted = itemsWithDifference.find(i => i.productId === p.id);
        return adjusted ? { ...p, quantity: adjusted.physicalStock } : p;
      }));
      
      // Reset counts
      setInventoryCounts(prev => prev.map(c => ({
        ...c,
        systemStock: c.physicalStock,
        difference: 0,
      })));
    } catch (error) {
      toast.error('Erreur lors de la validation');
    } finally {
      setIsSaving(false);
    }
  };

  // Handle regularisation - works offline
  const handleRegularisation = async () => {
    if (!regProductId || regQuantity <= 0 || !regReason.trim()) {
      toast.error('Veuillez remplir tous les champs');
      return;
    }

    const product = products.find(p => p.id === regProductId);
    if (!product) return;

    setIsSaving(true);
    try {
      const newQuantity = regAdjustmentType === 'add' 
        ? product.quantity + regQuantity 
        : Math.max(0, product.quantity - regQuantity);

      await OfflineDataService.updateProductStock(regProductId, newQuantity, regReason);
      
      toast.success(`Stock ajusté: ${product.name} → ${newQuantity}`);
      
      // Update local state
      setProducts(prev => prev.map(p => 
        p.id === regProductId ? { ...p, quantity: newQuantity } : p
      ));

      // Reset form
      setRegProductId('');
      setRegQuantity(0);
      setRegReason('');
    } catch (error) {
      toast.error('Erreur lors de la régularisation');
    } finally {
      setIsSaving(false);
    }
  };

  // Offline indicator
  const OfflineIndicator = () => isOffline ? (
    <div className="flex items-center gap-2 px-3 py-1 rounded-full bg-warning/20 text-warning text-xs">
      <WifiOff className="h-3 w-3" />
      <span>Mode hors ligne</span>
    </div>
  ) : null;

  const renderContent = () => {
    switch (mode) {
      case 'fiche-stock':
        return (
          <div className="grid grid-cols-[300px_1fr] gap-4 h-full">
            {/* Product List */}
            <Card className="h-full flex flex-col">
              <CardHeader className="py-3">
                <div className="flex items-center gap-2">
                  <Input
                    placeholder="Rechercher..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="h-8 flex-1"
                  />
                  <OfflineIndicator />
                </div>
              </CardHeader>
              <CardContent className="p-0 flex-1 overflow-hidden">
                <ScrollArea className="h-full">
                  {filteredProducts.map(product => (
                    <div
                      key={product.id}
                      onClick={() => setSelectedProductId(product.id)}
                      className={cn(
                        'px-4 py-2 cursor-pointer border-b border-border/30 transition-colors',
                        'hover:bg-primary/5',
                        selectedProductId === product.id && 'bg-primary/10 border-l-2 border-l-primary'
                      )}
                    >
                      <div className="text-sm font-medium truncate">{product.name}</div>
                      <div className="text-xs text-muted-foreground">
                        Stock: {product.quantity} | {formatCurrency(product.unit_price)}
                      </div>
                    </div>
                  ))}
                  {filteredProducts.length === 0 && (
                    <div className="text-center py-8 text-muted-foreground">
                      Aucun produit trouvé
                    </div>
                  )}
                </ScrollArea>
              </CardContent>
            </Card>

            {/* Product Details */}
            <Card className="h-full flex flex-col">
              {selectedProduct ? (
                <>
                  <CardHeader className="py-3 border-b">
                    <div className="flex items-center justify-between">
                      <div>
                        <CardTitle className="text-lg">{selectedProduct.name}</CardTitle>
                        <p className="text-xs text-muted-foreground mt-1">
                          SKU: {selectedProduct.sku || '—'} | Catégorie: {selectedProduct.category || '—'}
                        </p>
                      </div>
                      <div className="text-right">
                        <div className="text-2xl font-bold text-primary">{selectedProduct.quantity}</div>
                        <div className="text-xs text-muted-foreground">en stock</div>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent className="flex-1 p-4 overflow-auto">
                    <div className="grid grid-cols-3 gap-4 mb-6">
                      <div className="p-3 rounded-lg bg-muted/50">
                        <p className="text-xs text-muted-foreground">Prix Vente</p>
                        <p className="text-lg font-bold">{formatCurrency(selectedProduct.unit_price)}</p>
                      </div>
                      <div className="p-3 rounded-lg bg-muted/50">
                        <p className="text-xs text-muted-foreground">Prix Achat</p>
                        <p className="text-lg font-bold">{formatCurrency(selectedProduct.cost_price || 0)}</p>
                      </div>
                      <div className="p-3 rounded-lg bg-muted/50">
                        <p className="text-xs text-muted-foreground">Valeur Stock</p>
                        <p className="text-lg font-bold">
                          {formatCurrency(selectedProduct.quantity * (selectedProduct.cost_price || selectedProduct.unit_price))}
                        </p>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 mb-3">
                      <History className="h-4 w-4" />
                      <span className="text-sm font-medium">Historique des Mouvements</span>
                    </div>
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead className="text-xs">Date</TableHead>
                          <TableHead className="text-xs">Type</TableHead>
                          <TableHead className="text-xs text-center">Mouvement</TableHead>
                          <TableHead className="text-xs text-right">Solde</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {productMovements.map((mov, idx) => (
                          <TableRow key={idx} className="h-9">
                            <TableCell className="text-xs">{mov.date}</TableCell>
                            <TableCell className="text-xs">{mov.type}</TableCell>
                            <TableCell className={cn(
                              "text-xs text-center font-medium",
                              mov.qty > 0 ? 'text-success' : 'text-danger'
                            )}>
                              {mov.qty > 0 ? '+' : ''}{mov.qty}
                            </TableCell>
                            <TableCell className="text-xs text-right">{mov.balance}</TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </CardContent>
                </>
              ) : (
                <CardContent className="flex-1 flex items-center justify-center">
                  <div className="text-center text-muted-foreground">
                    <Package className="h-12 w-12 mx-auto mb-3 opacity-30" />
                    <p>Sélectionnez un produit</p>
                  </div>
                </CardContent>
              )}
            </Card>
          </div>
        );

      case 'mouvements-stock':
        return (
          <Card className="h-full flex flex-col">
            <CardHeader className="py-3 border-b">
              <div className="flex items-center gap-4">
                <Input
                  placeholder="Rechercher..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-64 h-8"
                />
                <Select value={filter} onValueChange={(v) => setFilter(v as StockFilter)}>
                  <SelectTrigger className="w-40 h-8">
                    <Filter className="h-4 w-4 mr-2" />
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Tous</SelectItem>
                    <SelectItem value="in_stock">Entrées</SelectItem>
                    <SelectItem value="out_of_stock">Sorties</SelectItem>
                  </SelectContent>
                </Select>
                <OfflineIndicator />
              </div>
            </CardHeader>
            <CardContent className="flex-1 p-0 overflow-hidden">
              {movementsMessage && (
                <div className="p-4 bg-warning/10 border-b border-warning/20 text-warning text-sm">
                  {movementsMessage}
                </div>
              )}
              <ScrollArea className="h-full">
                <Table>
                  <TableHeader className="sticky top-0 bg-background">
                    <TableRow>
                      <TableHead className="text-xs">Date</TableHead>
                      <TableHead className="text-xs">Produit</TableHead>
                      <TableHead className="text-xs">Type</TableHead>
                      <TableHead className="text-xs text-center">Quantité</TableHead>
                      <TableHead className="text-xs">Raison</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {movements.map(mov => (
                      <TableRow key={mov.id} className="h-10">
                        <TableCell className="text-xs">
                          {format(new Date(mov.date), 'dd/MM/yyyy HH:mm', { locale: fr })}
                        </TableCell>
                        <TableCell className="text-xs font-medium">{mov.product_name}</TableCell>
                        <TableCell>
                          <Badge variant={
                            mov.type === 'in' ? 'default' : 
                            mov.type === 'out' ? 'destructive' : 'secondary'
                          } className="text-xs">
                            {mov.type === 'in' ? 'Entrée' : mov.type === 'out' ? 'Sortie' : 'Ajust.'}
                          </Badge>
                        </TableCell>
                        <TableCell className={cn(
                          "text-xs text-center font-medium",
                          mov.type === 'in' ? 'text-success' : 
                          mov.type === 'out' ? 'text-danger' : 'text-warning'
                        )}>
                          {mov.type === 'in' ? '+' : '-'}{mov.quantity}
                        </TableCell>
                        <TableCell className="text-xs">{mov.reason}</TableCell>
                      </TableRow>
                    ))}
                    {movements.length === 0 && (
                      <TableRow>
                        <TableCell colSpan={5} className="text-center text-muted-foreground py-8">
                          Aucun mouvement enregistré
                        </TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              </ScrollArea>
            </CardContent>
          </Card>
        );

      case 'regularisation-stock':
        const regSelectedProduct = products.find(p => p.id === regProductId);
        
        return (
          <div className="space-y-4">
            <div className="flex justify-end">
              <OfflineIndicator />
            </div>

            <Card>
              <CardHeader className="py-3">
                <CardTitle className="text-sm flex items-center gap-2">
                  <RotateCcw className="h-4 w-4" />
                  Régularisation du Stock
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label className="text-xs">Produit</Label>
                    <Select value={regProductId} onValueChange={setRegProductId}>
                      <SelectTrigger className="h-9">
                        <SelectValue placeholder="Sélectionner un produit" />
                      </SelectTrigger>
                      <SelectContent>
                        {products.map(p => (
                          <SelectItem key={p.id} value={p.id}>
                            {p.name} (Stock: {p.quantity})
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label className="text-xs">Stock Actuel</Label>
                    <Input 
                      value={regSelectedProduct ? regSelectedProduct.quantity : '—'} 
                      disabled 
                      className="h-9 bg-muted"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label className="text-xs">Type d'Ajustement</Label>
                  <RadioGroup 
                    value={regAdjustmentType} 
                    onValueChange={(v: 'add' | 'subtract') => setRegAdjustmentType(v)}
                    className="flex gap-4"
                  >
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="add" id="add" />
                      <Label htmlFor="add" className="text-sm font-normal cursor-pointer">
                        Addition (+)
                      </Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="subtract" id="subtract" />
                      <Label htmlFor="subtract" className="text-sm font-normal cursor-pointer">
                        Soustraction (-)
                      </Label>
                    </div>
                  </RadioGroup>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label className="text-xs">Quantité</Label>
                    <Input
                      type="number"
                      min={0}
                      value={regQuantity}
                      onChange={(e) => setRegQuantity(parseInt(e.target.value) || 0)}
                      className="h-9"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label className="text-xs">Nouveau Stock</Label>
                    <Input 
                      value={regSelectedProduct 
                        ? (regAdjustmentType === 'add' 
                            ? regSelectedProduct.quantity + regQuantity 
                            : Math.max(0, regSelectedProduct.quantity - regQuantity))
                        : '—'
                      } 
                      disabled 
                      className="h-9 bg-muted font-bold"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label className="text-xs">Raison</Label>
                  <Select value={regReason} onValueChange={setRegReason}>
                    <SelectTrigger className="h-9">
                      <SelectValue placeholder="Sélectionner une raison" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Trouvé">Trouvé</SelectItem>
                      <SelectItem value="Don / Cadeau">Don / Cadeau</SelectItem>
                      <SelectItem value="Erreur de comptage">Erreur de comptage</SelectItem>
                      <SelectItem value="Retour client">Retour client</SelectItem>
                      <SelectItem value="Correction inventaire">Correction inventaire</SelectItem>
                      <SelectItem value="Autre">Autre</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <Button 
                  onClick={handleRegularisation} 
                  disabled={isSaving || !regProductId || regQuantity <= 0 || !regReason}
                  className="w-full"
                >
                  {isSaving ? <RefreshCw className="h-4 w-4 mr-2 animate-spin" /> : <Save className="h-4 w-4 mr-2" />}
                  Appliquer la Régularisation
                </Button>
              </CardContent>
            </Card>
          </div>
        );

      case 'listing-stock':
        return (
          <Card className="h-full flex flex-col">
            <CardHeader className="py-3 border-b">
              <div className="flex items-center gap-4">
                <Input
                  placeholder="Rechercher un produit..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-64 h-8"
                />
                <Select value={filter} onValueChange={(v) => setFilter(v as StockFilter)}>
                  <SelectTrigger className="w-40 h-8">
                    <Filter className="h-4 w-4 mr-2" />
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Tous ({stats.total})</SelectItem>
                    <SelectItem value="in_stock">En stock ({stats.inStock})</SelectItem>
                    <SelectItem value="out_of_stock">Rupture ({stats.outOfStock})</SelectItem>
                    <SelectItem value="expired">Périmés</SelectItem>
                  </SelectContent>
                </Select>
                <OfflineIndicator />
                <Button variant="outline" size="sm" className="ml-auto">
                  <Download className="h-4 w-4 mr-2" />
                  Exporter
                </Button>
              </div>
            </CardHeader>
            <CardContent className="flex-1 p-0 overflow-hidden">
              <ScrollArea className="h-full">
                <Table>
                  <TableHeader className="sticky top-0 bg-background">
                    <TableRow>
                      <TableHead className="text-xs">Produit</TableHead>
                      <TableHead className="text-xs">SKU</TableHead>
                      <TableHead className="text-xs">Catégorie</TableHead>
                      <TableHead className="text-xs text-center">Stock</TableHead>
                      <TableHead className="text-xs text-right">Prix Vente</TableHead>
                      <TableHead className="text-xs text-center">Statut</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredProducts.map(product => (
                      <TableRow key={product.id} className="h-10">
                        <TableCell className="text-xs font-medium">{product.name}</TableCell>
                        <TableCell className="text-xs font-mono">{product.sku || '—'}</TableCell>
                        <TableCell className="text-xs">{product.category || '—'}</TableCell>
                        <TableCell className={cn(
                          "text-xs text-center font-bold",
                          product.quantity <= 0 ? 'text-danger' :
                          product.quantity <= (product.min_quantity || 10) ? 'text-warning' : ''
                        )}>
                          {product.quantity}
                        </TableCell>
                        <TableCell className="text-xs text-right">{formatCurrency(product.unit_price)}</TableCell>
                        <TableCell className="text-center">
                          {product.quantity <= 0 ? (
                            <XCircle className="h-4 w-4 text-danger inline" />
                          ) : product.quantity <= (product.min_quantity || 10) ? (
                            <AlertTriangle className="h-4 w-4 text-warning inline" />
                          ) : (
                            <CheckCircle className="h-4 w-4 text-success inline" />
                          )}
                        </TableCell>
                      </TableRow>
                    ))}
                    {filteredProducts.length === 0 && (
                      <TableRow>
                        <TableCell colSpan={6} className="text-center text-muted-foreground py-8">
                          Aucun produit trouvé
                        </TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              </ScrollArea>
            </CardContent>
          </Card>
        );

      case 'valorisation-stock':
        return (
          <div className="space-y-4">
            <div className="flex justify-end">
              <OfflineIndicator />
            </div>

            {/* Summary Cards */}
            <div className="grid grid-cols-4 gap-4">
              <Card>
                <CardContent className="p-4">
                  <p className="text-xs text-muted-foreground">Total Produits</p>
                  <p className="text-2xl font-bold">{stats.total}</p>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-4">
                  <p className="text-xs text-muted-foreground">En Stock</p>
                  <p className="text-2xl font-bold text-success">{stats.inStock}</p>
                </CardContent>
              </Card>
              <Card className="bg-primary/10 border-primary">
                <CardContent className="p-4">
                  <p className="text-xs text-muted-foreground">Valeur Coût</p>
                  <p className="text-2xl font-bold text-primary">{formatCurrency(stats.totalValue)}</p>
                </CardContent>
              </Card>
              <Card className="bg-success/10 border-success">
                <CardContent className="p-4">
                  <p className="text-xs text-muted-foreground">Valeur Vente</p>
                  <p className="text-2xl font-bold text-success">{formatCurrency(stats.totalSaleValue)}</p>
                </CardContent>
              </Card>
            </div>

            <Card>
              <CardHeader className="py-3">
                <CardTitle className="text-sm">Valorisation par Produit</CardTitle>
              </CardHeader>
              <CardContent className="p-0">
                <ScrollArea className="h-[400px]">
                  <Table>
                    <TableHeader className="sticky top-0 bg-background">
                      <TableRow>
                        <TableHead className="text-xs">Produit</TableHead>
                        <TableHead className="text-xs text-center">Quantité</TableHead>
                        <TableHead className="text-xs text-right">Prix Coût</TableHead>
                        <TableHead className="text-xs text-right">Valeur Coût</TableHead>
                        <TableHead className="text-xs text-right">Prix Vente</TableHead>
                        <TableHead className="text-xs text-right">Valeur Vente</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {products.filter(p => p.quantity > 0).map(product => (
                        <TableRow key={product.id} className="h-10">
                          <TableCell className="text-xs font-medium">{product.name}</TableCell>
                          <TableCell className="text-xs text-center">{product.quantity}</TableCell>
                          <TableCell className="text-xs text-right">
                            {formatCurrency(product.cost_price || 0)}
                          </TableCell>
                          <TableCell className="text-xs text-right font-medium">
                            {formatCurrency(product.quantity * (product.cost_price || product.unit_price))}
                          </TableCell>
                          <TableCell className="text-xs text-right">
                            {formatCurrency(product.unit_price)}
                          </TableCell>
                          <TableCell className="text-xs text-right font-medium text-success">
                            {formatCurrency(product.quantity * product.unit_price)}
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </ScrollArea>
              </CardContent>
            </Card>
          </div>
        );

      case 'inventaire-stock':
        const totalDifferences = inventoryCounts.filter(c => c.difference !== 0).length;
        
        return (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                <Input
                  placeholder="Rechercher..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-64 h-8"
                />
                <OfflineIndicator />
              </div>
              <div className="flex items-center gap-4">
                {totalDifferences > 0 && (
                  <span className="text-sm text-warning">
                    {totalDifferences} différence(s) détectée(s)
                  </span>
                )}
                <Button onClick={handleValidateInventory} disabled={isSaving || totalDifferences === 0}>
                  {isSaving ? <RefreshCw className="h-4 w-4 mr-2 animate-spin" /> : <Save className="h-4 w-4 mr-2" />}
                  Valider l'Inventaire
                </Button>
              </div>
            </div>

            <Card>
              <CardContent className="p-0">
                <ScrollArea className="h-[500px]">
                  <Table>
                    <TableHeader className="sticky top-0 bg-background">
                      <TableRow>
                        <TableHead className="text-xs">Produit</TableHead>
                        <TableHead className="text-xs text-center">Stock Système</TableHead>
                        <TableHead className="text-xs text-center w-32">Stock Physique</TableHead>
                        <TableHead className="text-xs text-center">Différence</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {inventoryCounts
                        .filter(c => !searchQuery || c.productName.toLowerCase().includes(searchQuery.toLowerCase()))
                        .map(count => (
                        <TableRow key={count.productId} className="h-12">
                          <TableCell className="text-xs font-medium">{count.productName}</TableCell>
                          <TableCell className="text-xs text-center">{count.systemStock}</TableCell>
                          <TableCell className="text-center">
                            <Input
                              type="number"
                              min={0}
                              value={count.physicalStock}
                              onChange={(e) => updatePhysicalStock(count.productId, parseInt(e.target.value) || 0)}
                              className="h-8 w-20 text-center mx-auto"
                            />
                          </TableCell>
                          <TableCell className={cn(
                            "text-xs text-center font-bold",
                            count.difference > 0 ? 'text-success' :
                            count.difference < 0 ? 'text-danger' : ''
                          )}>
                            {count.difference > 0 ? '+' : ''}{count.difference}
                          </TableCell>
                        </TableRow>
                      ))}
                      {inventoryCounts.length === 0 && (
                        <TableRow>
                          <TableCell colSpan={4} className="text-center text-muted-foreground py-8">
                            Aucun produit à inventorier
                          </TableCell>
                        </TableRow>
                      )}
                    </TableBody>
                  </Table>
                </ScrollArea>
              </CardContent>
            </Card>
          </div>
        );

      default:
        return <div className="text-center py-8 text-muted-foreground">Mode non reconnu</div>;
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-full">
        <RefreshCw className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="h-full overflow-auto p-4">
      {renderContent()}
    </div>
  );
}
