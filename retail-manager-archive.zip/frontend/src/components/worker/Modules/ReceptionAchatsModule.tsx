import { useState, useEffect } from 'react';
import { usePurchasingStore, PurchaseItem } from '@/stores/usePurchasingStore';
import { getDataClient } from '@/lib/dataClient';
import { OfflineAuthService } from '@/services/OfflineAuthService';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { toast } from 'sonner';
import { Package, Check, Plus } from 'lucide-react';

interface ReceptionAchatsModuleProps {
  storeId: string;
}

interface ReceiptItem {
  id: string;
  product_id: string;
  product_name: string;
  quantity_ordered: number;
  quantity_received: number;
  unit_cost: number;
}

export function ReceptionAchatsModule({ storeId }: ReceptionAchatsModuleProps) {
  const { suppliers, orders, orderItems, fetchSuppliers, fetchOrders, fetchOrderItems } = usePurchasingStore();
  const [selectedOrderId, setSelectedOrderId] = useState<string>('');
  const [receiptItems, setReceiptItems] = useState<ReceiptItem[]>([]);
  const [isAdHoc, setIsAdHoc] = useState(false);
  const [selectedSupplierId, setSelectedSupplierId] = useState<string>('');
  const [products, setProducts] = useState<{ id: string; name: string; cost_price: number }[]>([]);
  const [loading, setLoading] = useState(false);
  const { supabase, isLocalFirst, localBridgeBaseUrl } = getDataClient();

  const useLocalBridge = isLocalFirst;

  const localBridgeRequest = async <T,>(path: string, init: RequestInit = {}) => {
    if (!useLocalBridge) {
      throw new Error('LocalBridge mode is not enabled.');
    }
    const headers = await OfflineAuthService.getAuthHeaders();
    if (!headers) {
      throw new Error('LocalBridge session expired. Please sign in again.');
    }
    const response = await fetch(`${localBridgeBaseUrl}${path}`, {
      ...init,
      headers: {
        'Content-Type': 'application/json',
        ...(init.headers || {}),
        ...headers,
      },
    });
    let payload: any = null;
    if (response.status !== 204) {
      try {
        payload = await response.json();
      } catch (error) {
        // ignore
      }
    }
    if (!response.ok) {
      const message = payload?.message || 'LocalBridge request failed';
      throw new Error(message);
    }
    return payload as T;
  };

  useEffect(() => {
    if (storeId) {
      fetchSuppliers(storeId);
      fetchOrders(storeId, 'ordered');
      fetchProducts();
    }
  }, [storeId, useLocalBridge]);

  const fetchProducts = async () => {
    if (useLocalBridge) {
      const data = await localBridgeRequest<{ id: string; name: string; cost_price: number | null }[]>(
        `/rest/v1/products?${new URLSearchParams({ store_id: storeId }).toString()}`
      );
      setProducts(
        (data || []).map(item => ({
          id: item.id,
          name: item.name,
          cost_price: item.cost_price ?? 0,
        }))
      );
      return;
    }

    const { data } = await supabase
      .from('products')
      .select('id, name, cost_price')
      .eq('store_id', storeId)
      .eq('is_active', true)
      .order('name');
    setProducts(data || []);
  };

  useEffect(() => {
    if (selectedOrderId && !isAdHoc) {
      fetchOrderItems(selectedOrderId);
    }
  }, [selectedOrderId]);

  useEffect(() => {
    if (orderItems.length > 0 && !isAdHoc) {
      setReceiptItems(orderItems.map(item => ({
        id: item.id,
        product_id: item.product_id,
        product_name: item.product?.name || '',
        quantity_ordered: item.quantity_ordered,
        quantity_received: item.quantity_ordered, // Default to ordered qty
        unit_cost: item.unit_cost
      })));
    }
  }, [orderItems]);

  const handleQuantityChange = (id: string, value: number) => {
    setReceiptItems(items => 
      items.map(item => item.id === id ? { ...item, quantity_received: value } : item)
    );
  };

  const handleCostChange = (id: string, value: number) => {
    setReceiptItems(items => 
      items.map(item => item.id === id ? { ...item, unit_cost: value } : item)
    );
  };

  const addAdHocItem = (productId: string) => {
    const product = products.find(p => p.id === productId);
    if (!product) return;
    
    const existingItem = receiptItems.find(i => i.product_id === productId);
    if (existingItem) {
      toast.error('Produit déjà ajouté');
      return;
    }

    setReceiptItems([...receiptItems, {
      id: crypto.randomUUID(),
      product_id: productId,
      product_name: product.name,
      quantity_ordered: 0,
      quantity_received: 1,
      unit_cost: product.cost_price || 0
    }]);
  };

  const validateReceipt = async () => {
    if (receiptItems.length === 0) {
      toast.error('Aucun article à réceptionner');
      return;
    }

    setLoading(true);
    try {
      if (useLocalBridge && !isAdHoc) {
        await localBridgeRequest(`/rest/v1/purchase_orders/${selectedOrderId}/receive`, {
          method: 'POST',
          body: JSON.stringify(
            receiptItems.map(item => ({
              id: item.id,
              quantity_received: item.quantity_received,
              unit_cost: item.unit_cost,
            }))
          ),
        });
      } else if (useLocalBridge && isAdHoc) {
        const totalAmount = receiptItems.reduce((sum, item) => sum + (item.quantity_received * item.unit_cost), 0);
        if (!selectedSupplierId) {
          toast.error('Veuillez sélectionner un fournisseur');
          return;
        }
        const orderData = await localBridgeRequest<any>(`/rest/v1/purchase_orders`, {
          method: 'POST',
          body: JSON.stringify({
            store_id: storeId,
            supplier_id: selectedSupplierId,
            status: 'received',
            total_amount: totalAmount,
          }),
        });

        if (orderData) {
          for (const item of receiptItems) {
            await localBridgeRequest(`/rest/v1/purchase_items`, {
              method: 'POST',
              body: JSON.stringify({
                order_id: orderData.id,
                product_id: item.product_id,
                quantity_ordered: item.quantity_received,
                quantity_received: item.quantity_received,
                unit_cost: item.unit_cost,
              }),
            });
          }

          const createdItems = await localBridgeRequest<PurchaseItem[]>(
            `/rest/v1/purchase_items?${new URLSearchParams({ order_id: orderData.id }).toString()}`
          );
          await localBridgeRequest(`/rest/v1/purchase_orders/${orderData.id}/receive`, {
            method: 'POST',
            body: JSON.stringify(
              (createdItems || []).map(item => ({
                id: item.id,
                quantity_received: item.quantity_received,
                unit_cost: item.unit_cost,
              }))
            ),
          });
        }
      } else if (isAdHoc) {
        // Create new order for ad-hoc receipt
        const totalAmount = receiptItems.reduce((sum, item) => sum + (item.quantity_received * item.unit_cost), 0);
        
        // Cast as any - purchase_orders table may not be in types yet
        const { data: orderData } = await (supabase as any)
          .from('purchase_orders')
          .insert({
            store_id: storeId,
            supplier_id: selectedSupplierId,
            status: 'received',
            total_amount: totalAmount
          })
          .select()
          .single();

        if (orderData) {
          // Insert items - cast as any
          await (supabase as any).from('purchase_items').insert(
            receiptItems.map(item => ({
              order_id: orderData.id,
              product_id: item.product_id,
              quantity_ordered: item.quantity_received,
              quantity_received: item.quantity_received,
              unit_cost: item.unit_cost
            }))
          );

          // Update stock
          for (const item of receiptItems) {
            const { data: product } = await supabase
              .from('products')
              .select('quantity')
              .eq('id', item.product_id)
              .single();
            
            if (product) {
              await supabase
                .from('products')
                .update({ 
                  quantity: product.quantity + item.quantity_received,
                  cost_price: item.unit_cost
                })
                .eq('id', item.product_id);
            }
          }

          // Update supplier balance - cast as any
          const { data: supplierData } = await (supabase as any)
            .from('suppliers')
            .select('balance')
            .eq('id', selectedSupplierId)
            .single();
          
          if (supplierData) {
            await (supabase as any)
              .from('suppliers')
              .update({ balance: (supplierData.balance || 0) + totalAmount })
              .eq('id', selectedSupplierId);
          }
        }
      } else {
        // Update existing order - cast as any for purchase tables
        for (const item of receiptItems) {
          await (supabase as any)
            .from('purchase_items')
            .update({ quantity_received: item.quantity_received, unit_cost: item.unit_cost })
            .eq('id', item.id);

          // Update product stock
          const orderItem = orderItems.find(oi => oi.id === item.id);
          if (orderItem?.product) {
            await supabase
              .from('products')
              .update({ 
                quantity: orderItem.product.quantity + item.quantity_received,
                cost_price: item.unit_cost
              })
              .eq('id', item.product_id);
          }
        }

        // Update order status
        const allReceived = receiptItems.every(item => item.quantity_received >= item.quantity_ordered);
        await (supabase as any)
          .from('purchase_orders')
          .update({ status: allReceived ? 'received' : 'partial' })
          .eq('id', selectedOrderId);
      }

      toast.success('Réception validée avec succès');
      setReceiptItems([]);
      setSelectedOrderId('');
      setIsAdHoc(false);
      fetchOrders(storeId, 'ordered');
    } catch (error) {
      toast.error('Erreur lors de la validation');
    } finally {
      setLoading(false);
    }
  };

  const totalAmount = receiptItems.reduce((sum, item) => sum + (item.quantity_received * item.unit_cost), 0);

  return (
    <div className="h-full flex flex-col p-4 gap-4">
      <Card>
        <CardHeader className="py-3">
          <CardTitle className="text-base flex items-center gap-2">
            <Package className="h-4 w-4" />
            Réception des Marchandises
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex gap-4">
            <div className="flex-1">
              <label className="text-xs font-medium mb-1 block">Mode</label>
              <Select value={isAdHoc ? 'adhoc' : 'order'} onValueChange={(v) => {
                setIsAdHoc(v === 'adhoc');
                setReceiptItems([]);
                setSelectedOrderId('');
              }}>
                <SelectTrigger className="h-8">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="order">Commande existante</SelectItem>
                  <SelectItem value="adhoc">Achat direct</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {isAdHoc ? (
              <div className="flex-1">
                <label className="text-xs font-medium mb-1 block">Fournisseur</label>
                <Select value={selectedSupplierId} onValueChange={setSelectedSupplierId}>
                  <SelectTrigger className="h-8">
                    <SelectValue placeholder="Sélectionner..." />
                  </SelectTrigger>
                  <SelectContent>
                    {suppliers.map(s => (
                      <SelectItem key={s.id} value={s.id}>{s.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            ) : (
              <div className="flex-1">
                <label className="text-xs font-medium mb-1 block">Commande</label>
                <Select value={selectedOrderId} onValueChange={setSelectedOrderId}>
                  <SelectTrigger className="h-8">
                    <SelectValue placeholder="Sélectionner..." />
                  </SelectTrigger>
                  <SelectContent>
                    {orders.filter(o => o.status === 'ordered').map(o => (
                      <SelectItem key={o.id} value={o.id}>
                        {o.supplier?.name} - {new Date(o.created_at).toLocaleDateString('fr-FR')}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            )}
          </div>

          {isAdHoc && selectedSupplierId && (
            <div className="flex gap-2">
              <Select onValueChange={addAdHocItem}>
                <SelectTrigger className="h-8 flex-1">
                  <SelectValue placeholder="Ajouter un produit..." />
                </SelectTrigger>
                <SelectContent>
                  {products.map(p => (
                    <SelectItem key={p.id} value={p.id}>{p.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Button size="sm" variant="outline">
                <Plus className="h-4 w-4" />
              </Button>
            </div>
          )}
        </CardContent>
      </Card>

      <Card className="flex-1 overflow-hidden">
        <CardContent className="p-0 h-full">
          <div className="h-full overflow-auto">
            <Table>
              <TableHeader className="sticky top-0 bg-background">
                <TableRow>
                  <TableHead className="text-xs">Produit</TableHead>
                  <TableHead className="text-xs w-24 text-center">Commandé</TableHead>
                  <TableHead className="text-xs w-28 text-center">Reçu</TableHead>
                  <TableHead className="text-xs w-32 text-right">Coût Unit.</TableHead>
                  <TableHead className="text-xs w-28 text-right">Total</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {receiptItems.map(item => (
                  <TableRow key={item.id} className="h-10">
                    <TableCell className="text-sm font-medium">{item.product_name}</TableCell>
                    <TableCell className="text-center text-sm">{item.quantity_ordered}</TableCell>
                    <TableCell className="p-1">
                      <Input
                        type="number"
                        min={0}
                        value={item.quantity_received}
                        onChange={(e) => handleQuantityChange(item.id, parseInt(e.target.value) || 0)}
                        className="h-8 text-center"
                      />
                    </TableCell>
                    <TableCell className="p-1">
                      <Input
                        type="number"
                        min={0}
                        step={0.01}
                        value={item.unit_cost}
                        onChange={(e) => handleCostChange(item.id, parseFloat(e.target.value) || 0)}
                        className="h-8 text-right"
                      />
                    </TableCell>
                    <TableCell className="text-right text-sm font-medium">
                      {(item.quantity_received * item.unit_cost).toLocaleString('fr-FR')} F
                    </TableCell>
                  </TableRow>
                ))}
                {receiptItems.length === 0 && (
                  <TableRow>
                    <TableCell colSpan={5} className="text-center text-muted-foreground py-8">
                      {isAdHoc ? 'Ajoutez des produits à réceptionner' : 'Sélectionnez une commande'}
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      <div className="flex items-center justify-between bg-muted/50 rounded-lg p-4">
        <div className="text-lg font-bold">
          Total: {totalAmount.toLocaleString('fr-FR')} F CFA
        </div>
        <Button 
          onClick={validateReceipt} 
          disabled={loading || receiptItems.length === 0}
          className="gap-2"
        >
          <Check className="h-4 w-4" />
          Valider la Réception
        </Button>
      </div>
    </div>
  );
}
