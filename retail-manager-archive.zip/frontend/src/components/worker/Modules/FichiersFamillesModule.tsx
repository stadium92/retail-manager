import { useState, useEffect, useMemo } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Search, Plus, Edit2, Trash2, FolderTree, ChevronRight } from 'lucide-react';
import { getDataClient } from '@/lib/dataClient';
import { OfflineAuthService } from '@/services/OfflineAuthService';
import { useMasterDataStore, ProductFamily } from '@/stores/useMasterDataStore';
import { toast } from '@/hooks/use-toast';

interface FichiersFamillesModuleProps {
  storeId: string;
}

export function FichiersFamillesModule({ storeId }: FichiersFamillesModuleProps) {
  const { supabase, isLocalFirst, localBridgeBaseUrl } = getDataClient();
  const { families, setFamilies, deleteFamily, setLoading } = useMasterDataStore();
  const [searchQuery, setSearchQuery] = useState('');
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingFamily, setEditingFamily] = useState<ProductFamily | null>(null);
  const [isSaving, setIsSaving] = useState(false);
  const [deletingId, setDeletingId] = useState<string | null>(null);
  const [isFetching, setIsFetching] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    parent_id: '',
  });

  const useLocalBridge = isLocalFirst;

  const localBridgeRequest = async <T,>(path: string, init: RequestInit = {}) => {
    if (!useLocalBridge) {
      throw new Error('LocalBridge mode is not enabled.');
    }

    const headers = await OfflineAuthService.getAuthHeaders();
    if (!headers) {
      throw new Error('LocalBridge session expired. Please sign in again.');
    }

    const response = await fetch(`${localBridgeBaseUrl}${path}`, {
      ...init,
      headers: {
        'Content-Type': 'application/json',
        ...(init.headers || {}),
        ...headers,
      },
    });

    let payload: any = null;
    if (response.status !== 204) {
      try {
        payload = await response.json();
      } catch (error) {
        // ignore
      }
    }

    if (!response.ok) {
      const message = payload?.message || 'LocalBridge request failed';
      throw new Error(message);
    }

    return payload as T;
  };

  useEffect(() => {
    if (!storeId) {
      setFamilies([]);
      return;
    }
    fetchFamilies();
  }, [storeId, useLocalBridge]);

  const fetchFamilies = async () => {
    if (!storeId) return;
    setLoading(true);
    setIsFetching(true);
    try {
      if (useLocalBridge) {
        const params = new URLSearchParams();
        params.set('store_id', storeId);
        const data = await localBridgeRequest<ProductFamily[]>(`/rest/v1/product_families?${params.toString()}`);
        setFamilies(data || []);
        return;
      }

      const { data, error } = await supabase
        .from('product_families')
        .select('*')
        .eq('store_id', storeId)
        .order('name');

      if (error) {
        throw error;
      }

      setFamilies(data || []);
    } catch (error: any) {
      console.error('Failed to fetch product families', error);
      toast({ title: 'Erreur', description: error.message || 'Impossible de charger les familles', variant: 'destructive' });
    } finally {
      setLoading(false);
      setIsFetching(false);
    }
  };

  const filteredFamilies = useMemo(() => {
    return families.filter((f) =>
      f.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      f.description?.toLowerCase().includes(searchQuery.toLowerCase())
    );
  }, [families, searchQuery]);

  // Build hierarchy for display
  const parentFamilies = useMemo(() => families.filter((f) => !f.parent_id), [families]);
  
  const getChildren = (parentId: string) => families.filter((f) => f.parent_id === parentId);

  const handleSave = async () => {
    if (!formData.name.trim()) {
      toast({ title: 'Erreur', description: 'Le nom est requis', variant: 'destructive' });
      return;
    }
    if (!storeId) {
      toast({ title: 'Erreur', description: 'Aucun magasin sélectionné', variant: 'destructive' });
      return;
    }

    setIsSaving(true);
    const payload = {
      name: formData.name.trim(),
      description: formData.description.trim() || null,
      parent_id: formData.parent_id || null,
      store_id: storeId,
    };

    try {
      if (useLocalBridge) {
        if (editingFamily) {
          await localBridgeRequest(`/rest/v1/product_families/${editingFamily.id}`, {
            method: 'PATCH',
            body: JSON.stringify({
              name: payload.name,
              description: payload.description,
              parent_id: payload.parent_id,
            }),
          });
          toast({ title: 'Famille mise à jour' });
        } else {
          await localBridgeRequest(`/rest/v1/product_families`, {
            method: 'POST',
            body: JSON.stringify(payload),
          });
          toast({ title: 'Famille créée' });
        }
        await fetchFamilies();
        setIsDialogOpen(false);
        resetForm();
        return;
      }

      if (editingFamily) {
        const { error } = await supabase
          .from('product_families')
          .update(payload)
          .eq('id', editingFamily.id)
          .eq('store_id', storeId);

        if (error) throw error;
        toast({ title: 'Famille mise à jour' });
      } else {
        const { error } = await supabase
          .from('product_families')
          .insert(payload);

        if (error) throw error;
        toast({ title: 'Famille créée' });
      }

      await fetchFamilies();
      setIsDialogOpen(false);
      resetForm();
    } catch (error: any) {
      console.error('Failed to save family', error);
      toast({ title: 'Erreur', description: error.message || 'Impossible de sauvegarder la famille', variant: 'destructive' });
    } finally {
      setIsSaving(false);
    }
  };

  const handleEdit = (family: ProductFamily) => {
    setEditingFamily(family);
    setFormData({
      name: family.name,
      description: family.description || '',
      parent_id: family.parent_id || '',
    });
    setIsDialogOpen(true);
  };

  const handleDeleteFamily = async (id: string) => {
    if (!confirm('Supprimer cette famille ?')) return;
    setDeletingId(id);
    try {
      if (useLocalBridge) {
        await localBridgeRequest(`/rest/v1/product_families/${id}`, { method: 'DELETE' });
        deleteFamily(id);
        toast({ title: 'Famille supprimée' });
        return;
      }

      const { error } = await supabase
        .from('product_families')
        .delete()
        .eq('id', id)
        .eq('store_id', storeId);

      if (error) throw error;

      deleteFamily(id);
      toast({ title: 'Famille supprimée' });
    } catch (error: any) {
      console.error('Failed to delete family', error);
      toast({ title: 'Erreur', description: error.message || 'Suppression impossible', variant: 'destructive' });
    } finally {
      setDeletingId(null);
    }
  };

  const resetForm = () => {
    setEditingFamily(null);
    setFormData({ name: '', description: '', parent_id: '' });
  };

  // Render family row with indentation for children
  const renderFamilyRow = (family: ProductFamily, level: number = 0) => {
    const children = getChildren(family.id);
    return (
      <>
        <TableRow key={family.id}>
          <TableCell>
            <div className="flex items-center" style={{ paddingLeft: `${level * 24}px` }}>
              {level > 0 && <ChevronRight className="h-4 w-4 mr-1 text-muted-foreground" />}
              <FolderTree className="h-4 w-4 mr-2 text-primary" />
              <span className="font-medium">{family.name}</span>
            </div>
          </TableCell>
          <TableCell className="text-muted-foreground">{family.description || '-'}</TableCell>
          <TableCell className="text-center">
            <Badge variant="outline">{children.length} sous-familles</Badge>
          </TableCell>
          <TableCell className="text-center">
            <div className="flex justify-center gap-1">
              <Button variant="ghost" size="icon" onClick={() => handleEdit(family)}>
                <Edit2 className="h-4 w-4" />
              </Button>
              <Button
                variant="ghost"
                size="icon"
                onClick={() => handleDeleteFamily(family.id)}
                disabled={deletingId === family.id}
              >
                <Trash2 className="h-4 w-4 text-destructive" />
              </Button>
            </div>
          </TableCell>
        </TableRow>
        {children.map((child) => renderFamilyRow(child, level + 1))}
      </>
    );
  };

  return (
    <div className="h-full flex flex-col p-4 gap-4">
      {/* Header */}
      <div className="flex items-center gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Rechercher une famille..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-9"
          />
        </div>
        <Button onClick={() => { resetForm(); setIsDialogOpen(true); }}>
          <Plus className="h-4 w-4 mr-2" /> Nouvelle Famille
        </Button>
      </div>

      {/* Families Table */}
      <Card className="flex-1 overflow-hidden">
        <CardContent className="p-0 h-full overflow-auto">
          <Table>
            <TableHeader className="sticky top-0 bg-card z-10">
              <TableRow>
                <TableHead>Nom</TableHead>
                <TableHead>Description</TableHead>
                <TableHead className="text-center">Sous-familles</TableHead>
                <TableHead className="text-center">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {searchQuery
                ? filteredFamilies.map((f) => renderFamilyRow(f))
                : parentFamilies.map((f) => renderFamilyRow(f))}
              {!isFetching && (searchQuery ? filteredFamilies : parentFamilies).length === 0 && (
                <TableRow>
                  <TableCell colSpan={4} className="text-center py-8 text-muted-foreground">
                    <FolderTree className="h-12 w-12 mx-auto mb-2 opacity-50" />
                    Aucune famille trouvée
                  </TableCell>
                </TableRow>
              )}
              {isFetching && (
                <TableRow>
                  <TableCell colSpan={4} className="text-center py-8 text-muted-foreground">
                    Chargement des familles...
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* Family Dialog */}
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <FolderTree className="h-5 w-5" />
              {editingFamily ? 'Modifier la Famille' : 'Nouvelle Famille'}
            </DialogTitle>
          </DialogHeader>

          <div className="space-y-4 mt-4">
            <div className="space-y-2">
              <Label>Nom *</Label>
              <Input
                value={formData.name}
                onChange={(e) => setFormData((f) => ({ ...f, name: e.target.value }))}
                placeholder="Nom de la famille"
              />
            </div>

            <div className="space-y-2">
              <Label>Description</Label>
              <Input
                value={formData.description}
                onChange={(e) => setFormData((f) => ({ ...f, description: e.target.value }))}
                placeholder="Description optionnelle"
              />
            </div>

            <div className="space-y-2">
              <Label>Famille Parente</Label>
              <Select
                value={formData.parent_id || "none"}
                onValueChange={(v) => setFormData((f) => ({ ...f, parent_id: v === "none" ? "" : v }))}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Aucune (racine)" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">Aucune (racine)</SelectItem>
                  {families
                    .filter((f) => f.id !== editingFamily?.id)
                    .map((f) => (
                      <SelectItem key={f.id} value={f.id}>{f.name}</SelectItem>
                    ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="flex justify-end gap-2 mt-6">
            <Button variant="outline" onClick={() => setIsDialogOpen(false)}>Annuler</Button>
            <Button onClick={handleSave} disabled={isSaving}>
              {isSaving ? 'Enregistrement...' : editingFamily ? 'Enregistrer' : 'Créer'}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
