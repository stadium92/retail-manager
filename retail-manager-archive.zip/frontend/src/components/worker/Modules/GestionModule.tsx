import { useState, useEffect, useMemo } from 'react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { 
  DollarSign, TrendingUp, Package, AlertTriangle, ShoppingCart,
  CreditCard, ArrowDownCircle, ArrowUpCircle, Save, Trash2, BarChart3,
  WifiOff, RefreshCw
} from 'lucide-react';
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  PieChart, Pie, Cell, Legend
} from 'recharts';
import { format, subDays, startOfDay } from 'date-fns';
import { fr } from 'date-fns/locale';
import { cn } from '@/lib/utils';
import { toast } from 'sonner';
import { OfflineDataService, SaleWithItems } from '@/services/OfflineDataService';
import { useMasterDataStore } from '@/stores/useMasterDataStore';
import { LocalDatabase } from '@/services/LocalDatabase';

interface GestionModuleProps {
  storeId: string;
  mode: 'consultation-caisse' | 'journal-caisse' | 'tableau-bord' | 'statistiques' | 'sorties-pertes';
}

interface CashEntry {
  id: string;
  type: 'in' | 'out';
  description: string;
  amount: number;
  date: string;
  category: string;
}

interface Product {
  id: string;
  name: string;
  quantity: number;
  unit_price: number;
  category: string | null;
}

const CHART_COLORS = ['#00D9FF', '#FF00FF', '#00FF66', '#FFD700', '#FF6B6B'];

const formatCurrency = (amount: number) => amount.toLocaleString('fr-FR') + ' F';

// Generate mock data for demo
const generateMockWeeklyRevenue = () => {
  const days = [];
  for (let i = 6; i >= 0; i--) {
    const date = subDays(new Date(), i);
    days.push({
      date: format(date, 'EEE', { locale: fr }),
      revenue: Math.floor(Math.random() * 500000) + 100000,
    });
  }
  return days;
};

export function GestionModule({ storeId, mode }: GestionModuleProps) {
  const [cashEntries, setCashEntries] = useState<CashEntry[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [sales, setSales] = useState<SaleWithItems[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isOffline, setIsOffline] = useState(!navigator.onLine);

  // Get products from Zustand store for offline access
  const storeProducts = useMasterDataStore(state => state.products);

  // Loss form state
  const [lossForm, setLossForm] = useState({
    productId: '',
    quantity: 1,
    reason: 'expired' as 'expired' | 'broken' | 'theft' | 'other',
    notes: '',
  });

  // Listen for online/offline changes
  useEffect(() => {
    const handleOnline = () => setIsOffline(false);
    const handleOffline = () => setIsOffline(true);
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  // Fetch data - uses local sources
  useEffect(() => {
    const fetchData = async () => {
      if (!storeId) return;
      setIsLoading(true);

      try {
        // Get products from Zustand store (offline-capable)
        const offlineProducts = storeProducts
          .filter(p => p.store_id === storeId)
          .map(p => ({
            id: p.id,
            name: p.name,
            quantity: p.current_stock,
            unit_price: p.selling_price_detail || 0,
            category: p.family_id || null,
          }));
        setProducts(offlineProducts);

        // Get today's sales from OfflineDataService
        const today = startOfDay(new Date());
        const salesData = await OfflineDataService.getSales(storeId, today);
        setSales(salesData);

        // Build cash entries from local sales
        const entries: CashEntry[] = [];
        
        // Sales as income
        salesData.forEach(sale => {
          entries.push({
            id: sale.id,
            type: 'in',
            description: `Vente ${sale.invoice_number || sale.id.slice(0, 8)}`,
            amount: sale.total_price,
            date: sale.created_at,
            category: 'Vente',
          });
        });

        // Get supplier payments if online
        if (navigator.onLine) {
          const payments = await OfflineDataService.getSupplierPayments(storeId, today);
          payments.forEach(payment => {
            entries.push({
              id: payment.id,
              type: 'out',
              description: `Paiement ${payment.supplier_name}`,
              amount: payment.amount,
              date: payment.date,
              category: 'Paiement Fournisseur',
            });
          });
        }

        setCashEntries(entries.sort((a, b) => 
          new Date(b.date).getTime() - new Date(a.date).getTime()
        ));
      } catch (error) {
        console.error('Error fetching data:', error);
        toast.error('Erreur lors du chargement des données');
      }

      setIsLoading(false);
    };

    fetchData();
  }, [storeId, storeProducts]);

  // Calculate KPIs
  const kpis = useMemo(() => {
    const totalRevenue = cashEntries
      .filter(e => e.type === 'in')
      .reduce((sum, e) => sum + e.amount, 0);
    const totalExpenses = cashEntries
      .filter(e => e.type === 'out')
      .reduce((sum, e) => sum + e.amount, 0);
    const netCash = totalRevenue - totalExpenses;
    const orderCount = sales.length;
    const lowStockCount = products.filter(p => p.quantity < 10).length;
    
    // Estimate profit (30% margin)
    const estimatedProfit = totalRevenue * 0.3;

    return { totalRevenue, totalExpenses, netCash, orderCount, lowStockCount, estimatedProfit };
  }, [cashEntries, sales, products]);

  // Category breakdown for pie chart
  const categoryData = useMemo(() => {
    const categories: Record<string, number> = {};
    sales.forEach(sale => {
      (sale.sale_items || []).forEach((item) => {
        const cat = item.product_name?.split(' ')[0] || 'Autre';
        categories[cat] = (categories[cat] || 0) + item.total;
      });
    });
    return Object.entries(categories)
      .map(([name, value]) => ({ name, value }))
      .sort((a, b) => b.value - a.value)
      .slice(0, 5);
  }, [sales]);

  // Weekly revenue data
  const weeklyRevenue = useMemo(() => generateMockWeeklyRevenue(), []);

  // Top selling products
  const topProducts = useMemo(() => {
    const productSales: Record<string, { name: string; qty: number; revenue: number }> = {};
    sales.forEach(sale => {
      (sale.sale_items || []).forEach((item) => {
        if (!productSales[item.product_name]) {
          productSales[item.product_name] = { name: item.product_name, qty: 0, revenue: 0 };
        }
        productSales[item.product_name].qty += item.quantity;
        productSales[item.product_name].revenue += item.total;
      });
    });
    return Object.values(productSales).sort((a, b) => b.revenue - a.revenue).slice(0, 10);
  }, [sales]);

  // Handle loss recording - works offline
  const handleRecordLoss = async () => {
    if (!lossForm.productId || lossForm.quantity <= 0) {
      toast.error('Veuillez remplir tous les champs');
      return;
    }

    const product = products.find(p => p.id === lossForm.productId);
    if (!product) return;

    try {
      const newQuantity = Math.max(0, product.quantity - lossForm.quantity);
      
      // Update locally via OfflineDataService
      await OfflineDataService.updateProductStock(lossForm.productId, newQuantity, `Perte: ${lossForm.reason}`);
      
      // Update local state
      setProducts(prev => prev.map(p => 
        p.id === lossForm.productId ? { ...p, quantity: newQuantity } : p
      ));

      toast.success(`${lossForm.quantity} x ${product.name} retirés du stock`);
      setLossForm({ productId: '', quantity: 1, reason: 'expired', notes: '' });
    } catch (error) {
      toast.error('Erreur lors de l\'enregistrement');
    }
  };

  // Offline indicator
  const OfflineIndicator = () => isOffline ? (
    <div className="flex items-center gap-2 px-3 py-1 rounded-full bg-warning/20 text-warning text-xs">
      <WifiOff className="h-3 w-3" />
      <span>Mode hors ligne</span>
    </div>
  ) : null;

  const renderContent = () => {
    switch (mode) {
      case 'consultation-caisse':
      case 'journal-caisse':
        return (
          <div className="space-y-4">
            {/* Header with offline indicator */}
            <div className="flex justify-end">
              <OfflineIndicator />
            </div>

            {/* Summary Cards */}
            <div className="grid grid-cols-3 gap-4">
              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center gap-3">
                    <div className="p-2 rounded-lg bg-success/20">
                      <ArrowDownCircle className="h-5 w-5 text-success" />
                    </div>
                    <div>
                      <p className="text-xs text-muted-foreground">Entrées</p>
                      <p className="text-lg font-bold text-success">{formatCurrency(kpis.totalRevenue)}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center gap-3">
                    <div className="p-2 rounded-lg bg-danger/20">
                      <ArrowUpCircle className="h-5 w-5 text-danger" />
                    </div>
                    <div>
                      <p className="text-xs text-muted-foreground">Sorties</p>
                      <p className="text-lg font-bold text-danger">{formatCurrency(kpis.totalExpenses)}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
              <Card className="bg-primary/10 border-primary">
                <CardContent className="p-4">
                  <div className="flex items-center gap-3">
                    <div className="p-2 rounded-lg bg-primary/20">
                      <DollarSign className="h-5 w-5 text-primary" />
                    </div>
                    <div>
                      <p className="text-xs text-muted-foreground">Solde Caisse</p>
                      <p className="text-lg font-bold text-primary">{formatCurrency(kpis.netCash)}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Journal Table */}
            <Card>
              <CardHeader className="py-3">
                <CardTitle className="text-sm">Journal de Caisse - {format(new Date(), 'dd/MM/yyyy', { locale: fr })}</CardTitle>
              </CardHeader>
              <CardContent className="p-0">
                <ScrollArea className="h-[350px]">
                  <Table>
                    <TableHeader className="sticky top-0 bg-background">
                      <TableRow>
                        <TableHead className="text-xs">Heure</TableHead>
                        <TableHead className="text-xs">Description</TableHead>
                        <TableHead className="text-xs">Catégorie</TableHead>
                        <TableHead className="text-xs text-right">Entrée</TableHead>
                        <TableHead className="text-xs text-right">Sortie</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {cashEntries.map(entry => (
                        <TableRow key={entry.id} className="h-9">
                          <TableCell className="text-xs">
                            {format(new Date(entry.date), 'HH:mm', { locale: fr })}
                          </TableCell>
                          <TableCell className="text-xs font-medium">{entry.description}</TableCell>
                          <TableCell className="text-xs">{entry.category}</TableCell>
                          <TableCell className="text-xs text-right text-success">
                            {entry.type === 'in' ? formatCurrency(entry.amount) : '—'}
                          </TableCell>
                          <TableCell className="text-xs text-right text-danger">
                            {entry.type === 'out' ? formatCurrency(entry.amount) : '—'}
                          </TableCell>
                        </TableRow>
                      ))}
                      {cashEntries.length === 0 && (
                        <TableRow>
                          <TableCell colSpan={5} className="text-center text-muted-foreground py-8">
                            Aucune transaction aujourd'hui
                          </TableCell>
                        </TableRow>
                      )}
                    </TableBody>
                  </Table>
                </ScrollArea>
              </CardContent>
            </Card>
          </div>
        );

      case 'tableau-bord':
        return (
          <div className="space-y-4">
            {/* Header with offline indicator */}
            <div className="flex justify-end">
              <OfflineIndicator />
            </div>

            {/* KPI Cards */}
            <div className="grid grid-cols-4 gap-4">
              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center gap-3">
                    <div className="p-2 rounded-lg bg-primary/20">
                      <DollarSign className="h-5 w-5 text-primary" />
                    </div>
                    <div>
                      <p className="text-xs text-muted-foreground">CA Jour</p>
                      <p className="text-lg font-bold">{formatCurrency(kpis.totalRevenue)}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center gap-3">
                    <div className="p-2 rounded-lg bg-success/20">
                      <TrendingUp className="h-5 w-5 text-success" />
                    </div>
                    <div>
                      <p className="text-xs text-muted-foreground">Profit Est.</p>
                      <p className="text-lg font-bold text-success">{formatCurrency(kpis.estimatedProfit)}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center gap-3">
                    <div className="p-2 rounded-lg bg-accent/20">
                      <ShoppingCart className="h-5 w-5 text-accent-foreground" />
                    </div>
                    <div>
                      <p className="text-xs text-muted-foreground">Commandes</p>
                      <p className="text-lg font-bold">{kpis.orderCount}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center gap-3">
                    <div className="p-2 rounded-lg bg-warning/20">
                      <AlertTriangle className="h-5 w-5 text-warning" />
                    </div>
                    <div>
                      <p className="text-xs text-muted-foreground">Stock Bas</p>
                      <p className="text-lg font-bold text-warning">{kpis.lowStockCount}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Charts */}
            <div className="grid grid-cols-2 gap-4">
              <Card>
                <CardHeader className="py-3">
                  <CardTitle className="text-sm flex items-center gap-2">
                    <BarChart3 className="h-4 w-4" />
                    CA 7 derniers jours
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={200}>
                    <BarChart data={weeklyRevenue}>
                      <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                      <XAxis dataKey="date" className="text-xs" />
                      <YAxis className="text-xs" tickFormatter={(v) => `${(v/1000).toFixed(0)}k`} />
                      <Tooltip 
                        formatter={(value: number) => formatCurrency(value)}
                        labelStyle={{ color: 'hsl(var(--foreground))' }}
                        contentStyle={{ 
                          backgroundColor: 'hsl(var(--background))', 
                          border: '1px solid hsl(var(--border))' 
                        }}
                      />
                      <Bar dataKey="revenue" fill="hsl(var(--primary))" radius={[4, 4, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="py-3">
                  <CardTitle className="text-sm">Top 5 Catégories</CardTitle>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={200}>
                    <PieChart>
                      <Pie
                        data={categoryData}
                        cx="50%"
                        cy="50%"
                        innerRadius={40}
                        outerRadius={70}
                        paddingAngle={2}
                        dataKey="value"
                      >
                        {categoryData.map((_, index) => (
                          <Cell key={`cell-${index}`} fill={CHART_COLORS[index % CHART_COLORS.length]} />
                        ))}
                      </Pie>
                      <Legend 
                        formatter={(value) => <span className="text-xs">{value}</span>}
                      />
                      <Tooltip formatter={(value: number) => formatCurrency(value)} />
                    </PieChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
            </div>
          </div>
        );

      case 'statistiques':
        return (
          <div className="space-y-4">
            {/* Header with offline indicator */}
            <div className="flex justify-end">
              <OfflineIndicator />
            </div>

            <Card>
              <CardHeader className="py-3">
                <CardTitle className="text-sm">Top 10 Produits Vendus</CardTitle>
              </CardHeader>
              <CardContent className="p-0">
                <ScrollArea className="h-[400px]">
                  <Table>
                    <TableHeader className="sticky top-0 bg-background">
                      <TableRow>
                        <TableHead className="text-xs">#</TableHead>
                        <TableHead className="text-xs">Produit</TableHead>
                        <TableHead className="text-xs text-center">Quantité</TableHead>
                        <TableHead className="text-xs text-right">Chiffre d'Affaires</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {topProducts.map((product, idx) => (
                        <TableRow key={product.name} className="h-10">
                          <TableCell className="text-xs font-bold text-primary">{idx + 1}</TableCell>
                          <TableCell className="text-xs font-medium">{product.name}</TableCell>
                          <TableCell className="text-xs text-center">{product.qty}</TableCell>
                          <TableCell className="text-xs text-right font-medium">
                            {formatCurrency(product.revenue)}
                          </TableCell>
                        </TableRow>
                      ))}
                      {topProducts.length === 0 && (
                        <TableRow>
                          <TableCell colSpan={4} className="text-center text-muted-foreground py-8">
                            Aucune vente enregistrée
                          </TableCell>
                        </TableRow>
                      )}
                    </TableBody>
                  </Table>
                </ScrollArea>
              </CardContent>
            </Card>
          </div>
        );

      case 'sorties-pertes':
        return (
          <div className="space-y-4">
            {/* Header with offline indicator */}
            <div className="flex justify-end">
              <OfflineIndicator />
            </div>

            <Card>
              <CardHeader className="py-3">
                <CardTitle className="text-sm flex items-center gap-2">
                  <Trash2 className="h-4 w-4" />
                  Enregistrer une Perte / Sortie
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label className="text-xs">Produit</Label>
                    <Select 
                      value={lossForm.productId} 
                      onValueChange={(v) => setLossForm(f => ({ ...f, productId: v }))}
                    >
                      <SelectTrigger className="h-9">
                        <SelectValue placeholder="Sélectionner un produit" />
                      </SelectTrigger>
                      <SelectContent>
                        {products.map(p => (
                          <SelectItem key={p.id} value={p.id}>
                            {p.name} (Stock: {p.quantity})
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label className="text-xs">Quantité</Label>
                    <Input
                      type="number"
                      min={1}
                      value={lossForm.quantity}
                      onChange={(e) => setLossForm(f => ({ ...f, quantity: parseInt(e.target.value) || 0 }))}
                      className="h-9"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label className="text-xs">Raison</Label>
                  <Select 
                    value={lossForm.reason} 
                    onValueChange={(v: 'expired' | 'broken' | 'theft' | 'other') => setLossForm(f => ({ ...f, reason: v }))}
                  >
                    <SelectTrigger className="h-9">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="expired">Périmé</SelectItem>
                      <SelectItem value="broken">Cassé / Endommagé</SelectItem>
                      <SelectItem value="theft">Vol</SelectItem>
                      <SelectItem value="other">Autre</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label className="text-xs">Notes (optionnel)</Label>
                  <Textarea
                    value={lossForm.notes}
                    onChange={(e) => setLossForm(f => ({ ...f, notes: e.target.value }))}
                    placeholder="Détails supplémentaires..."
                    rows={3}
                  />
                </div>

                <Button onClick={handleRecordLoss} className="w-full">
                  <Save className="h-4 w-4 mr-2" />
                  Enregistrer la Perte
                </Button>
              </CardContent>
            </Card>

            {/* Low stock warning */}
            {kpis.lowStockCount > 0 && (
              <Card className="border-warning">
                <CardHeader className="py-3">
                  <CardTitle className="text-sm flex items-center gap-2 text-warning">
                    <AlertTriangle className="h-4 w-4" />
                    Produits en Stock Bas ({kpis.lowStockCount})
                  </CardTitle>
                </CardHeader>
                <CardContent className="p-0">
                  <ScrollArea className="h-[200px]">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead className="text-xs">Produit</TableHead>
                          <TableHead className="text-xs text-right">Stock Actuel</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {products.filter(p => p.quantity < 10).map(p => (
                          <TableRow key={p.id} className="h-9">
                            <TableCell className="text-xs font-medium">{p.name}</TableCell>
                            <TableCell className="text-xs text-right text-warning font-bold">
                              {p.quantity}
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </ScrollArea>
                </CardContent>
              </Card>
            )}
          </div>
        );

      default:
        return <div className="text-center py-8 text-muted-foreground">Mode non reconnu</div>;
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-full">
        <RefreshCw className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="h-full overflow-auto p-4">
      {renderContent()}
    </div>
  );
}
