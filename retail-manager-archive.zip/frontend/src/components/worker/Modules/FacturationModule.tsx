import { useState, useEffect, useCallback } from 'react';
import { usePOSStore, CartItem } from '@/stores/usePOSStore';
import { POSGrid } from '@/components/pos/POSGrid';
import { POSCommandBar } from '@/components/pos/POSCommandBar';
import { POSSidebar } from '@/components/pos/POSSidebar';
import { POSTotals } from '@/components/pos/POSTotals';
import { BarcodeScanner } from '@/components/shared/BarcodeScanner';
import { Product } from '@/types';
import { supabase } from '@/integrations/supabase/client';
import { SalesService } from '@/services/SalesService';
import { toast } from '@/hooks/use-toast';
import { useAuth } from '@/contexts/AuthContext';

interface FacturationModuleProps {
  storeId: string;
  mode: 'vente-detail' | 'facturation-detail' | 'facturation-gros';
}

const modeLabels = {
  'vente-detail': 'Vente au Détail',
  'facturation-detail': 'Facturation au Détail',
  'facturation-gros': 'Facturation en Gros',
};

// Map Product to InventoryItem format for POS components
const mapProductToInventoryItem = (product: Product) => ({
  id: product.id,
  name: product.name,
  description: product.description,
  sku: product.sku,
  price: product.unit_price,
  unit_price: product.unit_price,
  cost: product.cost_price,
  cost_price: product.cost_price,
  quantity: product.quantity,
  low_stock_threshold: product.min_quantity,
  min_quantity: product.min_quantity,
  category_id: undefined,
  store_id: product.store_id,
  image_url: product.image_url,
  created_at: product.created_at,
  updated_at: product.updated_at,
});

export function FacturationModule({ storeId, mode }: FacturationModuleProps) {
  const { user } = useAuth();
  const { 
    cart, 
    addToCart, 
    clearCart,
    completeTransaction,
    setCommandOpen,
  } = usePOSStore();
  
  const [products, setProducts] = useState<ReturnType<typeof mapProductToInventoryItem>[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isScanning, setIsScanning] = useState(false);
  const [selectedItem, setSelectedItem] = useState<CartItem | null>(null);

  // Fetch products from products table
  useEffect(() => {
    const fetchProducts = async () => {
      if (!storeId) return;
      setIsLoading(true);
      const { data } = await supabase
        .from('products')
        .select('*')
        .eq('store_id', storeId)
        .order('name');
      if (data) {
        // Map products to expected format
        const mappedProducts = data.map((item) => ({
          id: item.id,
          store_id: item.store_id,
          name: item.name,
          description: item.description,
          sku: item.sku,
          unit_price: Number(item.unit_price) || 0,
          cost_price: Number(item.cost_price) || 0,
          quantity: item.quantity,
          min_quantity: item.min_quantity,
          image_url: item.image_url,
          created_at: item.created_at,
          updated_at: item.updated_at,
        }));
        setProducts(mappedProducts.map(mapProductToInventoryItem));
      }
      setIsLoading(false);
    };
    fetchProducts();
  }, [storeId]);

  // Keyboard shortcuts
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Don't capture if in input
      if (e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement) {
        return;
      }

      if (e.key === 'F2' && !e.ctrlKey && !e.metaKey) {
        // F2 is handled globally for module switching
        return;
      }
      
      if (e.key === 'F4') {
        e.preventDefault();
        if (cart.length > 0) handlePayment();
      } else if (e.key === 'F5') {
        e.preventDefault();
        setIsScanning(true);
      } else if (e.key === 'Escape') {
        setIsScanning(false);
      }
    };
    
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [cart]);

  const handleScanResult = useCallback((result: string) => {
    const product = products.find(p => 
      p.sku?.toLowerCase() === result.toLowerCase() ||
      p.name.toLowerCase().includes(result.toLowerCase())
    );
    
    if (product) {
      addToCart(product);
      toast({ title: 'Produit ajouté', description: product.name });
    } else {
      toast({ 
        title: 'Produit non trouvé', 
        description: `Code: ${result}`, 
        variant: 'destructive' 
      });
    }
    setIsScanning(false);
  }, [products, addToCart]);

  const handlePayment = async () => {
    const transaction = completeTransaction('cash');
    if (!transaction) return;

    // Create sale with items using the new schema
    const saleData = {
      store_id: storeId,
      worker_id: user?.id,
      customer_name: transaction.customerName,
      customer_phone: transaction.customerPhone,
      sale_type: 'detail' as const,
      total_price: transaction.grandTotal,
      payment_method: 'cash',
      payment_status: 'paid' as const,
    };

    const saleItems = transaction.items.map(item => ({
      product_id: item.product.id,
      product_name: item.product.name,
      quantity: item.quantity,
      unit_price: item.unitPrice,
      total: item.lineTotal,
    }));

    const { error } = await SalesService.createSaleWithItems(saleData, saleItems);
    
    if (error) {
      toast({ 
        title: 'Erreur', 
        description: 'Échec de l\'enregistrement de la vente',
        variant: 'destructive',
      });
      return;
    }
    
    toast({ 
      title: 'Vente enregistrée', 
      description: `Total: ${transaction.grandTotal.toLocaleString('fr-FR')} XAF` 
    });
  };

  return (
    <div className="h-full flex flex-col p-4 bg-[hsl(60,80%,85%)] dark:bg-transparent">
      {/* Mode indicator */}
      <div className="mb-3 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <span className="px-3 py-1 bg-primary/20 text-primary rounded-lg text-sm font-medium">
            {modeLabels[mode]}
          </span>
          <span className="text-xs text-muted-foreground">
            F4: Payer • F5: Scanner • Cmd+K: Recherche
          </span>
        </div>
        <div className="text-sm text-muted-foreground">
          {cart.length} article(s)
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex gap-4 overflow-hidden">
        {/* Left: Grid + Totals */}
        <div className="flex-1 flex flex-col gap-3 min-w-0">
          <POSGrid onRowSelect={setSelectedItem} />
          <POSTotals 
            onPayment={handlePayment} 
            onScan={() => setIsScanning(true)} 
            onClear={clearCart}
          />
        </div>

        {/* Right: Sidebar */}
        <POSSidebar selectedItem={selectedItem} className="w-72 shrink-0" />
      </div>

      {/* Command Bar */}
      <POSCommandBar products={products} isLoading={isLoading} />
      
      {/* Barcode Scanner */}
      <BarcodeScanner 
        isScanning={isScanning} 
        onResult={handleScanResult} 
        onClose={() => setIsScanning(false)} 
      />
    </div>
  );
}
