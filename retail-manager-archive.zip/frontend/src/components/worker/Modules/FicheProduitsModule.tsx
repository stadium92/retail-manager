import { useState, useEffect } from 'react';
import { getDataClient } from '@/lib/dataClient';
import { OfflineAuthService } from '@/services/OfflineAuthService';
import { Product } from '@/types';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { 
  ChevronLeft, 
  ChevronRight, 
  Save,
  Search,
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { toast } from '@/hooks/use-toast';

interface FicheProduitsModuleProps {
  storeId: string;
}

export function FicheProduitsModule({ storeId }: FicheProduitsModuleProps) {
  const [products, setProducts] = useState<Product[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isLoading, setIsLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const { supabase, isLocalFirst, localBridgeBaseUrl } = getDataClient();

  // Current product for editing
  const currentProduct = products[currentIndex];

  const useLocalBridge = isLocalFirst;

  const localBridgeRequest = async <T,>(path: string, init: RequestInit = {}) => {
    if (!useLocalBridge) {
      throw new Error('LocalBridge mode is not enabled.');
    }

    const headers = await OfflineAuthService.getAuthHeaders();
    if (!headers) {
      throw new Error('LocalBridge session expired. Please sign in again.');
    }

    const response = await fetch(`${localBridgeBaseUrl}${path}`, {
      ...init,
      headers: {
        'Content-Type': 'application/json',
        ...(init.headers || {}),
        ...headers,
      },
    });

    let payload: any = null;
    if (response.status !== 204) {
      try {
        payload = await response.json();
      } catch (error) {
        // ignore
      }
    }

    if (!response.ok) {
      const message = payload?.message || 'LocalBridge request failed';
      throw new Error(message);
    }

    return payload as T;
  };

  useEffect(() => {
    const fetchProducts = async () => {
      if (!storeId) return;
      setIsLoading(true);

      try {
        if (useLocalBridge) {
          const params = new URLSearchParams();
          params.set('store_id', storeId);
          const data = await localBridgeRequest<Product[]>(`/rest/v1/products?${params.toString()}`);
          setProducts(data || []);
          return;
        }

        const { data } = await supabase
          .from('products')
          .select('*')
          .eq('store_id', storeId)
          .order('name');
        
        if (data) {
          // Map products to Product interface
          const mappedProducts: Product[] = data.map(item => ({
            id: item.id,
            store_id: item.store_id,
            name: item.name,
            description: item.description,
            sku: item.sku,
            unit_price: Number(item.unit_price) || 0,
            cost_price: Number(item.cost_price) || 0,
            quantity: item.quantity,
            min_quantity: item.min_quantity,
            image_url: item.image_url,
            created_at: item.created_at,
            updated_at: item.updated_at,
          }));
          setProducts(mappedProducts);
        }
      } catch (error) {
        console.error('Failed to load products', error);
        toast({ title: 'Erreur', description: 'Impossible de charger les produits', variant: 'destructive' });
      } finally {
        setIsLoading(false);
      }
    };
    
    fetchProducts();
  }, [storeId, useLocalBridge]);

  const goToNext = () => {
    if (currentIndex < products.length - 1) {
      setCurrentIndex(currentIndex + 1);
    }
  };

  const goToPrevious = () => {
    if (currentIndex > 0) {
      setCurrentIndex(currentIndex - 1);
    }
  };

  const handleSearch = () => {
    const index = products.findIndex(p => 
      p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.sku?.toLowerCase().includes(searchQuery.toLowerCase())
    );
    if (index >= 0) {
      setCurrentIndex(index);
    } else {
      toast({ title: 'Produit non trouvé', variant: 'destructive' });
    }
  };

  const getStockStatus = (quantity: number, threshold: number = 10) => {
    if (quantity <= 0) return 'rupture';
    if (quantity <= threshold) return 'low';
    return 'ok';
  };

  if (isLoading) {
    return (
      <div className="h-full flex items-center justify-center">
        <div className="text-muted-foreground">Chargement...</div>
      </div>
    );
  }

  if (!currentProduct) {
    return (
      <div className="h-full flex items-center justify-center">
        <div className="text-muted-foreground">Aucun produit trouvé</div>
      </div>
    );
  }

  const stockStatus = getStockStatus(currentProduct.quantity, currentProduct.min_quantity);

  return (
    <div className="h-full flex flex-col p-4 bg-[hsl(60,80%,85%)] dark:bg-transparent">
      {/* Header with navigation */}
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <Input
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
            placeholder="Rechercher..."
            className="w-48 h-8"
          />
          <Button variant="outline" size="sm" onClick={handleSearch}>
            <Search className="h-4 w-4" />
          </Button>
        </div>
        
        <div className="flex items-center gap-2">
          <Button 
            variant="outline" 
            size="sm"
            onClick={goToPrevious}
            disabled={currentIndex === 0}
          >
            <ChevronLeft className="h-4 w-4" />
          </Button>
          <span className="text-sm font-medium px-3">
            {currentIndex + 1} / {products.length} Fiches
          </span>
          <Button 
            variant="outline" 
            size="sm"
            onClick={goToNext}
            disabled={currentIndex >= products.length - 1}
          >
            <ChevronRight className="h-4 w-4" />
          </Button>
        </div>
      </div>

      {/* Product Form - Sanifere Style */}
      <ScrollArea className="flex-1">
        <div className="glass-card p-4 space-y-4">
          {/* Row 1: Designation, Ref, Prix */}
          <div className="grid grid-cols-[1fr_120px_150px] gap-4 items-end">
            <div>
              <Label className="text-xs uppercase text-muted-foreground">Désignation</Label>
              <Input 
                value={currentProduct.name} 
                className="h-9 bg-success/20 font-medium"
                readOnly
              />
            </div>
            <div>
              <Label className="text-xs uppercase text-muted-foreground">REF.</Label>
              <Input 
                value={currentProduct.sku || ''} 
                className="h-9 bg-success/20"
                readOnly
              />
            </div>
            <div>
              <Label className="text-xs uppercase text-muted-foreground">Prix VENTE</Label>
              <Input 
                value={(currentProduct.unit_price || 0).toLocaleString('fr-FR')} 
                className="h-9 bg-[hsl(180,60%,70%)] text-right font-bold"
                readOnly
              />
            </div>
          </div>

          {/* Row 2: Code Barre, CDNT, Unite, Marque */}
          <div className="grid grid-cols-[1fr_80px_100px_1fr] gap-4 items-end">
            <div>
              <Label className="text-xs uppercase text-muted-foreground">Code Barre</Label>
              <Input 
                value={currentProduct.sku || ''} 
                className="h-9 bg-success/20"
                readOnly
              />
            </div>
            <div>
              <Label className="text-xs uppercase text-muted-foreground">CDNT.</Label>
              <Input 
                value="1" 
                className="h-9 bg-success/20 text-center"
                readOnly
              />
            </div>
            <div>
              <Label className="text-xs uppercase text-muted-foreground">Unité</Label>
              <Input 
                value="Pièce" 
                className="h-9 bg-success/20"
                readOnly
              />
            </div>
            <div>
              <Label className="text-xs uppercase text-muted-foreground">Marque</Label>
              <Input 
                value="" 
                className="h-9 bg-success/20"
                readOnly
              />
            </div>
          </div>

          {/* Row 3: Rayon, Categorie, Date Peremption */}
          <div className="grid grid-cols-[1fr_1fr_200px] gap-4 items-end">
            <div>
              <Label className="text-xs uppercase text-muted-foreground">Rayon</Label>
              <Input 
                value="" 
                className="h-9 bg-success/20"
                readOnly
              />
            </div>
            <div>
              <Label className="text-xs uppercase text-muted-foreground">Catégorie</Label>
              <Input 
                value="" 
                className="h-9 bg-success/20"
                readOnly
              />
            </div>
            <div>
              <Label className="text-xs uppercase text-muted-foreground">Date Péremption</Label>
              <Input 
                value="/ /" 
                className="h-9 bg-muted text-center"
                readOnly
              />
            </div>
          </div>

          {/* Row 4: Prix Section */}
          <div className="grid grid-cols-4 gap-4 items-end">
            <div>
              <Label className="text-xs uppercase text-muted-foreground">Prix ACHAT</Label>
              <Input 
                value={(currentProduct.cost_price || 0).toLocaleString('fr-FR')} 
                className="h-9 bg-[hsl(180,60%,70%)] text-right"
                readOnly
              />
            </div>
            <div>
              <Label className="text-xs uppercase text-muted-foreground">Prix RVT</Label>
              <Input 
                value="0,00" 
                className="h-9 bg-[hsl(180,60%,70%)] text-right"
                readOnly
              />
            </div>
            <div>
              <Label className="text-xs uppercase text-muted-foreground">PVG HT</Label>
              <Input 
                value="0,00" 
                className="h-9 bg-[hsl(180,60%,70%)] text-right"
                readOnly
              />
            </div>
            <div>
              <Label className="text-xs uppercase text-muted-foreground">PVG TTC</Label>
              <Input 
                value="0,00" 
                className="h-9 bg-[hsl(180,60%,70%)] text-right"
                readOnly
              />
            </div>
          </div>

          {/* Row 5: Stock Section */}
          <div className="grid grid-cols-[100px_100px_100px_1fr_150px] gap-4 items-end">
            <div>
              <Label className="text-xs uppercase text-muted-foreground">Stock MINI</Label>
              <Input 
                value={(currentProduct.min_quantity || 0).toString()} 
                className="h-9 bg-[hsl(180,60%,70%)] text-right"
                readOnly
              />
            </div>
            <div>
              <Label className="text-xs uppercase text-muted-foreground">Rupture</Label>
              <div className={cn(
                'h-9 flex items-center justify-center rounded-md font-bold',
                stockStatus === 'rupture' ? 'bg-danger text-danger-foreground' : 'bg-warning/50'
              )}>
                {stockStatus === 'rupture' ? 'O' : 'N'}
              </div>
            </div>
            <div>
              <Label className="text-xs uppercase text-muted-foreground">Famille</Label>
              <Input 
                value="" 
                className="h-9 bg-success/20"
                readOnly
              />
            </div>
            <div></div>
            <div>
              <Label className="text-xs uppercase text-muted-foreground">Stock ACTUEL</Label>
              <Input 
                value={currentProduct.quantity.toString()} 
                className={cn(
                  'h-9 text-right font-bold text-lg',
                  stockStatus === 'ok' && 'bg-success/30 text-success',
                  stockStatus === 'low' && 'bg-warning/30 text-warning',
                  stockStatus === 'rupture' && 'bg-danger/30 text-danger'
                )}
                readOnly
              />
            </div>
          </div>

          {/* Divider */}
          <div className="border-t border-border/50 my-2" />

          {/* Bottom Section: Dates & Fournisseurs */}
          <div className="grid grid-cols-2 gap-6">
            {/* Dernières Dates */}
            <div className="bg-warning/20 p-3 rounded-lg">
              <Label className="text-xs uppercase font-bold mb-2 block">Dernières Dates</Label>
              <div className="grid grid-cols-3 gap-2 text-sm">
                <div>
                  <span className="text-xs text-muted-foreground block">Inventaire</span>
                  <span>/ /</span>
                </div>
                <div>
                  <span className="text-xs text-muted-foreground block">Achat</span>
                  <span>/ /</span>
                </div>
                <div>
                  <span className="text-xs text-muted-foreground block">Vente</span>
                  <span>/ /</span>
                </div>
              </div>
            </div>

            {/* Meilleurs Fournisseurs */}
            <div className="bg-success/30 p-3 rounded-lg">
              <Label className="text-xs uppercase font-bold mb-2 block">Meilleurs Fournisseurs</Label>
              <div className="grid grid-cols-3 gap-2 text-sm">
                <div>
                  <span className="text-xs text-muted-foreground block">Nom</span>
                  <span>----</span>
                  <span className="text-xs text-muted-foreground block mt-1">Prix Gros</span>
                  <span>0,00</span>
                </div>
                <div>
                  <span className="text-xs text-muted-foreground block">Nom</span>
                  <span>----</span>
                  <span className="text-xs text-muted-foreground block mt-1">Prix Gros</span>
                  <span>0,00</span>
                </div>
                <div>
                  <span className="text-xs text-muted-foreground block">Nom</span>
                  <span>----</span>
                  <span className="text-xs text-muted-foreground block mt-1">Prix Gros</span>
                  <span>0,00</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </ScrollArea>

      {/* Action Bar */}
      <div className="mt-3 flex justify-end gap-2">
        <Button variant="outline" size="sm">
          Annuler
        </Button>
        <Button size="sm" className="btn-neon">
          <Save className="h-4 w-4 mr-2" />
          Sauvegarder (F2)
        </Button>
      </div>
    </div>
  );
}
