import { useState, useEffect, useMemo } from 'react';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Save } from 'lucide-react';
import { cn } from '@/lib/utils';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import { getDataClient } from '@/lib/dataClient';
import { OfflineAuthService } from '@/services/OfflineAuthService';

interface FicheCaisseModuleProps {
  storeId: string;
}

interface BillCount {
  denomination: number;
  count: number;
}

export function FicheCaisseModule({ storeId }: FicheCaisseModuleProps) {
  const { user } = useAuth();
  const [fondsCaisse, setFondsCaisse] = useState(0);
  const [observations, setObservations] = useState('');
  const [cashierName, setCashierName] = useState('');
  const { isLocalFirst, localBridgeBaseUrl } = getDataClient();
  
  // Billetage (Cash counting)
  const [bills, setBills] = useState<BillCount[]>([
    { denomination: 10000, count: 0 },
    { denomination: 5000, count: 0 },
    { denomination: 2000, count: 0 },
    { denomination: 1000, count: 0 },
    { denomination: 500, count: 0 },
  ]);
  const [jetons, setJetons] = useState(0);

  // Day transactions (would come from real data)
  const [dayData, setDayData] = useState({
    especesJour: 0,
    cheques: 0,
    reglementCredit: 0,
    venteCredit: 0,
    reglementFournisseur: 0,
    depensesJour: 0,
    versementBanque: 0,
    refBanque: '',
  });

  // Computer calculated values (simulated)
  const [computerValues] = useState({
    especes: 0,
    cheques: 0,
    credits: 0,
    ventesCredit: 0,
  });

  const currentDate = new Date();

  // Fetch today's sales
  useEffect(() => {
    const fetchDaySales = async () => {
      if (!storeId) return;
      
      const today = new Date();
      today.setHours(0, 0, 0, 0);

      if (isLocalFirst) {
        const headers = await OfflineAuthService.getAuthHeaders();
        if (!headers) return;
        const params = new URLSearchParams();
        params.set('store_id', storeId);
        const response = await fetch(`${localBridgeBaseUrl}/rest/v1/sales?${params.toString()}`, {
          headers,
        });
        const payload = await response.json().catch(() => []);
        if (response.ok) {
          const sales = (payload || []) as Array<{ total_price?: number; created_at?: string }>;
          const total = sales
            .filter((sale) => sale.created_at && new Date(sale.created_at) >= today)
            .reduce((sum, sale) => sum + Number(sale.total_price || 0), 0);
          setDayData(prev => ({ ...prev, especesJour: total }));
        }
        return;
      }

      const { data } = await supabase
        .from('sales')
        .select('total_price')
        .eq('store_id', storeId)
        .gte('created_at', today.toISOString());
      
      if (data) {
        const total = data.reduce((sum, sale) => sum + (sale.total_price || 0), 0);
        setDayData(prev => ({ ...prev, especesJour: total }));
      }
    };
    
    fetchDaySales();
  }, [storeId, isLocalFirst, localBridgeBaseUrl]);

  // Calculate totals
  const billTotal = useMemo(() => {
    return bills.reduce((sum, bill) => sum + (bill.denomination * bill.count), 0) + jetons;
  }, [bills, jetons]);

  const totalEncaissement = useMemo(() => {
    return dayData.especesJour + dayData.cheques + dayData.reglementCredit - dayData.venteCredit;
  }, [dayData]);

  const updateBillCount = (denomination: number, count: number) => {
    setBills(prev => prev.map(bill => 
      bill.denomination === denomination 
        ? { ...bill, count: Math.max(0, count) }
        : bill
    ));
  };

  const formatCurrency = (amount: number) => {
    return amount.toLocaleString('fr-FR');
  };

  return (
    <div className="h-full flex flex-col p-4 bg-[hsl(60,80%,85%)] dark:bg-transparent">
      <ScrollArea className="flex-1">
        <div className="glass-card p-4">
          {/* Header */}
          <div className="flex items-center gap-8 mb-6 p-3 bg-muted/30 rounded-lg">
            <div className="flex items-center gap-2">
              <Label className="font-bold">EQUIPE</Label>
              <Input 
                value="" 
                className="w-20 h-8 bg-success/30"
                readOnly
              />
            </div>
            <div className="flex items-center gap-2">
              <Label className="font-bold">CAISSIER(E)</Label>
              <Input 
                value={cashierName}
                onChange={(e) => setCashierName(e.target.value)}
                className="w-40 h-8"
              />
            </div>
            <div className="flex items-center gap-2">
              <Label className="font-bold">DATE</Label>
              <Input 
                value={currentDate.toLocaleDateString('fr-FR')} 
                className="w-28 h-8 bg-success/30"
                readOnly
              />
            </div>
            <div className="flex items-center gap-2">
              <Label className="font-bold">HORAIRE de</Label>
              <Input 
                value={currentDate.toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' })} 
                className="w-20 h-8 bg-success/30"
                readOnly
              />
              <Label>à</Label>
              <Input className="w-20 h-8 bg-success/30" />
            </div>
            <div className="flex items-center gap-2">
              <Label className="font-bold">FONDS DE CAISSE:</Label>
              <Input 
                type="number"
                value={fondsCaisse}
                onChange={(e) => setFondsCaisse(Number(e.target.value))}
                className="w-24 h-8 bg-success/30 text-right"
              />
            </div>
          </div>

          {/* Main Grid - 3 columns */}
          <div className="grid grid-cols-[1fr_1.5fr_auto] gap-6">
            {/* Left: Billetage */}
            <div>
              <div className="bg-[hsl(300,70%,60%)] text-white px-3 py-1 rounded-t-lg font-bold text-sm">
                BILLETAGE ESPECES EN CAISSE
              </div>
              <div className="border border-border rounded-b-lg p-3 bg-card/50">
                <div className="grid grid-cols-[auto_1fr_auto_1fr] gap-2 items-center text-sm">
                  <span className="font-medium">Billets de</span>
                  <span></span>
                  <span className="font-medium">Montant</span>
                  <span></span>
                  
                  {bills.map((bill) => (
                    <>
                      <Input 
                        key={`count-${bill.denomination}`}
                        type="number"
                        value={bill.count || ''}
                        onChange={(e) => updateBillCount(bill.denomination, parseInt(e.target.value) || 0)}
                        className="w-12 h-7 text-center bg-success/30"
                      />
                      <span>x {formatCurrency(bill.denomination)} F</span>
                      <span>...=</span>
                      <span className="text-right font-mono">
                        {formatCurrency(bill.denomination * bill.count)}
                      </span>
                    </>
                  ))}
                  
                  <span className="col-span-2 mt-2">JETONS ...=</span>
                  <span></span>
                  <Input 
                    type="number"
                    value={jetons || ''}
                    onChange={(e) => setJetons(parseInt(e.target.value) || 0)}
                    className="w-20 h-7 text-right bg-success/30"
                  />
                </div>
                
                <div className="border-t border-dashed border-border mt-3 pt-3">
                  <div className="flex justify-between items-center">
                    <span className="font-bold">TOTAL .....=</span>
                    <Input 
                      value={formatCurrency(billTotal)}
                      className="w-28 h-8 text-right bg-success/30 font-bold"
                      readOnly
                    />
                  </div>
                  <div className="flex justify-between items-center mt-2">
                    <span className="font-medium">VERSEMENT SIEGE ....:</span>
                    <Input className="w-28 h-8 text-right" />
                  </div>
                </div>
              </div>
            </div>

            {/* Center: Transactions du Jour */}
            <div>
              <div className="bg-[hsl(300,70%,60%)] text-white px-3 py-1 rounded-t-lg font-bold text-sm">
                TRANSACTIONS DU JOUR
              </div>
              <div className="border border-border rounded-b-lg p-3 bg-card/50">
                <div className="space-y-2 text-sm">
                  <div className="font-bold mb-2">ENCAISSEMENTS :</div>
                  
                  <div className="flex justify-between items-center">
                    <span>- Espèces du jour ....:</span>
                    <Input 
                      value={formatCurrency(dayData.especesJour)}
                      className="w-28 h-7 text-right bg-success/30"
                      readOnly
                    />
                  </div>
                  <div className="flex justify-between items-center">
                    <span>- Chèques ...........:</span>
                    <Input 
                      value={formatCurrency(dayData.cheques)}
                      className="w-28 h-7 text-right bg-success/30"
                      readOnly
                    />
                  </div>
                  <div className="flex justify-between items-center">
                    <span>- Règlt. CREDIT......:</span>
                    <Input 
                      value={formatCurrency(dayData.reglementCredit)}
                      className="w-28 h-7 text-right bg-success/30"
                      readOnly
                    />
                  </div>
                  <div className="flex justify-between items-center">
                    <span>- Vente CREDIT.......:</span>
                    <Input 
                      value={formatCurrency(dayData.venteCredit)}
                      className="w-28 h-7 text-right bg-success/30"
                      readOnly
                    />
                  </div>
                  
                  <div className="flex justify-between items-center mt-3">
                    <span>REGLEMENT FOURNISSEUR.:</span>
                    <Input 
                      value={formatCurrency(dayData.reglementFournisseur)}
                      className="w-28 h-7 text-right bg-success/30"
                      readOnly
                    />
                  </div>
                  <div className="flex justify-between items-center">
                    <span>DEPENSES du JOUR .....:</span>
                    <Input 
                      value={formatCurrency(dayData.depensesJour)}
                      className="w-28 h-7 text-right bg-success/30"
                      readOnly
                    />
                  </div>
                  
                  <div className="border-t border-dashed border-border mt-3 pt-3">
                    <div className="flex justify-between items-center">
                      <span className="font-bold text-[hsl(300,70%,50%)]">TOTAL ENCAISSEMENT....:</span>
                      <Input 
                        value={formatCurrency(totalEncaissement)}
                        className="w-28 h-8 text-right bg-success/30 font-bold"
                        readOnly
                      />
                    </div>
                  </div>
                  
                  <div className="flex justify-between items-center mt-2">
                    <span>VERSEMENT BANQUE.......:</span>
                    <Input 
                      type="number"
                      value={dayData.versementBanque || ''}
                      onChange={(e) => setDayData(prev => ({ ...prev, versementBanque: Number(e.target.value) }))}
                      className="w-28 h-7 text-right"
                    />
                  </div>
                  <div className="flex justify-between items-center">
                    <span>REF. BANQUE:</span>
                    <Input 
                      value={dayData.refBanque}
                      onChange={(e) => setDayData(prev => ({ ...prev, refBanque: e.target.value }))}
                      className="w-40 h-7"
                    />
                  </div>
                </div>
              </div>
            </div>

            {/* Right: Ordinateur */}
            <div className="w-48">
              <div className="bg-[hsl(300,70%,60%)] text-white px-3 py-1 rounded-t-lg font-bold text-sm text-center">
                ORDINATEUR
              </div>
              <div className="border border-border rounded-b-lg p-3 bg-danger text-danger-foreground">
                <div className="space-y-2 text-right font-mono text-lg">
                  <div>{formatCurrency(computerValues.especes)}</div>
                  <div>{formatCurrency(computerValues.cheques)}</div>
                  <div>{formatCurrency(computerValues.credits)}</div>
                  <div>{formatCurrency(computerValues.ventesCredit)}</div>
                </div>
              </div>
            </div>
          </div>

          {/* Observations */}
          <div className="mt-4">
            <div className="flex items-center gap-3">
              <Label className="font-bold">OBSERVATIONS</Label>
              <Input 
                value={observations}
                onChange={(e) => setObservations(e.target.value)}
                className="flex-1 h-8 bg-success/30"
                placeholder="Notes et observations..."
              />
            </div>
          </div>
        </div>
      </ScrollArea>

      {/* Action Bar */}
      <div className="mt-3 flex justify-end gap-2">
        <Button variant="outline" size="sm">
          Annuler (Esc)
        </Button>
        <Button size="sm" className="btn-neon">
          <Save className="h-4 w-4 mr-2" />
          Sauvegarder (F2)
        </Button>
      </div>
    </div>
  );
}
