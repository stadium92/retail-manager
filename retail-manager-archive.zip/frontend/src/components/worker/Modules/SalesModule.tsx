import { useState, useEffect, useCallback, useMemo } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import { getDataClient } from '@/lib/dataClient';
import { OfflineAuthService } from '@/services/OfflineAuthService';
import { OfflineSalesService } from '@/services/OfflineSalesService';
import { Product } from '@/types';
import { toast } from 'sonner';
import { format } from 'date-fns';
import { useSalesStore } from '@/stores/useSalesStore';
import { useMasterDataStore, Client } from '@/stores/useMasterDataStore';

import { SanifereHeader, SaleMode } from '../Sales/SanifereHeader';
import { SanifereGrid, SanifereLineItem } from '../Sales/SanifereGrid';
import { SanifereFooter } from '../Sales/SanifereFooter';
import { ProductLookupDialog } from '../Sales/ProductLookupDialog';
import { PaymentDialog } from '../Sales/PaymentDialog';
import { BarcodeScanner } from '@/components/shared/BarcodeScanner';

interface SalesModuleProps {
  storeId: string;
  mode: SaleMode;
}

/**
 * Pricing logic:
 * - Vente au Détail / Facturation Détail: use unit_price (Prix RVT - retail price)
 * - Facturation en Gros: use wholesale_price (PVG HT - wholesale price excluding tax)
 * - Proforma: uses retail price by default, can be switched
 */
function getProductPrice(product: Product, mode: SaleMode): number {
  if (mode === 'facturation-gros') {
    return product.wholesale_price || product.unit_price;
  }
  // Retail modes use unit_price (Prix RVT)
  return product.unit_price;
}

function calculateLineTotal(unitPrice: number, quantity: number, discountPercent: number): number {
  const subtotal = unitPrice * quantity;
  const discountAmount = subtotal * (discountPercent / 100);
  return Math.round(subtotal - discountAmount);
}

function generateInvoiceNumber(): string {
  const datePrefix = format(new Date(), 'yyMMdd');
  const sequence = String(Math.floor(Math.random() * 9999)).padStart(4, '0');
  return `${datePrefix}${sequence}`;
}

export function SalesModule({ storeId, mode }: SalesModuleProps) {
  const { user } = useAuth();
  const { isLocalFirst, localBridgeBaseUrl } = getDataClient();
  const { sessions, updateSession } = useSalesStore();
  const { clients, setClients } = useMasterDataStore();

  const currentSession = sessions[mode] || {
    lineItems: [],
    customerCode: '',
    customerName: '',
    customerAddress: '',
    orderRef: '',
  };

  const {
    lineItems,
    customerCode,
    customerName,
    customerAddress,
    orderRef,
    invoiceNumber: savedInvoiceNumber
  } = currentSession;

  // Ensure stable invoice number
  const invoiceNumber = useMemo(() => {
    return savedInvoiceNumber || generateInvoiceNumber();
  }, [savedInvoiceNumber]);

  // Persist invoice number if new
  useEffect(() => {
    if (!savedInvoiceNumber) {
      updateSession(mode, { invoiceNumber });
    }
  }, [invoiceNumber, savedInvoiceNumber, mode, updateSession]);

  // Data state
  const [products, setProducts] = useState<Product[]>([]);
  // selectedIndex remains local UI state as it's transient focus
  const [selectedIndex, setSelectedIndex] = useState(-1);

  // UI state
  const [isLoading, setIsLoading] = useState(true);
  const [isProductLookupOpen, setIsProductLookupOpen] = useState(false);
  const [isPaymentOpen, setIsPaymentOpen] = useState(false);
  const [isScanning, setIsScanning] = useState(false);

  // validation: invoiceNumber is now handled by store/memo above

  // Fetch products and clients
  useEffect(() => {
    // 1. Fetch Products
    const fetchProducts = async () => {
      if (!storeId) return;
      setIsLoading(true);

      try {
        if (isLocalFirst) {
          const headers = await OfflineAuthService.getAuthHeaders();
          if (!headers) {
            setIsLoading(false);
            return;
          }
          // Fetch Products
          const params = new URLSearchParams({ store_id: storeId });
          const response = await fetch(`${localBridgeBaseUrl}/rest/v1/products?${params.toString()}`, { headers });
          const payload = await response.json().catch(() => []);
          
          if (response.ok && payload) {
            setProducts(payload.map((item: any) => ({
              id: item.id,
              store_id: item.store_id,
              name: item.name,
              description: item.description,
              sku: item.sku,
              barcode: item.barcode,
              category: item.category,
              unit_price: Number(item.unit_price) || 0,
              wholesale_price: Number(item.wholesale_price) || Number(item.unit_price) || 0,
              cost_price: Number(item.cost_price) || 0,
              quantity: item.quantity,
              min_quantity: item.min_quantity,
              image_url: item.image_url,
              is_active: item.is_active ?? true,
              created_at: item.created_at,
              updated_at: item.updated_at,
            })));
          }

          // Fetch Clients (Optimistic check if store already has them)
          if (clients.length === 0) {
            const clientRes = await fetch(`${localBridgeBaseUrl}/rest/v1/clients?${params.toString()}`, { headers });
            const clientPayload = await clientRes.json().catch(() => []);
            if (clientRes.ok && clientPayload) {
              setClients(clientPayload);
            }
          }
        } else {
          // Online Mode
          const { data } = await supabase
            .from('products')
            .select('*')
            .eq('store_id', storeId)
            .order('name');

          if (data) {
            setProducts(data.map(item => ({
              id: item.id,
              store_id: item.store_id,
              name: item.name,
              description: item.description,
              sku: item.sku,
              barcode: item.barcode,
              category: item.category,
              unit_price: Number(item.unit_price) || 0,
              wholesale_price: Number(item.wholesale_price) || Number(item.unit_price) || 0,
              cost_price: Number(item.cost_price) || 0,
              quantity: item.quantity,
              min_quantity: item.min_quantity,
              image_url: item.image_url,
              is_active: item.is_active ?? true,
              created_at: item.created_at,
              updated_at: item.updated_at,
            })));
          }

          if (clients.length === 0) {
             const { data: clientData } = await supabase
              .from('clients')
              .select('*')
              .eq('store_id', storeId);
             if (clientData) setClients(clientData); 
          }
        }
      } catch (error) {
        console.error('Failed to fetch data:', error);
        toast.error('Erreur lors du chargement des données');
      } finally {
        setIsLoading(false);
      }
    };

    fetchProducts();
  }, [storeId, isLocalFirst, localBridgeBaseUrl, clients.length, setClients]);

  // Calculate net total
  const netTotal = useMemo(() => {
    return lineItems.reduce((sum, item) => sum + item.lineTotal, 0);
  }, [lineItems]);

  // Client Data Binding Logic (Fix 4.2)
  const handleClientChange = useCallback((field: 'code' | 'name', value: string) => {
    let updates: Partial<SalesSessionState> = {};
    
    if (field === 'code') {
      updates = { customerCode: value };
      const client = clients.find(c => c.code?.toLowerCase() === value.toLowerCase());
      if (client) {
        updates.customerName = client.name;
        updates.customerAddress = client.address || '';
      }
    } else if (field === 'name') {
      updates = { customerName: value };
      const client = clients.find(c => c.name.toLowerCase() === value.toLowerCase());
      if (client) {
        updates.customerCode = client.code || '';
        updates.customerAddress = client.address || '';
      }
    }

    updateSession(mode, updates);
  }, [clients, mode, updateSession]);

  // Add product to line items
  const addProduct = useCallback((product: Product) => {
    const existingIndex = lineItems.findIndex(li => li.productId === product.id);
    
    if (existingIndex >= 0) {
      // Increment quantity
      const newItems = [...lineItems];
      const item = newItems[existingIndex];
      const newQty = item.quantity + 1;
      newItems[existingIndex] = {
        ...item,
        quantity: newQty,
        lineTotal: calculateLineTotal(item.unitPrice, newQty, item.discountPercent),
      };
      updateSession(mode, { lineItems: newItems });
      setSelectedIndex(existingIndex);
    } else {
      // Add new line
      const price = getProductPrice(product, mode);
      const newItem: SanifereLineItem = {
        id: crypto.randomUUID(),
        lineNumber: lineItems.length + 1,
        productId: product.id,
        designation: product.name,
        code: product.sku || product.barcode || '',
        conditionnement: 1, // Default 1 unit per pack
        stock: product.quantity,
        unitPrice: price,
        quantity: 1,
        discountPercent: 0,
        lineTotal: price,
      };
      updateSession(mode, { lineItems: [...lineItems, newItem] });
      setSelectedIndex(lineItems.length);
    }
    
    toast.success(`${product.name} ajouté`);
  }, [lineItems, mode, updateSession]);

  // Update quantity
  const handleQuantityChange = useCallback((index: number, quantity: number) => {
    if (quantity <= 0) {
      handleDeleteLine(index);
      return;
    }
    
    const newItems = [...lineItems];
    const item = newItems[index];
    newItems[index] = {
      ...item,
      quantity,
      lineTotal: calculateLineTotal(item.unitPrice, quantity, item.discountPercent),
    };
    updateSession(mode, { lineItems: newItems });
  }, [lineItems, mode, updateSession]);

  // Update discount
  const handleDiscountChange = useCallback((index: number, discount: number) => {
    const newItems = [...lineItems];
    const item = newItems[index];
    newItems[index] = {
      ...item,
      discountPercent: discount,
      lineTotal: calculateLineTotal(item.unitPrice, item.quantity, discount),
    };
    updateSession(mode, { lineItems: newItems });
  }, [lineItems, mode, updateSession]);

  // Handle Designation editing (Fix 5.2)
  const handleDesignationChange = useCallback((index: number, value: string) => {
    const newItems = [...lineItems];
    newItems[index] = { ...newItems[index], designation: value };
    updateSession(mode, { lineItems: newItems });
  }, [lineItems, mode, updateSession]);

  // Handle Price editing (Fix 5.2)
  const handlePriceChange = useCallback((index: number, value: number) => {
    const newItems = [...lineItems];
    const item = newItems[index];
    newItems[index] = { 
      ...item, 
      unitPrice: value,
      lineTotal: calculateLineTotal(value, item.quantity, item.discountPercent)
    };
    updateSession(mode, { lineItems: newItems });
  }, [lineItems, mode, updateSession]);

  // Delete line
  const handleDeleteLine = useCallback((index: number) => {
    const newItems = lineItems.filter((_, i) => i !== index);
    // Renumber lines
    newItems.forEach((item, i) => { item.lineNumber = i + 1; });
    updateSession(mode, { lineItems: newItems });
    setSelectedIndex(Math.min(index, newItems.length - 1));
  }, [lineItems, mode, updateSession]);

  // Handle barcode scan
  const handleScanResult = useCallback((result: string) => {
    const product = products.find(p =>
      p.sku?.toLowerCase() === result.toLowerCase() ||
      p.barcode?.toLowerCase() === result.toLowerCase() ||
      p.name.toLowerCase().includes(result.toLowerCase())
    );

    if (product) {
      addProduct(product);
    } else {
      toast.error(`Produit non trouvé: ${result}`);
    }
    setIsScanning(false);
  }, [products, addProduct]);

  // Handle payment confirmation
  const handlePaymentConfirm = useCallback(async (paymentMethod: string, amountPaid: number, isCredit: boolean) => {
    if (lineItems.length === 0) return;

    try {
      // Determine sale type based on mode
      let saleType: 'detail' | 'gros' | 'proforma' = 'detail';
      if (mode === 'facturation-gros') saleType = 'gros';
      if (mode === 'proforma') saleType = 'proforma';

      // Create cart items for OfflineSalesService
      const cartItems = lineItems.map(item => ({
        product: products.find(p => p.id === item.productId) || {
          id: item.productId || '',
          store_id: storeId,
          name: item.designation,
          unit_price: item.unitPrice,
          quantity: item.stock,
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString(),
        },
        quantity: item.quantity,
        discount: item.discountPercent,
        unitPrice: item.unitPrice,
        lineTotal: item.lineTotal,
        total: item.lineTotal,
      }));

      const { error } = await OfflineSalesService.createSale({
        store_id: storeId,
        worker_id: user?.id || '',
        items: cartItems,
        total_price: netTotal,
        payment_method: paymentMethod as 'cash' | 'card' | 'credit',
        sale_type: saleType,
        customer_name: customerName || undefined,
        customer_phone: undefined,
      });

      if (error) throw error;

      // Show success message
      if (mode === 'proforma') {
        toast.success(`Proforma ${invoiceNumber} créée: ${netTotal.toLocaleString('fr-FR')} F`);
      } else {
        toast.success(`Vente enregistrée: ${netTotal.toLocaleString('fr-FR')} F`);
      }

      // Clear session after successful sale
      updateSession(mode, {
        lineItems: [],
        customerCode: '',
        customerName: '',
        customerAddress: '',
        orderRef: '',
        invoiceNumber: generateInvoiceNumber(), // Generate new one for next sale
      });
      setSelectedIndex(-1);
    } catch (error) {
      console.error('Payment error:', error);
      toast.error('Erreur lors de l\'enregistrement');
    }
  }, [lineItems, products, storeId, user, netTotal, mode, customerName, invoiceNumber, updateSession]);

  // Keyboard shortcuts
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement) {
        return;
      }

      switch (e.key) {
        case 'F4':
          e.preventDefault();
          if (lineItems.length > 0) setIsPaymentOpen(true);
          break;
        case 'F5':
          e.preventDefault();
          setIsProductLookupOpen(true);
          break;
        case 'F8':
          e.preventDefault();
          if (selectedIndex >= 0) handleDeleteLine(selectedIndex);
          break;
        case 'Escape':
          setIsScanning(false);
          setIsProductLookupOpen(false);
          setIsPaymentOpen(false);
          break;
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [lineItems.length, selectedIndex, handleDeleteLine]);

  // Reset selection index on mode change (but keep session data)
  useEffect(() => {
    setSelectedIndex(-1);
  }, [mode]);

  if (isLoading) {
    return (
      <div className="h-full flex items-center justify-center font-mono text-muted-foreground">
        Chargement des produits...
      </div>
    );
  }

  return (
    <div className="h-full flex flex-col overflow-hidden">
      {/* Header */}
      <SanifereHeader
        mode={mode}
        invoiceNumber={invoiceNumber}
        customerCode={customerCode}
        customerName={customerName}
        customerAddress={customerAddress}
        orderRef={orderRef}
        onCustomerChange={(code, name, address) => {
          // If the header passes all 3 (e.g. from a clear action), update all
          // Otherwise rely on the specific field change logic
          if (code !== customerCode) handleClientChange('code', code);
          else if (name !== customerName) handleClientChange('name', name);
          else updateSession(mode, { customerAddress: address });
        }}
        onOrderRefChange={(ref) => updateSession(mode, { orderRef: ref })}
        onInvoiceNumberChange={(num) => updateSession(mode, { invoiceNumber: num })}
      />

      {/* Grid */}
      <SanifereGrid
        items={lineItems}
        selectedIndex={selectedIndex}
        priceLabel={mode === 'facturation-gros' ? 'PVG' : 'PRIX'}
        onSelectLine={setSelectedIndex}
        onQuantityChange={handleQuantityChange}
        onDiscountChange={handleDiscountChange}
        onDeleteLine={handleDeleteLine}
        onDesignationChange={handleDesignationChange}
        onPriceChange={handlePriceChange}
        persistenceKey={`sales_grid_${user?.id || 'anon'}`}
      />

      {/* Footer */}
      <SanifereFooter
        mode={mode}
        netTotal={netTotal}
        onValidate={() => lineItems.length > 0 && setIsPaymentOpen(true)}
        onSettlement={() => lineItems.length > 0 && setIsPaymentOpen(true)}
        onProductCard={() => setIsProductLookupOpen(true)}
        onDelete={() => selectedIndex >= 0 && handleDeleteLine(selectedIndex)}
        onPrint={() => toast.info('Impression en cours...')}
      />

      {/* Product Lookup Dialog */}
      <ProductLookupDialog
        open={isProductLookupOpen}
        onOpenChange={setIsProductLookupOpen}
        products={products}
        mode={mode === 'facturation-gros' ? 'wholesale' : 'retail'}
        onSelect={addProduct}
      />

      {/* Payment Dialog */}
      <PaymentDialog
        open={isPaymentOpen}
        onOpenChange={setIsPaymentOpen}
        mode={mode}
        totalAmount={netTotal}
        onConfirm={handlePaymentConfirm}
      />

      {/* Barcode Scanner */}
      <BarcodeScanner
        isScanning={isScanning}
        onResult={handleScanResult}
        onClose={() => setIsScanning(false)}
      />
    </div>
  );
}
