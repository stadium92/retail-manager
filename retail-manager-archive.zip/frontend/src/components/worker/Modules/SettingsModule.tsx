import { useState, useEffect } from 'react';
import { useTheme } from 'next-themes';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Progress } from '@/components/ui/progress';
import { 
  Settings, Moon, Sun, Printer, Keyboard, Lock, Save, 
  Eye, EyeOff, Check, AlertCircle, RefreshCw, Cloud, WifiOff, Database
} from 'lucide-react';
import { toast } from 'sonner';
import { cn } from '@/lib/utils';
import { OfflineDataService } from '@/services/OfflineDataService';
import { LocalBridgeSyncService } from '@/services/LocalBridgeSyncService';
import { useMasterDataStore } from '@/stores/useMasterDataStore';
import { LocalDatabase } from '@/services/LocalDatabase';

interface SettingsModuleProps {
  storeId: string;
  mode: 'preferences' | 'programmation-touches' | 'mots-de-passe' | 'synchronisation';
}

interface FKeyMapping {
  key: string;
  label: string;
  action: string;
}

const DEFAULT_FKEYS: FKeyMapping[] = [
  { key: 'F1', label: 'F1', action: 'vente-detail' },
  { key: 'F2', label: 'F2', action: 'facturation-detail' },
  { key: 'F3', label: 'F3', action: 'facturation-gros' },
  { key: 'F4', label: 'F4', action: 'proforma' },
  { key: 'F5', label: 'F5', action: 'reception-achats' },
  { key: 'F6', label: 'F6', action: 'listing-stock' },
  { key: 'F7', label: 'F7', action: 'journal-caisse' },
  { key: 'F8', label: 'F8', action: 'tableau-bord' },
  { key: 'F9', label: 'F9', action: 'clients' },
  { key: 'F10', label: 'F10', action: 'fournisseurs' },
  { key: 'F11', label: 'F11', action: 'produits' },
  { key: 'F12', label: 'F12', action: 'fermeture-caisse' },
];

const AVAILABLE_ACTIONS = [
  { value: 'vente-detail', label: 'Vente au Détail' },
  { value: 'facturation-detail', label: 'Facturation Détail' },
  { value: 'facturation-gros', label: 'Facturation Gros' },
  { value: 'proforma', label: 'Proforma' },
  { value: 'reception-achats', label: 'Réception Achats' },
  { value: 'listing-stock', label: 'Listing Stock' },
  { value: 'journal-caisse', label: 'Journal Caisse' },
  { value: 'tableau-bord', label: 'Tableau de Bord' },
  { value: 'clients', label: 'Fichier Clients' },
  { value: 'fournisseurs', label: 'Fichier Fournisseurs' },
  { value: 'produits', label: 'Fichier Produits' },
  { value: 'fermeture-caisse', label: 'Fermeture Caisse' },
  { value: 'inventaire-stock', label: 'Inventaire' },
  { value: 'statistiques', label: 'Statistiques' },
];

export function SettingsModule({ storeId, mode }: SettingsModuleProps) {
  const { theme, setTheme } = useTheme();
  const { user } = useAuth();
  
  // Sync state
  const [isSyncing, setIsSyncing] = useState(false);
  const [syncProgress, setSyncProgress] = useState(0);
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  const [pendingQueueSize, setPendingQueueSize] = useState(0);
  const [serviceKey, setServiceKey] = useState('');
  const lastSync = useMasterDataStore(state => state.lastSync);
  const productsCount = useMasterDataStore(state => state.products.filter(p => p.store_id === storeId).length);
  const suppliersCount = useMasterDataStore(state => state.suppliers.filter(s => s.store_id === storeId).length);
  
  // Preferences state
  const [printerFormat, setPrinterFormat] = useState<'a4' | 'ticket'>('a4');
  const [autoLogout, setAutoLogout] = useState(false);
  const [soundEnabled, setSoundEnabled] = useState(true);
  
  // F-Keys state
  const [fKeyMappings, setFKeyMappings] = useState<FKeyMapping[]>(DEFAULT_FKEYS);
  
  // Password state
  const [passwordForm, setPasswordForm] = useState({
    currentPassword: '',
    newPassword: '',
    confirmPassword: '',
  });
  const [showPasswords, setShowPasswords] = useState({
    current: false,
    new: false,
    confirm: false,
  });
  const [isChangingPassword, setIsChangingPassword] = useState(false);

  // Listen for online/offline and queue changes
  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);
    const updateQueueSize = async () => {
      const size = await LocalDatabase.getSyncQueueSize();
      setPendingQueueSize(size);
    };

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    window.addEventListener('localDbQueueUpdated', updateQueueSize);
    updateQueueSize();

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
      window.removeEventListener('localDbQueueUpdated', updateQueueSize);
    };
  }, []);

  // Handle initial sync

  const handleSyncPush = async () => {
    if (!isOnline) {
      toast.error('Connexion internet requise');
      return;
    }
    if (!serviceKey) {
      toast.error('Clé Supabase requise');
      return;
    }
    setIsSyncing(true);
    try {
      const result = await LocalBridgeSyncService.pushPendingMutations(serviceKey);
      if (result.failed > 0) {
        toast.error(`Synchronisation partielle: ${result.pushed} OK, ${result.failed} échecs`);
      } else {
        toast.success(`Synchronisation terminée: ${result.pushed} opérations`);
      }
      const size = await LocalDatabase.getSyncQueueSize();
      setPendingQueueSize(size);
    } catch (error) {
      toast.error('Erreur lors de la synchronisation');
    } finally {
      setIsSyncing(false);
    }
  };

  const handleInitialSync = async () => {
    if (!isOnline) {
      toast.error('Connexion internet requise');
      return;
    }

    setIsSyncing(true);
    setSyncProgress(10);

    try {
      setSyncProgress(30);
      const result = await OfflineDataService.performInitialSync(storeId);
      setSyncProgress(100);
      
      if (result.success) {
        toast.success(result.message);
      } else {
        toast.error(result.message);
      }
    } catch (error) {
      toast.error('Erreur lors de la synchronisation');
    } finally {
      setIsSyncing(false);
      setSyncProgress(0);
    }
  };

  // Update F-Key mapping
  const updateFKeyAction = (key: string, action: string) => {
    setFKeyMappings(mappings => 
      mappings.map(m => m.key === key ? { ...m, action } : m)
    );
  };

  // Handle password change
  const handleChangePassword = async () => {
    if (!passwordForm.currentPassword || !passwordForm.newPassword || !passwordForm.confirmPassword) {
      toast.error('Veuillez remplir tous les champs');
      return;
    }

    if (passwordForm.newPassword !== passwordForm.confirmPassword) {
      toast.error('Les mots de passe ne correspondent pas');
      return;
    }

    if (passwordForm.newPassword.length < 6) {
      toast.error('Le mot de passe doit contenir au moins 6 caractères');
      return;
    }

    setIsChangingPassword(true);
    try {
      const { error } = await supabase.auth.updateUser({
        password: passwordForm.newPassword,
      });

      if (error) throw error;

      toast.success('Mot de passe modifié avec succès');
      setPasswordForm({ currentPassword: '', newPassword: '', confirmPassword: '' });
    } catch (error: any) {
      toast.error(error.message || 'Erreur lors du changement de mot de passe');
    } finally {
      setIsChangingPassword(false);
    }
  };

  // Save preferences
  const savePreferences = () => {
    // In a real app, save to user preferences in database
    localStorage.setItem('printerFormat', printerFormat);
    localStorage.setItem('autoLogout', String(autoLogout));
    localStorage.setItem('soundEnabled', String(soundEnabled));
    toast.success('Préférences sauvegardées');
  };

  // Save F-Key mappings
  const saveFKeyMappings = () => {
    localStorage.setItem('fKeyMappings', JSON.stringify(fKeyMappings));
    toast.success('Programmation des touches sauvegardée');
  };

  const renderContent = () => {
    switch (mode) {
      case 'preferences':
        return (
          <div className="max-w-2xl mx-auto space-y-6">
            {/* Theme */}
            <Card>
              <CardHeader className="py-4">
                <CardTitle className="text-sm flex items-center gap-2">
                  {theme === 'dark' ? <Moon className="h-4 w-4" /> : <Sun className="h-4 w-4" />}
                  Apparence
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center justify-between">
                  <div>
                    <Label>Mode Sombre</Label>
                    <p className="text-xs text-muted-foreground">
                      Basculer entre le mode clair et sombre
                    </p>
                  </div>
                  <Switch
                    checked={theme === 'dark'}
                    onCheckedChange={(checked) => setTheme(checked ? 'dark' : 'light')}
                  />
                </div>
              </CardContent>
            </Card>

            {/* Printer */}
            <Card>
              <CardHeader className="py-4">
                <CardTitle className="text-sm flex items-center gap-2">
                  <Printer className="h-4 w-4" />
                  Impression
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <Label>Format d'impression</Label>
                    <p className="text-xs text-muted-foreground">
                      Choisir le format des factures
                    </p>
                  </div>
                  <Select value={printerFormat} onValueChange={(v: 'a4' | 'ticket') => setPrinterFormat(v)}>
                    <SelectTrigger className="w-40">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="a4">A4 (Standard)</SelectItem>
                      <SelectItem value="ticket">Ticket (Thermique)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </CardContent>
            </Card>

            {/* General */}
            <Card>
              <CardHeader className="py-4">
                <CardTitle className="text-sm flex items-center gap-2">
                  <Settings className="h-4 w-4" />
                  Général
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <Label>Déconnexion automatique</Label>
                    <p className="text-xs text-muted-foreground">
                      Se déconnecter après 30 minutes d'inactivité
                    </p>
                  </div>
                  <Switch
                    checked={autoLogout}
                    onCheckedChange={setAutoLogout}
                  />
                </div>
                <div className="flex items-center justify-between">
                  <div>
                    <Label>Sons</Label>
                    <p className="text-xs text-muted-foreground">
                      Activer les sons de notification
                    </p>
                  </div>
                  <Switch
                    checked={soundEnabled}
                    onCheckedChange={setSoundEnabled}
                  />
                </div>
              </CardContent>
            </Card>

            <Button onClick={savePreferences} className="w-full">
              <Save className="h-4 w-4 mr-2" />
              Sauvegarder les Préférences
            </Button>
          </div>
        );

      case 'programmation-touches':
        return (
          <div className="max-w-3xl mx-auto space-y-6">
            <Card>
              <CardHeader className="py-4">
                <CardTitle className="text-sm flex items-center gap-2">
                  <Keyboard className="h-4 w-4" />
                  Programmation des Touches de Fonction
                </CardTitle>
                <CardDescription>
                  Personnalisez les raccourcis clavier F1-F12
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 gap-4">
                  {fKeyMappings.map(mapping => (
                    <div key={mapping.key} className="flex items-center gap-3">
                      <div className="w-12 h-10 flex items-center justify-center bg-muted rounded-lg font-mono font-bold text-sm">
                        {mapping.key}
                      </div>
                      <Select 
                        value={mapping.action} 
                        onValueChange={(v) => updateFKeyAction(mapping.key, v)}
                      >
                        <SelectTrigger className="flex-1 h-10">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {AVAILABLE_ACTIONS.map(action => (
                            <SelectItem key={action.value} value={action.value}>
                              {action.label}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <div className="flex gap-3">
              <Button 
                variant="outline" 
                onClick={() => setFKeyMappings(DEFAULT_FKEYS)}
                className="flex-1"
              >
                Réinitialiser par défaut
              </Button>
              <Button onClick={saveFKeyMappings} className="flex-1">
                <Save className="h-4 w-4 mr-2" />
                Sauvegarder
              </Button>
            </div>
          </div>
        );

      case 'mots-de-passe':
        return (
          <div className="max-w-md mx-auto space-y-6">
            <Card>
              <CardHeader className="py-4">
                <CardTitle className="text-sm flex items-center gap-2">
                  <Lock className="h-4 w-4" />
                  Changer le Mot de Passe
                </CardTitle>
                <CardDescription>
                  Compte: {user?.email}
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label className="text-xs">Mot de passe actuel</Label>
                  <div className="relative">
                    <Input
                      type={showPasswords.current ? 'text' : 'password'}
                      value={passwordForm.currentPassword}
                      onChange={(e) => setPasswordForm(f => ({ ...f, currentPassword: e.target.value }))}
                      className="pr-10"
                    />
                    <Button
                      type="button"
                      variant="ghost"
                      size="icon"
                      className="absolute right-0 top-0 h-full"
                      onClick={() => setShowPasswords(s => ({ ...s, current: !s.current }))}
                    >
                      {showPasswords.current ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                    </Button>
                  </div>
                </div>

                <div>
                  <Label className="text-xs">Nouveau mot de passe</Label>
                  <div className="relative">
                    <Input
                      type={showPasswords.new ? 'text' : 'password'}
                      value={passwordForm.newPassword}
                      onChange={(e) => setPasswordForm(f => ({ ...f, newPassword: e.target.value }))}
                      className="pr-10"
                    />
                    <Button
                      type="button"
                      variant="ghost"
                      size="icon"
                      className="absolute right-0 top-0 h-full"
                      onClick={() => setShowPasswords(s => ({ ...s, new: !s.new }))}
                    >
                      {showPasswords.new ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                    </Button>
                  </div>
                  {passwordForm.newPassword && passwordForm.newPassword.length < 6 && (
                    <p className="text-xs text-warning mt-1 flex items-center gap-1">
                      <AlertCircle className="h-3 w-3" />
                      Minimum 6 caractères
                    </p>
                  )}
                </div>

                <div>
                  <Label className="text-xs">Confirmer le mot de passe</Label>
                  <div className="relative">
                    <Input
                      type={showPasswords.confirm ? 'text' : 'password'}
                      value={passwordForm.confirmPassword}
                      onChange={(e) => setPasswordForm(f => ({ ...f, confirmPassword: e.target.value }))}
                      className="pr-10"
                    />
                    <Button
                      type="button"
                      variant="ghost"
                      size="icon"
                      className="absolute right-0 top-0 h-full"
                      onClick={() => setShowPasswords(s => ({ ...s, confirm: !s.confirm }))}
                    >
                      {showPasswords.confirm ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                    </Button>
                  </div>
                  {passwordForm.confirmPassword && passwordForm.newPassword !== passwordForm.confirmPassword && (
                    <p className="text-xs text-danger mt-1 flex items-center gap-1">
                      <AlertCircle className="h-3 w-3" />
                      Les mots de passe ne correspondent pas
                    </p>
                  )}
                  {passwordForm.confirmPassword && passwordForm.newPassword === passwordForm.confirmPassword && passwordForm.newPassword.length >= 6 && (
                    <p className="text-xs text-success mt-1 flex items-center gap-1">
                      <Check className="h-3 w-3" />
                      Les mots de passe correspondent
                    </p>
                  )}
                </div>
              </CardContent>
            </Card>

            <Button 
              onClick={handleChangePassword} 
              disabled={isChangingPassword || !passwordForm.currentPassword || !passwordForm.newPassword || passwordForm.newPassword !== passwordForm.confirmPassword}
              className="w-full"
            >
              <Lock className="h-4 w-4 mr-2" />
              {isChangingPassword ? 'Modification en cours...' : 'Changer le Mot de Passe'}
            </Button>
          </div>
        );

      case 'synchronisation':
        return (
          <div className="max-w-2xl mx-auto space-y-6">
            {/* Connection Status */}
            <Card className={cn(
              isOnline ? 'border-success' : 'border-warning'
            )}>
              <CardContent className="p-4">
                <div className="flex items-center gap-4">
                  <div className={cn(
                    'p-3 rounded-full',
                    isOnline ? 'bg-success/20' : 'bg-warning/20'
                  )}>
                    {isOnline ? <Cloud className="h-6 w-6 text-success" /> : <WifiOff className="h-6 w-6 text-warning" />}
                  </div>
                  <div>
                    <p className="font-medium">{isOnline ? 'Connecté' : 'Hors ligne'}</p>
                    <p className="text-sm text-muted-foreground">
                      {isOnline 
                        ? 'Vous êtes connecté au serveur'
                        : 'Mode hors ligne - les données sont stockées localement'}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Sync Status */}
            <Card>
              <CardHeader className="py-4">
                <CardTitle className="text-sm flex items-center gap-2">
                  <Database className="h-4 w-4" />
                  État des Données Locales
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="p-4 rounded-lg bg-muted/50">
                    <p className="text-xs text-muted-foreground">Produits en cache</p>
                    <p className="text-2xl font-bold">{productsCount}</p>
                  </div>
                  <div className="p-4 rounded-lg bg-muted/50">
                    <p className="text-xs text-muted-foreground">Fournisseurs en cache</p>
                    <p className="text-2xl font-bold">{suppliersCount}</p>
                  </div>
                </div>

                <div className="p-4 rounded-lg bg-muted/50">
                  <p className="text-xs text-muted-foreground">Dernière synchronisation</p>
                  <p className="text-lg font-medium">
                    {lastSync 
                      ? new Date(lastSync).toLocaleString('fr-FR')
                      : 'Jamais synchronisé'}
                  </p>
                </div>

                {pendingQueueSize > 0 && (
                  <div className="p-4 rounded-lg bg-warning/10 border border-warning/30">
                    <p className="text-xs text-warning">Modifications en attente de synchronisation</p>
                    <p className="text-lg font-bold text-warning">{pendingQueueSize} opération(s)</p>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Sync Action */}
            <Card>
              <CardHeader className="py-4">
                <CardTitle className="text-sm flex items-center gap-2">
                  <RefreshCw className="h-4 w-4" />
                  Synchronisation Complète
                </CardTitle>
                <CardDescription>
                  Télécharge toutes les données du serveur pour un accès hors ligne complet
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label className="text-xs">Clé Supabase (Service Role)</Label>
                  <Input
                    type="password"
                    placeholder="Entrer la clé Supabase"
                    value={serviceKey}
                    onChange={(e) => setServiceKey(e.target.value)}
                  />
                </div>
                {isSyncing && (
                  <div className="space-y-2">
                    <Progress value={syncProgress} />
                    <p className="text-xs text-center text-muted-foreground">
                      Synchronisation en cours... {syncProgress}%
                    </p>
                  </div>
                )}
                
                <Button
                  variant="secondary"
                  onClick={handleSyncPush}
                  disabled={isSyncing || !isOnline || !serviceKey}
                  className="w-full"
                >
                  {isSyncing ? (
                    <>
                      <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                      Synchronisation...
                    </>
                  ) : (
                    <>
                      <RefreshCw className="h-4 w-4 mr-2" />
                      Synchroniser les changements locaux
                    </>
                  )}
                </Button>

                <Button 
                  onClick={handleInitialSync} 
                  disabled={isSyncing || !isOnline}
                  className="w-full"
                >
                  {isSyncing ? (
                    <>
                      <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                      Synchronisation...
                    </>
                  ) : (
                    <>
                      <RefreshCw className="h-4 w-4 mr-2" />
                      Synchroniser les Données
                    </>
                  )}
                </Button>

                {!isOnline && (
                  <p className="text-xs text-center text-warning">
                    Connexion internet requise pour synchroniser
                  </p>
                )}
              </CardContent>
            </Card>
          </div>
        );

      default:
        return <div className="p-8 text-center text-muted-foreground">Module non disponible</div>;
    }
  };

  return (
    <div className="h-full flex flex-col p-6 bg-[hsl(60,80%,85%)] dark:bg-transparent overflow-auto">
      {renderContent()}
    </div>
  );
}
