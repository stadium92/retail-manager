import { useState, useEffect, useMemo } from 'react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { 
  Search, CalendarIcon, FileText, Users, 
  ShoppingBag, Truck, Printer, Download, Eye, WifiOff, RefreshCw
} from 'lucide-react';
import { format, startOfDay, endOfDay, subDays } from 'date-fns';
import { fr } from 'date-fns/locale';
import { cn } from '@/lib/utils';
import { OfflineDataService, SaleWithItems } from '@/services/OfflineDataService';
import { useMasterDataStore } from '@/stores/useMasterDataStore';
import { toast } from 'sonner';

interface EditionModuleProps {
  storeId: string;
  mode: 'situation-client' | 'suivi-ventes-jour' | 'suivi-ventes-produit' | 
        'suivi-ventes-factures' | 'situation-fournisseur' | 'suivi-achats-famille' | 
        'suivi-achats-jour' | 'suivi-achats-periode';
}

interface ProductFamily {
  family_name: string;
  total_quantity: number;
  total_amount: number;
}

interface Supplier {
  id: string;
  name: string;
  balance: number;
  phone: string | null;
}

interface PurchaseOrder {
  id: string;
  created_at: string;
  total_amount: number;
  status: string;
  supplier?: { name: string };
}

const formatCurrency = (amount: number) => amount.toLocaleString('fr-FR') + ' F';

export function EditionModule({ storeId, mode }: EditionModuleProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [dateRange, setDateRange] = useState<{ from: Date; to: Date }>({
    from: startOfDay(new Date()),
    to: endOfDay(new Date()),
  });
  const [sales, setSales] = useState<SaleWithItems[]>([]);
  const [suppliers, setSuppliers] = useState<Supplier[]>([]);
  const [purchases, setPurchases] = useState<PurchaseOrder[]>([]);
  const [purchasesByFamily, setPurchasesByFamily] = useState<ProductFamily[]>([]);
  const [selectedItem, setSelectedItem] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isOffline, setIsOffline] = useState(!navigator.onLine);

  // Get suppliers from Zustand store for offline access
  const storeSuppliers = useMasterDataStore(state => state.suppliers);
  const storeProducts = useMasterDataStore(state => state.products);

  // Listen for online/offline changes
  useEffect(() => {
    const handleOnline = () => setIsOffline(false);
    const handleOffline = () => setIsOffline(true);
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  // Fetch data based on mode - uses OfflineDataService
  useEffect(() => {
    const fetchData = async () => {
      if (!storeId) return;
      setIsLoading(true);

      try {
        switch (mode) {
          case 'suivi-ventes-jour':
          case 'suivi-ventes-produit':
          case 'suivi-ventes-factures':
          case 'situation-client':
            // Use OfflineDataService for sales
            const salesData = await OfflineDataService.getSales(storeId, dateRange.from, dateRange.to);
            setSales(salesData);
            break;

          case 'situation-fournisseur':
            // Use Zustand store for suppliers (offline-capable)
            const offlineSuppliers = storeSuppliers
              .filter(s => s.store_id === storeId)
              .map(s => ({
                id: s.id,
                name: s.name,
                balance: s.balance,
                phone: s.phone || null,
              }));
            setSuppliers(offlineSuppliers);
            break;

          case 'suivi-achats-jour':
          case 'suivi-achats-periode':
            // Purchases need online access for now - show graceful message if offline
            if (!navigator.onLine) {
              setPurchases([]);
              toast.info('Historique des achats disponible uniquement en ligne');
            } else {
              // Dynamically import supabase only when online
              const { supabase } = await import('@/integrations/supabase/client');
              // Cast as any - purchase_orders table may not be in types yet
              const { data: purchaseData } = await (supabase as any)
                .from('purchase_orders')
                .select('*, supplier:suppliers(name)')
                .eq('store_id', storeId)
                .gte('created_at', dateRange.from.toISOString())
                .lte('created_at', dateRange.to.toISOString())
                .order('created_at', { ascending: false });
              setPurchases((purchaseData as any[]) || []);
            }
            break;

          case 'suivi-achats-famille':
            // Generate family data from local products if offline
            if (!navigator.onLine) {
              const familyMap: Record<string, { total_quantity: number; total_amount: number }> = {};
              storeProducts
                .filter(p => p.store_id === storeId)
                .forEach(p => {
                  const family = p.family_id || 'Non classé';
                  if (!familyMap[family]) {
                    familyMap[family] = { total_quantity: 0, total_amount: 0 };
                  }
                  familyMap[family].total_quantity += p.current_stock;
                  familyMap[family].total_amount += p.current_stock * (p.purchase_price || 0);
                });

              const familyData: ProductFamily[] = Object.entries(familyMap)
                .map(([family_name, data]) => ({
                  family_name,
                  total_quantity: data.total_quantity,
                  total_amount: data.total_amount,
                }))
                .sort((a, b) => b.total_amount - a.total_amount);

              setPurchasesByFamily(familyData);
              toast.info('Données estimées à partir du stock local');
            } else {
              const { supabase } = await import('@/integrations/supabase/client');
              // Cast as any - purchase_items/orders tables may not be in types yet
              const { data: poItems } = await (supabase as any)
                .from('purchase_items')
                .select(`quantity_ordered, unit_cost, order_id, product:products(category)`);

              const { data: ordersForFamily } = await (supabase as any)
                .from('purchase_orders')
                .select('id')
                .eq('store_id', storeId)
                .gte('created_at', dateRange.from.toISOString())
                .lte('created_at', dateRange.to.toISOString());

              const validOrderIds = new Set((ordersForFamily || []).map(o => o.id));

              const familyMap: Record<string, { total_quantity: number; total_amount: number }> = {};
              ((poItems as any[]) || []).forEach((item: any) => {
                if (!validOrderIds.has(item.order_id)) return;
                
                const family = item.product?.category || 'Non classé';
                if (!familyMap[family]) {
                  familyMap[family] = { total_quantity: 0, total_amount: 0 };
                }
                familyMap[family].total_quantity += item.quantity_ordered || 0;
                familyMap[family].total_amount += (item.quantity_ordered * item.unit_cost) || 0;
              });

              const familyData: ProductFamily[] = Object.entries(familyMap)
                .map(([family_name, data]) => ({
                  family_name,
                  total_quantity: data.total_quantity,
                  total_amount: data.total_amount,
                }))
                .sort((a, b) => b.total_amount - a.total_amount);

              setPurchasesByFamily(familyData);
            }
            break;
        }
      } catch (error) {
        console.error('Error fetching data:', error);
        toast.error('Erreur lors du chargement des données');
      }

      setIsLoading(false);
    };

    fetchData();
  }, [storeId, mode, dateRange, storeSuppliers, storeProducts]);

  // Aggregate sales by product
  const salesByProduct = useMemo(() => {
    const aggregated: Record<string, { name: string; quantity: number; total: number }> = {};
    sales.forEach(sale => {
      (sale.sale_items || []).forEach(item => {
        if (!aggregated[item.product_name]) {
          aggregated[item.product_name] = { name: item.product_name, quantity: 0, total: 0 };
        }
        aggregated[item.product_name].quantity += item.quantity;
        aggregated[item.product_name].total += item.total;
      });
    });
    return Object.values(aggregated).sort((a, b) => b.total - a.total);
  }, [sales]);

  // Filter by search
  const filteredSales = useMemo(() => 
    sales.filter(s => 
      !searchQuery || 
      s.customer_name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      s.invoice_number?.toLowerCase().includes(searchQuery.toLowerCase())
    ), [sales, searchQuery]);

  const filteredSuppliers = useMemo(() =>
    suppliers.filter(s => 
      !searchQuery || s.name.toLowerCase().includes(searchQuery.toLowerCase())
    ), [suppliers, searchQuery]);

  const totalSales = useMemo(() => 
    filteredSales.reduce((sum, s) => sum + s.total_price, 0), [filteredSales]);

  const totalPurchases = useMemo(() =>
    purchases.reduce((sum, p) => sum + p.total_amount, 0), [purchases]);

  // Offline indicator component
  const OfflineIndicator = () => isOffline ? (
    <div className="flex items-center gap-2 px-3 py-1 rounded-full bg-warning/20 text-warning text-xs">
      <WifiOff className="h-3 w-3" />
      <span>Mode hors ligne</span>
    </div>
  ) : null;

  // Render based on mode
  const renderContent = () => {
    switch (mode) {
      case 'situation-client':
        return (
          <div className="space-y-4">
            <div className="flex gap-4">
              <div className="flex-1">
                <Input
                  placeholder="Rechercher un client..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="h-9"
                />
              </div>
              <OfflineIndicator />
              <Button variant="outline" size="sm">
                <Search className="h-4 w-4 mr-2" />
                Rechercher
              </Button>
            </div>

            <Card>
              <CardHeader className="py-3">
                <CardTitle className="text-sm flex items-center gap-2">
                  <Users className="h-4 w-4" />
                  Historique Client
                </CardTitle>
              </CardHeader>
              <CardContent className="p-0">
                <ScrollArea className="h-[400px]">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead className="text-xs">Date</TableHead>
                        <TableHead className="text-xs">Client</TableHead>
                        <TableHead className="text-xs">N° Facture</TableHead>
                        <TableHead className="text-xs text-right">Montant</TableHead>
                        <TableHead className="text-xs text-center">Statut</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredSales.filter(s => s.customer_name).map(sale => (
                        <TableRow key={sale.id} className="h-10">
                          <TableCell className="text-xs">
                            {format(new Date(sale.created_at), 'dd/MM/yyyy HH:mm', { locale: fr })}
                          </TableCell>
                          <TableCell className="text-xs font-medium">{sale.customer_name}</TableCell>
                          <TableCell className="text-xs font-mono">{sale.invoice_number || '—'}</TableCell>
                          <TableCell className="text-xs text-right">{formatCurrency(sale.total_price)}</TableCell>
                          <TableCell className="text-center">
                            <span className={cn(
                              'px-2 py-0.5 rounded-full text-xs',
                              sale.payment_status === 'paid' ? 'bg-success/20 text-success' : 'bg-warning/20 text-warning'
                            )}>
                              {sale.payment_status === 'paid' ? 'Payé' : 'Crédit'}
                            </span>
                          </TableCell>
                        </TableRow>
                      ))}
                      {filteredSales.filter(s => s.customer_name).length === 0 && (
                        <TableRow>
                          <TableCell colSpan={5} className="text-center text-muted-foreground py-8">
                            Aucune vente client trouvée
                          </TableCell>
                        </TableRow>
                      )}
                    </TableBody>
                  </Table>
                </ScrollArea>
              </CardContent>
            </Card>
          </div>
        );

      case 'suivi-ventes-jour':
        return (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 text-sm">
                <CalendarIcon className="h-4 w-4" />
                <span className="font-medium">
                  Ventes du {format(dateRange.from, 'dd/MM/yyyy', { locale: fr })}
                </span>
                <OfflineIndicator />
              </div>
              <div className="flex items-center gap-4">
                <span className="text-lg font-bold text-primary">
                  Total: {formatCurrency(totalSales)}
                </span>
                <span className="text-sm text-muted-foreground">
                  {filteredSales.length} vente(s)
                </span>
              </div>
            </div>

            <Card>
              <CardContent className="p-0">
                <ScrollArea className="h-[450px]">
                  <Table>
                    <TableHeader className="sticky top-0 bg-background">
                      <TableRow>
                        <TableHead className="text-xs">Heure</TableHead>
                        <TableHead className="text-xs">Produit</TableHead>
                        <TableHead className="text-xs text-center">Qté</TableHead>
                        <TableHead className="text-xs text-right">P.U.</TableHead>
                        <TableHead className="text-xs text-right">Total</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredSales.flatMap(sale => 
                        (sale.sale_items || []).map(item => (
                          <TableRow key={item.id} className="h-9">
                            <TableCell className="text-xs">
                              {format(new Date(sale.created_at), 'HH:mm', { locale: fr })}
                            </TableCell>
                            <TableCell className="text-xs font-medium">{item.product_name}</TableCell>
                            <TableCell className="text-xs text-center">{item.quantity}</TableCell>
                            <TableCell className="text-xs text-right">{formatCurrency(item.unit_price)}</TableCell>
                            <TableCell className="text-xs text-right font-medium">{formatCurrency(item.total)}</TableCell>
                          </TableRow>
                        ))
                      )}
                      {filteredSales.length === 0 && (
                        <TableRow>
                          <TableCell colSpan={5} className="text-center text-muted-foreground py-8">
                            Aucune vente pour cette période
                          </TableCell>
                        </TableRow>
                      )}
                    </TableBody>
                  </Table>
                </ScrollArea>
              </CardContent>
            </Card>
          </div>
        );

      case 'suivi-ventes-produit':
        return (
          <div className="space-y-4">
            <div className="flex items-center gap-4">
              <Popover>
                <PopoverTrigger asChild>
                  <Button variant="outline" size="sm">
                    <CalendarIcon className="h-4 w-4 mr-2" />
                    {format(dateRange.from, 'dd/MM/yyyy')} - {format(dateRange.to, 'dd/MM/yyyy')}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0" align="start">
                  <Calendar
                    mode="range"
                    selected={{ from: dateRange.from, to: dateRange.to }}
                    onSelect={(range) => {
                      if (range?.from && range?.to) {
                        setDateRange({ from: startOfDay(range.from), to: endOfDay(range.to) });
                      }
                    }}
                    className="pointer-events-auto"
                  />
                </PopoverContent>
              </Popover>
              <Button variant="outline" size="sm" onClick={() => setDateRange({
                from: startOfDay(subDays(new Date(), 7)),
                to: endOfDay(new Date())
              })}>
                7 derniers jours
              </Button>
              <Button variant="outline" size="sm" onClick={() => setDateRange({
                from: startOfDay(subDays(new Date(), 30)),
                to: endOfDay(new Date())
              })}>
                30 derniers jours
              </Button>
              <OfflineIndicator />
            </div>

            <Card>
              <CardHeader className="py-3">
                <CardTitle className="text-sm flex items-center gap-2">
                  <ShoppingBag className="h-4 w-4" />
                  Ventes par Produit ({salesByProduct.length} produits)
                </CardTitle>
              </CardHeader>
              <CardContent className="p-0">
                <ScrollArea className="h-[400px]">
                  <Table>
                    <TableHeader className="sticky top-0 bg-background">
                      <TableRow>
                        <TableHead className="text-xs">#</TableHead>
                        <TableHead className="text-xs">Produit</TableHead>
                        <TableHead className="text-xs text-center">Quantité</TableHead>
                        <TableHead className="text-xs text-right">Total Ventes</TableHead>
                        <TableHead className="text-xs text-right">%</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {salesByProduct.map((item, idx) => (
                        <TableRow key={item.name} className="h-9">
                          <TableCell className="text-xs font-medium">{idx + 1}</TableCell>
                          <TableCell className="text-xs font-medium">{item.name}</TableCell>
                          <TableCell className="text-xs text-center">{item.quantity}</TableCell>
                          <TableCell className="text-xs text-right font-medium">{formatCurrency(item.total)}</TableCell>
                          <TableCell className="text-xs text-right text-muted-foreground">
                            {totalSales > 0 ? ((item.total / totalSales) * 100).toFixed(1) : 0}%
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </ScrollArea>
              </CardContent>
            </Card>
          </div>
        );

      case 'suivi-ventes-factures':
        return (
          <div className="space-y-4">
            <div className="flex gap-4">
              <Input
                placeholder="Rechercher facture..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-64 h-9"
              />
              <Popover>
                <PopoverTrigger asChild>
                  <Button variant="outline" size="sm">
                    <CalendarIcon className="h-4 w-4 mr-2" />
                    {format(dateRange.from, 'dd/MM/yyyy')} - {format(dateRange.to, 'dd/MM/yyyy')}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0" align="start">
                  <Calendar
                    mode="range"
                    selected={{ from: dateRange.from, to: dateRange.to }}
                    onSelect={(range) => {
                      if (range?.from && range?.to) {
                        setDateRange({ from: startOfDay(range.from), to: endOfDay(range.to) });
                      }
                    }}
                    className="pointer-events-auto"
                  />
                </PopoverContent>
              </Popover>
              <OfflineIndicator />
            </div>

            <Card>
              <CardHeader className="py-3">
                <CardTitle className="text-sm flex items-center gap-2">
                  <FileText className="h-4 w-4" />
                  Liste des Factures ({filteredSales.length})
                </CardTitle>
              </CardHeader>
              <CardContent className="p-0">
                <ScrollArea className="h-[400px]">
                  <Table>
                    <TableHeader className="sticky top-0 bg-background">
                      <TableRow>
                        <TableHead className="text-xs">N° Facture</TableHead>
                        <TableHead className="text-xs">Date</TableHead>
                        <TableHead className="text-xs">Client</TableHead>
                        <TableHead className="text-xs text-right">Montant</TableHead>
                        <TableHead className="text-xs text-center">Statut</TableHead>
                        <TableHead className="text-xs text-center">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredSales.map(sale => (
                        <TableRow key={sale.id} className="h-10">
                          <TableCell className="text-xs font-mono font-medium">
                            {sale.invoice_number || sale.id.slice(0, 8)}
                          </TableCell>
                          <TableCell className="text-xs">
                            {format(new Date(sale.created_at), 'dd/MM/yyyy HH:mm', { locale: fr })}
                          </TableCell>
                          <TableCell className="text-xs">{sale.customer_name || '—'}</TableCell>
                          <TableCell className="text-xs text-right font-medium">
                            {formatCurrency(sale.total_price)}
                          </TableCell>
                          <TableCell className="text-center">
                            <span className={cn(
                              'px-2 py-0.5 rounded-full text-xs',
                              sale.payment_status === 'paid' ? 'bg-success/20 text-success' : 'bg-warning/20 text-warning'
                            )}>
                              {sale.payment_status === 'paid' ? 'Payé' : 'Crédit'}
                            </span>
                          </TableCell>
                          <TableCell className="text-center">
                            <Button variant="ghost" size="sm" className="h-7 w-7 p-0">
                              <Eye className="h-3.5 w-3.5" />
                            </Button>
                            <Button variant="ghost" size="sm" className="h-7 w-7 p-0">
                              <Printer className="h-3.5 w-3.5" />
                            </Button>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </ScrollArea>
              </CardContent>
            </Card>
          </div>
        );

      case 'situation-fournisseur':
        return (
          <div className="space-y-4">
            <div className="flex gap-4">
              <div className="flex-1">
                <Input
                  placeholder="Rechercher un fournisseur..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="h-9"
                />
              </div>
              <OfflineIndicator />
            </div>

            <Card>
              <CardHeader className="py-3">
                <CardTitle className="text-sm flex items-center gap-2">
                  <Truck className="h-4 w-4" />
                  Situation Fournisseurs ({filteredSuppliers.length})
                </CardTitle>
              </CardHeader>
              <CardContent className="p-0">
                <ScrollArea className="h-[400px]">
                  <Table>
                    <TableHeader className="sticky top-0 bg-background">
                      <TableRow>
                        <TableHead className="text-xs">Fournisseur</TableHead>
                        <TableHead className="text-xs">Téléphone</TableHead>
                        <TableHead className="text-xs text-right">Solde</TableHead>
                        <TableHead className="text-xs text-center">Statut</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredSuppliers.map(supplier => (
                        <TableRow key={supplier.id} className="h-10">
                          <TableCell className="text-xs font-medium">{supplier.name}</TableCell>
                          <TableCell className="text-xs">{supplier.phone || '—'}</TableCell>
                          <TableCell className="text-xs text-right font-medium">
                            {formatCurrency(supplier.balance)}
                          </TableCell>
                          <TableCell className="text-center">
                            <span className={cn(
                              'px-2 py-0.5 rounded-full text-xs',
                              supplier.balance === 0 ? 'bg-success/20 text-success' : 
                              supplier.balance > 0 ? 'bg-warning/20 text-warning' : 'bg-danger/20 text-danger'
                            )}>
                              {supplier.balance === 0 ? 'Soldé' : supplier.balance > 0 ? 'Créditeur' : 'Débiteur'}
                            </span>
                          </TableCell>
                        </TableRow>
                      ))}
                      {filteredSuppliers.length === 0 && (
                        <TableRow>
                          <TableCell colSpan={4} className="text-center text-muted-foreground py-8">
                            Aucun fournisseur trouvé
                          </TableCell>
                        </TableRow>
                      )}
                    </TableBody>
                  </Table>
                </ScrollArea>
              </CardContent>
            </Card>
          </div>
        );

      case 'suivi-achats-jour':
      case 'suivi-achats-periode':
        return (
          <div className="space-y-4">
            <div className="flex items-center gap-4">
              <Popover>
                <PopoverTrigger asChild>
                  <Button variant="outline" size="sm">
                    <CalendarIcon className="h-4 w-4 mr-2" />
                    {format(dateRange.from, 'dd/MM/yyyy')} - {format(dateRange.to, 'dd/MM/yyyy')}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0" align="start">
                  <Calendar
                    mode="range"
                    selected={{ from: dateRange.from, to: dateRange.to }}
                    onSelect={(range) => {
                      if (range?.from && range?.to) {
                        setDateRange({ from: startOfDay(range.from), to: endOfDay(range.to) });
                      }
                    }}
                    className="pointer-events-auto"
                  />
                </PopoverContent>
              </Popover>
              <OfflineIndicator />
              <span className="text-lg font-bold text-primary ml-auto">
                Total: {formatCurrency(totalPurchases)}
              </span>
            </div>

            <Card>
              <CardHeader className="py-3">
                <CardTitle className="text-sm flex items-center gap-2">
                  <ShoppingBag className="h-4 w-4" />
                  Commandes d'Achat ({purchases.length})
                </CardTitle>
              </CardHeader>
              <CardContent className="p-0">
                <ScrollArea className="h-[400px]">
                  {isOffline && purchases.length === 0 ? (
                    <div className="flex flex-col items-center justify-center py-12 text-muted-foreground">
                      <WifiOff className="h-12 w-12 mb-4 opacity-30" />
                      <p>Historique des achats disponible uniquement en ligne</p>
                    </div>
                  ) : (
                    <Table>
                      <TableHeader className="sticky top-0 bg-background">
                        <TableRow>
                          <TableHead className="text-xs">Date</TableHead>
                          <TableHead className="text-xs">Fournisseur</TableHead>
                          <TableHead className="text-xs text-right">Montant</TableHead>
                          <TableHead className="text-xs text-center">Statut</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {purchases.map(po => (
                          <TableRow key={po.id} className="h-10">
                            <TableCell className="text-xs">
                              {format(new Date(po.created_at), 'dd/MM/yyyy', { locale: fr })}
                            </TableCell>
                            <TableCell className="text-xs font-medium">{po.supplier?.name || '—'}</TableCell>
                            <TableCell className="text-xs text-right font-medium">
                              {formatCurrency(po.total_amount)}
                            </TableCell>
                            <TableCell className="text-center">
                              <span className={cn(
                                'px-2 py-0.5 rounded-full text-xs',
                                po.status === 'completed' ? 'bg-success/20 text-success' : 'bg-warning/20 text-warning'
                              )}>
                                {po.status === 'completed' ? 'Reçu' : 'En cours'}
                              </span>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  )}
                </ScrollArea>
              </CardContent>
            </Card>
          </div>
        );

      case 'suivi-achats-famille':
        return (
          <div className="space-y-4">
            <div className="flex items-center gap-4">
              <Popover>
                <PopoverTrigger asChild>
                  <Button variant="outline" size="sm">
                    <CalendarIcon className="h-4 w-4 mr-2" />
                    {format(dateRange.from, 'dd/MM/yyyy')} - {format(dateRange.to, 'dd/MM/yyyy')}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0" align="start">
                  <Calendar
                    mode="range"
                    selected={{ from: dateRange.from, to: dateRange.to }}
                    onSelect={(range) => {
                      if (range?.from && range?.to) {
                        setDateRange({ from: startOfDay(range.from), to: endOfDay(range.to) });
                      }
                    }}
                    className="pointer-events-auto"
                  />
                </PopoverContent>
              </Popover>
              <OfflineIndicator />
            </div>

            <Card>
              <CardHeader className="py-3">
                <CardTitle className="text-sm flex items-center gap-2">
                  <ShoppingBag className="h-4 w-4" />
                  Achats par Famille de Produits
                </CardTitle>
              </CardHeader>
              <CardContent className="p-0">
                <ScrollArea className="h-[400px]">
                  <Table>
                    <TableHeader className="sticky top-0 bg-background">
                      <TableRow>
                        <TableHead className="text-xs">Famille</TableHead>
                        <TableHead className="text-xs text-center">Quantité Totale</TableHead>
                        <TableHead className="text-xs text-right">Montant Total</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {purchasesByFamily.map((family) => (
                        <TableRow key={family.family_name} className="h-10">
                          <TableCell className="text-xs font-medium">{family.family_name}</TableCell>
                          <TableCell className="text-xs text-center">{family.total_quantity}</TableCell>
                          <TableCell className="text-xs text-right font-medium">
                            {formatCurrency(family.total_amount)}
                          </TableCell>
                        </TableRow>
                      ))}
                      {purchasesByFamily.length === 0 && (
                        <TableRow>
                          <TableCell colSpan={3} className="text-center text-muted-foreground py-8">
                            Aucune donnée disponible
                          </TableCell>
                        </TableRow>
                      )}
                    </TableBody>
                  </Table>
                </ScrollArea>
              </CardContent>
            </Card>
          </div>
        );

      default:
        return <div className="text-center py-8 text-muted-foreground">Mode non reconnu</div>;
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-full">
        <RefreshCw className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="h-full overflow-auto p-4">
      {renderContent()}
    </div>
  );
}
