import { useState, useEffect, useCallback } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import { getDataClient } from '@/lib/dataClient';
import { OfflineAuthService } from '@/services/OfflineAuthService';
import { OfflineSalesService } from '@/services/OfflineSalesService';
import { Product } from '@/types';
import { Plus, Trash2, Check, ScanBarcode } from 'lucide-react';
import { BarcodeScanner } from '@/components/shared/BarcodeScanner';
import { toast } from '@/hooks/use-toast';
import { OfflineManager } from '@/services/OfflineManager';
import { useTranslation } from 'react-i18next';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';

interface SaleItem {
  product: Product;
  quantity: number;
  price: number;
}

export function SalesEntryForm() {
  const { user } = useAuth();
  const { t } = useTranslation();
  const [products, setProducts] = useState<Product[]>([]);
  const [selectedItems, setSelectedItems] = useState<SaleItem[]>([]);
  const [customerName, setCustomerName] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');
  const [needsDelivery, setNeedsDelivery] = useState(false);
  const [deliveryAddress, setDeliveryAddress] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [storeId, setStoreId] = useState<string>('');
  const [isScanning, setIsScanning] = useState(false);
  const { supabase, isLocalFirst, localBridgeBaseUrl } = getDataClient();

  const useLocalBridge = isLocalFirst;

  const localBridgeRequest = useCallback(async <T,>(path: string, init: RequestInit = {}) => {
    if (!useLocalBridge) {
      throw new Error('LocalBridge mode is not enabled.');
    }

    const headers = await OfflineAuthService.getAuthHeaders();
    if (!headers) {
      throw new Error('LocalBridge session expired. Please sign in again.');
    }

    const response = await fetch(`${localBridgeBaseUrl}${path}`, {
      ...init,
      headers: {
        'Content-Type': 'application/json',
        ...(init.headers || {}),
        ...headers,
      },
    });

    let payload: any = null;
    if (response.status !== 204) {
      try {
        payload = await response.json();
      } catch (error) {
        // ignore
      }
    }

    if (!response.ok) {
      const message = payload?.message || 'LocalBridge request failed';
      throw new Error(message);
    }

    return payload as T;
  }, [localBridgeBaseUrl, useLocalBridge]);

  // Move function declarations before useEffect calls
  const fetchUserStore = useCallback(async () => {
    if (!user) return;

    if (useLocalBridge) {
      const metaStoreId = user.user_metadata?.store_id;
      if (metaStoreId) {
        setStoreId(metaStoreId);
        return;
      }
      toast({
        title: t('worker.sales.noStoreAssigned'),
        description: t('worker.sales.contactManager'),
        variant: 'destructive',
      });
      return;
    }

    // Get worker's assigned store from user_roles
    const { data, error } = await supabase
      .from('user_roles')
      .select('store_id')
      .eq('user_id', user.id)
      .eq('role', 'worker')
      .single();

    if (error) {
      console.error('Error fetching worker store:', error);
      toast({
        title: t('common.error'),
        description: t('worker.sales.couldNotLoadStore'),
        variant: 'destructive',
      });
      return;
    }

    if (data?.store_id) {
      setStoreId(data.store_id);
    } else {
      toast({
        title: t('worker.sales.noStoreAssigned'),
        description: t('worker.sales.contactManager'),
        variant: 'destructive',
      });
    }
  }, [t, useLocalBridge, user, supabase, toast]);

  const fetchProducts = useCallback(async () => {
    try {
      if (useLocalBridge) {
        const params = new URLSearchParams();
        params.set('store_id', storeId);
        const data = await localBridgeRequest<Product[]>(`/rest/v1/products?${params.toString()}`);
        const filtered = (data || []).filter((item) => (item.quantity || 0) > 0);
        if (filtered) {
          const mappedProducts: Product[] = filtered.map(item => ({
            id: item.id,
            store_id: item.store_id,
            name: item.name,
            description: item.description,
            sku: item.sku,
            unit_price: Number(item.unit_price) || 0,
            cost_price: Number(item.cost_price) || 0,
            quantity: item.quantity,
            min_quantity: item.min_quantity,
            image_url: item.image_url,
            created_at: item.created_at,
            updated_at: item.updated_at,
          }));
          setProducts(mappedProducts);
        }
        return;
      }

      const { data } = await supabase
        .from('products')
        .select('*')
        .eq('store_id', storeId)
        .gt('quantity', 0);

      if (data) {
        // Map products to Product interface
        const mappedProducts: Product[] = data.map(item => ({
          id: item.id,
          store_id: item.store_id,
          name: item.name,
          description: item.description,
          sku: item.sku,
          unit_price: Number(item.unit_price) || 0,
          cost_price: Number(item.cost_price) || 0,
          quantity: item.quantity,
          min_quantity: item.min_quantity,
          image_url: item.image_url,
          created_at: item.created_at,
          updated_at: item.updated_at,
        }));
        setProducts(mappedProducts);
      }
    } catch (error) {
      console.error('Failed to fetch products', error);
      toast({
        title: t('common.error'),
        description: t('common.failedToLoad'),
        variant: 'destructive',
      });
    }
  }, [localBridgeRequest, storeId, supabase, t, useLocalBridge, toast]);

  useEffect(() => {
    fetchUserStore();
  }, [fetchUserStore]);

  useEffect(() => {
    if (storeId) {
      fetchProducts();
    }
  }, [storeId, fetchProducts]);

  // Functions moved above useEffect calls

  const addItem = (productId: string) => {
    const product = products.find(p => p.id === productId);
    if (!product) return;

    const existing = selectedItems.find(si => si.product.id === productId);
    if (existing) {
      toast({
        title: t('worker.sales.itemAlreadyAdded'),
        description: t('worker.sales.adjustQuantity'),
        variant: 'destructive',
      });
      return;
    }

    setSelectedItems([...selectedItems, {
      product,
      quantity: 1,
      price: Number(product.unit_price),
    }]);
  };

  const updateQuantity = (productId: string, quantity: number) => {
    setSelectedItems(selectedItems.map(si =>
      si.product.id === productId ? { ...si, quantity } : si
    ));
  };

  const removeItem = (productId: string) => {
    setSelectedItems(selectedItems.filter(si => si.product.id !== productId));
  };

  const calculateTotal = () => {
    return selectedItems.reduce((sum, si) => sum + (si.price * si.quantity), 0);
  };

  const handleSubmit = async () => {
    if (selectedItems.length === 0) {
      toast({
        title: t('worker.sales.noItems'),
        description: t('worker.sales.addAtLeastOne'),
        variant: 'destructive',
      });
      return;
    }

    if (needsDelivery && !deliveryAddress.trim()) {
      toast({
        title: t('worker.sales.deliveryAddressRequired'),
        variant: 'destructive',
      });
      return;
    }

    setSubmitting(true);

    try {
        if (!useLocalBridge && OfflineManager.isOnline()) {
        // Get first item for required item_id field
        const firstItem = selectedItems[0];
        
        const { data: sale, error } = await supabase
          .from('sales')
          .insert([{
            store_id: storeId,
            worker_id: user?.id,
            customer_name: customerName || null,
            customer_phone: customerPhone || null,
            item_id: firstItem.product.id, // Required field
            unit_price: firstItem.price,
            quantity: selectedItems.reduce((sum, si) => sum + si.quantity, 0),
            total_price: calculateTotal(),
            notes: null,
          }])
          .select()
          .single();

        if (error) throw error;

        // Create sale items
        const saleItems = selectedItems.map(si => ({
          sale_id: sale.id,
          product_id: si.product.id,
          product_name: si.product.name,
          quantity: si.quantity,
          unit_price: si.price,
          total: si.price * si.quantity,
        }));

        await supabase.from('sale_items').insert(saleItems);

        // Create delivery if needed
        if (needsDelivery) {
          await supabase.from('deliveries').insert([{
            sale_id: sale.id,
            store_id: storeId,
            customer_name: customerName,
            customer_phone: customerPhone,
            delivery_address: deliveryAddress,
            status: 'pending',
          }]);
        }

        toast({
          title: t('worker.sales.saleRecorded'),
          description: t('worker.sales.itemsSold', { count: selectedItems.length, total: `$${calculateTotal().toFixed(2)}` }),
        });
        } else {
          if (useLocalBridge) {
            const saleResult = await OfflineSalesService.createSale({
              store_id: storeId,
              worker_id: user?.id || '',
              items: selectedItems.map((item) => ({
                product: item.product,
                quantity: item.quantity,
                discount: 0,
                unitPrice: item.price,
                lineTotal: item.price * item.quantity,
                total: item.price * item.quantity,
              })),
              total_price: calculateTotal(),
              payment_method: 'cash',
              sale_type: 'detail',
              customer_name: customerName,
              customer_phone: customerPhone,
            });
            if (saleResult.error) {
              throw saleResult.error;
            }
            toast({
              title: t('worker.sales.saleQueued'),
              description: t('worker.sales.itemsQueued', { count: selectedItems.length, total: `$${calculateTotal().toFixed(2)}` }),
            });
          } else {
            const offlineSaleData = {
              store_id: storeId,
              worker_id: user?.id,
              customer_name: customerName,
              customer_phone: customerPhone,
              total_price: calculateTotal(),
              items: selectedItems,
            };
            OfflineManager.addToQueue('sale', offlineSaleData);
            toast({
              title: t('worker.sales.saleQueued'),
              description: t('worker.sales.itemsQueued', { count: selectedItems.length, total: `$${calculateTotal().toFixed(2)}` }),
            });
          }
        }

      // Reset form
      setSelectedItems([]);
      setCustomerName('');
      setCustomerPhone('');
      setNeedsDelivery(false);
      setDeliveryAddress('');

      // Refresh products if online
      if (!useLocalBridge && OfflineManager.isOnline()) {
        fetchProducts();
      }
    } catch (error) {
      console.error('Sale error:', error);
      toast({
        title: t('common.error'),
        description: t('worker.sales.errorRecording'),
        variant: 'destructive',
      });
    } finally {
      setSubmitting(false);
    }
  };

  const handleScanResult = (result: string) => {
    // Find product by SKU or barcode
    const scannedProduct = products.find(
      (p) => p.sku?.toLowerCase() === result.toLowerCase() || p.barcode?.toLowerCase() === result.toLowerCase()
    );

    if (scannedProduct) {
      toast({
        title: t('common.success'),
        description: t('worker.sales.itemFound', { name: scannedProduct.name }),
      });
      addItem(scannedProduct.id);
    } else {
      toast({
        title: t('common.error'),
        description: t('worker.sales.itemNotFound'),
        variant: 'destructive',
      });
    }
    setIsScanning(false);
  };

  return (
    <Card>
      <BarcodeScanner
        isScanning={isScanning}
        onResult={handleScanResult}
        onClose={() => setIsScanning(false)}
      />
      <CardHeader>
        <CardTitle>{t('worker.sales.newSale')}</CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Product Selection */}
        <div className="space-y-2">
          <Label>{t('worker.sales.addItem')}</Label>
          <div className="flex gap-2">
            <Select onValueChange={addItem}>
              <SelectTrigger className="flex-1">
                <SelectValue placeholder={t('worker.sales.selectItem')} />
              </SelectTrigger>
              <Button
                variant="outline"
                size="icon"
                onClick={() => setIsScanning(true)}
                className="ml-2 shrink-0"
                title={t('common.scanBarcode')}
              >
                <ScanBarcode className="h-4 w-4" />
              </Button>
              <SelectContent>
                {products.map(product => (
                  <SelectItem key={product.id} value={product.id}>
                    {product.name} - ${Number(product.unit_price).toFixed(2)} ({product.quantity} {t('worker.sales.inStock')})
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>

        {/* Selected Items */}
        {selectedItems.length > 0 && (
          <div className="space-y-3">
            <Label>{t('worker.sales.items', { count: selectedItems.length })}</Label>
            {selectedItems.map(si => (
              <div key={si.product.id} className="flex items-center gap-3 p-3 bg-muted rounded-lg">
                <div className="flex-1">
                  <p className="font-medium">{si.product.name}</p>
                  <p className="text-sm text-muted-foreground">
                    ${si.price.toFixed(2)} {t('worker.sales.each')}
                  </p>
                </div>
                <Input
                  type="number"
                  min="1"
                  max={si.product.quantity}
                  value={si.quantity}
                  onChange={(e) => updateQuantity(si.product.id, parseInt(e.target.value) || 1)}
                  className="w-20"
                />
                <p className="font-medium w-24 text-right">
                  ${(si.price * si.quantity).toFixed(2)}
                </p>
                <Button
                  size="icon"
                  variant="ghost"
                  onClick={() => removeItem(si.product.id)}
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
              </div>
            ))}

            <div className="flex justify-between items-center pt-3 border-t">
              <span className="text-lg font-semibold">{t('worker.sales.total')}</span>
              <span className="text-2xl font-bold">${calculateTotal().toFixed(2)}</span>
            </div>
          </div>
        )}

        {/* Customer Info */}
        <div className="grid gap-4 md:grid-cols-2">
          <div className="space-y-2">
            <Label htmlFor="customer-name">{t('worker.sales.customerName')}</Label>
            <Input
              id="customer-name"
              value={customerName}
              onChange={(e) => setCustomerName(e.target.value)}
              placeholder={t('worker.sales.enterCustomerName')}
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="customer-phone">{t('worker.sales.customerPhone')}</Label>
            <Input
              id="customer-phone"
              value={customerPhone}
              onChange={(e) => setCustomerPhone(e.target.value)}
              placeholder={t('worker.sales.enterPhone')}
            />
          </div>
        </div>

        {/* Delivery Option */}
        <div className="space-y-3">
          <div className="flex items-center space-x-2">
            <Checkbox
              id="needs-delivery"
              checked={needsDelivery}
              onCheckedChange={(checked) => setNeedsDelivery(checked as boolean)}
            />
            <Label htmlFor="needs-delivery" className="cursor-pointer">
              {t('worker.sales.needsDelivery')}
            </Label>
          </div>

          {needsDelivery && (
            <div className="space-y-2">
              <Label htmlFor="delivery-address">{t('worker.sales.deliveryAddress')}</Label>
              <Input
                id="delivery-address"
                value={deliveryAddress}
                onChange={(e) => setDeliveryAddress(e.target.value)}
                placeholder={t('worker.sales.enterDeliveryAddress')}
                required
              />
            </div>
          )}
        </div>

        {/* Submit Button */}
        <Button
          onClick={handleSubmit}
          disabled={submitting || selectedItems.length === 0}
          className="w-full"
          size="lg"
        >
          {submitting ? (
            t('worker.sales.recording')
          ) : (
            <>
              <Check className="h-5 w-5 mr-2" />
              {t('worker.sales.recordSale')} - ${calculateTotal().toFixed(2)}
            </>
          )}
        </Button>
      </CardContent>
    </Card>
  );
}
