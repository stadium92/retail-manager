import { useState, useEffect } from 'react';
import { SaleMode } from './SanifereHeader';
import { cn } from '@/lib/utils';

interface SanifereFooterProps {
  mode: SaleMode;
  netTotal: number;
  onValidate?: () => void;
  onSettlement?: () => void;
  onPrint?: () => void;
  onInsert?: () => void;
  onDelete?: () => void;
  onProductCard?: () => void;
  onTicket?: () => void;
  onPriceChange?: () => void;
  onHelp?: () => void;
  onSelect?: () => void;
}

const formatCurrency = (amount: number) => amount.toLocaleString('fr-FR');

// F-Key buttons mapping - aligned with User Request
const functionKeys = [
  { key: 'F2', label: 'Aide', action: 'help' },
  { key: 'F3', label: 'Valide', action: 'validate' },
  { key: 'F4', label: 'Sél', action: 'select' },
  { key: 'F5', label: 'Règlt', action: 'settlement' },
  { key: 'F6', label: 'Fiche', action: 'productCard' },
  { key: 'F7', label: 'Impr', action: 'print' },
  { key: 'F8', label: 'Ins', action: 'insert' },
  { key: 'F10', label: 'Suppr', action: 'delete' },
  { key: 'F11', label: 'Ticket', action: 'ticket' },
  { key: 'P', label: 'Prix', action: 'priceChange' }, // Assuming 'P' or just button for Prix based on "Prix" at end
] as const;

export function SanifereFooter({
  mode,
  netTotal,
  onValidate,
  onSettlement,
  onPrint,
  onInsert,
  onDelete,
  onProductCard,
  onTicket,
  onPriceChange,
  onHelp,
  onSelect,
}: SanifereFooterProps) {
  const [pressedKey, setPressedKey] = useState<string | null>(null);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      setPressedKey(e.key);
      // Optional: triggering actions here would duplicate SalesModule logic, 
      // but purely visual feedback is safe.
    };
    const handleKeyUp = () => setPressedKey(null);
    
    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
    };
  }, []);

  const handleAction = (action: string) => {
    switch (action) {
      case 'validate': onValidate?.(); break;
      case 'select': onSelect?.(); break;
      case 'settlement': onSettlement?.(); break; // F5
      case 'productCard': onProductCard?.(); break; // F6
      case 'print': onPrint?.(); break;
      case 'insert': onInsert?.(); break;
      case 'delete': onDelete?.(); break; // F10
      case 'ticket': onTicket?.(); break;
      case 'priceChange': onPriceChange?.(); break;
      case 'help': onHelp?.(); break;
    }
  };

  const isActive = (k: string) => pressedKey === k;

  return (
    <div className="bg-[hsl(220,20%,90%)] border-t-2 border-black/30 font-mono select-none">
      {/* NET A PAYER line */}
      <div className="flex items-center justify-end px-4 py-2 bg-white/80 border-b border-black/10">
        <span className="text-lg font-bold text-black mr-4 uppercase">Net à payer</span>
        <span className="text-3xl font-bold text-black bg-[hsl(50,100%,60%)] px-6 py-1 min-w-[200px] text-right shadow-inner border border-black/20">
          {formatCurrency(netTotal)}
        </span>
      </div>

      {/* Function keys bar */}
      <div className="flex items-center gap-1.5 px-2 py-2 bg-[hsl(220,15%,80%)] overflow-x-auto shadow-[inset_0_2px_4px_rgba(0,0,0,0.1)]">
        {functionKeys.map((fk) => (
          <button
            key={fk.key}
            onClick={() => handleAction(fk.action)}
            className={cn(
              "relative flex flex-col items-center justify-center min-w-[60px] h-[50px] px-2",
              "bg-gradient-to-b from-[#f0f0f0] to-[#d0d0d0]",
              "border border-b-2 border-r-2 border-white/50 border-b-black/40 border-r-black/40",
              "rounded-sm text-xs font-bold text-black shadow-sm transition-all active:translate-y-0.5 active:shadow-none",
              isActive(fk.key) && "bg-gradient-to-b from-[#e0e0e0] to-[#c0c0c0] translate-y-0.5 shadow-none border-t-black/20 border-l-black/20"
            )}
          >
            <span className="text-[hsl(0,70%,45%)] mb-0.5 text-sm">{fk.key}</span>
            <span className="uppercase tracking-tight leading-none text-[10px]">{fk.label}</span>
          </button>
        ))}
        
        {/* Helper text for detail mode if needed, or unify */}
      </div>
    </div>
  );
}
