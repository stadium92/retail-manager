import { useState } from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { cn } from '@/lib/utils';
import { SaleMode } from './SanifereHeader';

interface PaymentDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  mode: SaleMode;
  totalAmount: number;
  onConfirm: (paymentMethod: string, amountPaid: number, isCredit: boolean) => void;
}

const formatCurrency = (amount: number) => amount.toLocaleString('fr-FR');

type PaymentMethod = 'cash' | 'card' | 'mobile' | 'credit';

const paymentMethods: { id: PaymentMethod; label: string; icon: string }[] = [
  { id: 'cash', label: 'Espèces', icon: '💵' },
  { id: 'card', label: 'Carte', icon: '💳' },
  { id: 'mobile', label: 'Mobile', icon: '📱' },
  { id: 'credit', label: 'Crédit', icon: '📝' },
];

export function PaymentDialog({
  open,
  onOpenChange,
  mode,
  totalAmount,
  onConfirm,
}: PaymentDialogProps) {
  const [selectedMethod, setSelectedMethod] = useState<PaymentMethod>('cash');
  const [amountReceived, setAmountReceived] = useState<number>(totalAmount);
  const [partialPayment, setPartialPayment] = useState<number>(0);

  const isCredit = selectedMethod === 'credit';
  const change = amountReceived - totalAmount;
  const remaining = isCredit ? totalAmount - partialPayment : 0;

  const handleConfirm = () => {
    const amountPaid = isCredit ? partialPayment : amountReceived;
    onConfirm(selectedMethod, amountPaid, isCredit);
    onOpenChange(false);
  };

  const quickAmounts = [1000, 2000, 5000, 10000, 25000, 50000];

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md bg-[hsl(180,60%,85%)] border-4 border-[hsl(180,60%,40%)] p-0">
        <DialogHeader className="bg-[hsl(180,60%,40%)] px-4 py-3">
          <DialogTitle className="text-white font-mono text-lg">
            RÈGLEMENT - {mode === 'vente-detail' ? 'Vente' : 'Facture'}
          </DialogTitle>
        </DialogHeader>

        <div className="p-4 space-y-4">
          {/* Total */}
          <div className="bg-[hsl(50,100%,60%)] p-4 rounded text-center">
            <p className="text-sm font-mono text-black/70">NET A PAYER</p>
            <p className="text-3xl font-bold font-mono text-black">
              {formatCurrency(totalAmount)} F CFA
            </p>
          </div>

          {/* Payment Methods */}
          <div className="grid grid-cols-4 gap-2">
            {paymentMethods.map((method) => (
              <button
                key={method.id}
                onClick={() => setSelectedMethod(method.id)}
                className={cn(
                  'p-3 rounded border-2 font-mono text-sm flex flex-col items-center gap-1 transition-all',
                  selectedMethod === method.id
                    ? 'bg-[hsl(220,100%,35%)] text-white border-[hsl(220,100%,25%)]'
                    : 'bg-white text-black border-black/20 hover:border-black/40'
                )}
              >
                <span className="text-xl">{method.icon}</span>
                <span className="text-xs">{method.label}</span>
              </button>
            ))}
          </div>

          {/* Amount input - for cash */}
          {selectedMethod === 'cash' && (
            <div className="space-y-3">
              <div>
                <Label className="font-mono text-sm">Montant reçu</Label>
                <Input
                  type="number"
                  value={amountReceived}
                  onChange={(e) => setAmountReceived(Number(e.target.value))}
                  className="text-xl font-bold font-mono text-right bg-white"
                />
              </div>

              {/* Quick amounts */}
              <div className="grid grid-cols-3 gap-2">
                {quickAmounts.map((amt) => (
                  <Button
                    key={amt}
                    variant="outline"
                    size="sm"
                    onClick={() => setAmountReceived(amt)}
                    className="font-mono text-xs"
                  >
                    {formatCurrency(amt)}
                  </Button>
                ))}
              </div>

              {/* Change */}
              {change >= 0 && (
                <div className="bg-green-100 p-3 rounded border border-green-300">
                  <p className="text-sm font-mono text-green-800">Monnaie à rendre</p>
                  <p className="text-2xl font-bold font-mono text-green-700">
                    {formatCurrency(change)} F
                  </p>
                </div>
              )}
              {change < 0 && (
                <div className="bg-red-100 p-3 rounded border border-red-300">
                  <p className="text-sm font-mono text-red-800">Montant insuffisant</p>
                  <p className="text-lg font-bold font-mono text-red-700">
                    Manque: {formatCurrency(Math.abs(change))} F
                  </p>
                </div>
              )}
            </div>
          )}

          {/* Credit/Partial payment */}
          {isCredit && (
            <div className="space-y-3">
              <div>
                <Label className="font-mono text-sm">Acompte (optionnel)</Label>
                <Input
                  type="number"
                  value={partialPayment}
                  onChange={(e) => setPartialPayment(Number(e.target.value))}
                  max={totalAmount}
                  className="text-lg font-bold font-mono text-right bg-white"
                />
              </div>
              <div className="bg-orange-100 p-3 rounded border border-orange-300">
                <p className="text-sm font-mono text-orange-800">Reste à payer</p>
                <p className="text-2xl font-bold font-mono text-orange-700">
                  {formatCurrency(remaining)} F
                </p>
              </div>
            </div>
          )}
        </div>

        <DialogFooter className="px-4 pb-4">
          <Button
            variant="outline"
            onClick={() => onOpenChange(false)}
            className="font-mono"
          >
            Annuler (Esc)
          </Button>
          <Button
            onClick={handleConfirm}
            disabled={selectedMethod === 'cash' && change < 0}
            className="font-mono bg-[hsl(120,70%,35%)] hover:bg-[hsl(120,70%,30%)]"
          >
            Valider (F4)
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
