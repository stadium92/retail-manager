import { useState, useEffect } from 'react';
import { format } from 'date-fns';
import { fr } from 'date-fns/locale';

export type SaleMode = 'vente-detail' | 'facturation-detail' | 'facturation-gros' | 'proforma';

interface SanifereHeaderProps {
  mode: SaleMode;
  invoiceNumber?: string;
  customerCode?: string;
  customerName?: string;
  customerAddress?: string;
  orderRef?: string;
  onCustomerChange?: (code: string, name: string, address: string) => void;
  onOrderRefChange?: (ref: string) => void;
  onInvoiceNumberChange?: (num: string) => void; // Added for editable reference
}

const modeBgColors: Record<SaleMode, string> = {
  'vente-detail': 'bg-[hsl(120,100%,35%)]', // Bright green
  'facturation-detail': 'bg-[hsl(120,100%,35%)]',
  'facturation-gros': 'bg-[hsl(120,100%,35%)]',
  'proforma': 'bg-[hsl(120,100%,35%)]',
};

const modeLabels: Record<SaleMode, string> = {
  'vente-detail': 'VENTE AU DÉTAIL',
  'facturation-detail': 'FACTURE DÉTAIL',
  'facturation-gros': 'FACTURE GROS',
  'proforma': 'FACTURE PROFORMA',
};

export function SanifereHeader({
  mode,
  invoiceNumber,
  customerCode = '',
  customerName = '',
  customerAddress = '',
  orderRef = '',
  onCustomerChange,
  onOrderRefChange,
  onInvoiceNumberChange,
}: SanifereHeaderProps) {
  const [currentTime, setCurrentTime] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  const isSimpleSale = mode === 'vente-detail';
  const dateStr = format(currentTime, 'EEEE dd/MM/yyyy', { locale: fr });
  const timeStr = format(currentTime, 'HH:mm:ss');

  // Generate invoice number if not provided
  const displayInvoiceNumber = invoiceNumber || format(currentTime, 'yyMMdd') + '0001';

  if (isSimpleSale) {
    // Simple header for Vente au Détail
    return (
      <div className={`${modeBgColors[mode]} text-black font-mono`}>
        {/* Title line */}
        <div className="px-3 py-1">
          <div className="text-lg font-bold tracking-wide text-[hsl(60,100%,50%)]">
            {modeLabels[mode]}
          </div>
          <div className="text-sm capitalize">{dateStr}</div>
        </div>
        {/* Time and reference */}
        <div className="px-3 pb-1 flex items-center gap-6 text-sm">
          <span className="bg-white/90 px-2 py-0.5 text-black font-bold">
            {timeStr}
          </span>
          <div className="flex items-center gap-2">
            <span>N° Réf:</span>
            {onInvoiceNumberChange ? (
              <input 
                type="text" 
                value={invoiceNumber || ''} 
                onChange={(e) => onInvoiceNumberChange(e.target.value)}
                className="bg-white/90 px-2 py-0.5 text-black font-bold w-32 border-none focus:ring-2 focus:ring-blue-500"
              />
            ) : (
              <span className="bg-white/90 px-2 py-0.5 text-black font-bold">{displayInvoiceNumber}</span>
            )}
          </div>
        </div>
      </div>
    );
  }

  // Full header for Facture Détail, Facture Gros, Proforma
  return (
    <div className={`${modeBgColors[mode]} text-black font-mono`}>
      {/* Title bar with decorative lines */}
      <div className="px-3 py-1 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <span className="text-[hsl(180,100%,50%)]">═══</span>
          <span className="text-lg font-bold tracking-wide text-[hsl(60,100%,50%)] px-2 border border-[hsl(180,100%,50%)]">
            {modeLabels[mode]}
          </span>
          <span className="text-[hsl(180,100%,50%)]">═══</span>
        </div>
        <div className="flex items-center gap-4 text-sm">
          <span className="capitalize">{dateStr}</span>
          <span className="bg-white/90 px-2 py-0.5 text-black font-bold text-lg">
            {timeStr}
          </span>
        </div>
      </div>

      {/* Invoice info row */}
      <div className="px-3 py-1 flex flex-wrap items-center gap-x-6 gap-y-1 text-sm">
        <div className="flex items-center gap-2">
          <span className="text-[hsl(60,100%,50%)]">N° FACTURE:</span>
          {onInvoiceNumberChange ? (
             <input
              type="text"
              value={invoiceNumber || ''}
              onChange={(e) => onInvoiceNumberChange(e.target.value)}
              className="bg-[hsl(180,100%,40%)] px-2 py-0.5 text-black font-bold w-32 border-none focus:outline-none focus:ring-1 focus:ring-yellow-400"
            />
          ) : (
            <span className="bg-[hsl(180,100%,40%)] px-2 py-0.5 text-black font-bold">
              {displayInvoiceNumber}
            </span>
          )}
        </div>
        <div className="flex items-center gap-2">
          <span>DATE</span>
          <span className="bg-[hsl(180,100%,40%)] px-2 py-0.5 text-black font-bold">
            {format(currentTime, 'dd/MM/yyyy')}
          </span>
        </div>
        <div className="flex items-center gap-2">
          <span>Réf. COMMANDE:</span>
          <input
            type="text"
            value={orderRef}
            onChange={(e) => onOrderRefChange?.(e.target.value)}
            className="bg-[hsl(120,100%,35%)] border-b border-black/50 px-2 py-0.5 w-32 text-black placeholder:text-black/50 focus:outline-none focus:border-[hsl(60,100%,50%)]"
            placeholder=""
          />
        </div>
      </div>

      {/* Customer info row */}
      <div className="px-3 pb-2 flex flex-wrap items-center gap-x-6 gap-y-1 text-sm">
        <div className="flex items-center gap-2">
          <span className="text-[hsl(60,100%,50%)]">CODE CLIENT</span>
          <input
            type="text"
            value={customerCode}
            onChange={(e) => onCustomerChange?.(e.target.value, customerName, customerAddress)}
            className="bg-[hsl(120,100%,35%)] border-b border-black/50 px-2 py-0.5 w-24 text-black focus:outline-none focus:border-[hsl(60,100%,50%)]"
          />
        </div>
        <div className="flex items-center gap-2">
          <span>NOM</span>
          <input
            type="text"
            value={customerName}
            onChange={(e) => onCustomerChange?.(customerCode, e.target.value, customerAddress)}
            className="bg-[hsl(120,100%,35%)] border-b border-black/50 px-2 py-0.5 w-48 text-black focus:outline-none focus:border-[hsl(60,100%,50%)]"
          />
        </div>
      </div>
      <div className="px-3 pb-2 flex items-center gap-2 text-sm">
        <span className="text-[hsl(60,100%,50%)]">ADRESSE</span>
        <input
          type="text"
          value={customerAddress}
          onChange={(e) => onCustomerChange?.(customerCode, customerName, e.target.value)}
          className="bg-[hsl(120,100%,35%)] border-b border-black/50 px-2 py-0.5 flex-1 text-black focus:outline-none focus:border-[hsl(60,100%,50%)]"
        />
      </div>
    </div>
  );
}
