import { useState, useEffect, useCallback } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import { WorkerMenuBar, WorkerModule } from './WorkerMenuBar';
import { WorkerStatusBar } from './WorkerStatusBar';
import { cn } from '@/lib/utils';
import POSPage from '@/pages/worker/POS';
import ProformaList from '@/pages/worker/ProformaList';
import { OfflineAuthService } from '@/services/OfflineAuthService';
import { LocalDatabase } from '@/services/LocalDatabase';

// Module views
import { SalesModule } from '../Modules/SalesModule';
import { FacturationModule } from '../Modules/FacturationModule';
import { FicheProduitsModule } from '../Modules/FicheProduitsModule';
import { FicheCaisseModule } from '../Modules/FicheCaisseModule';
import { StockListingModule } from '../Modules/StockListingModule';
import { PlaceholderModule } from '../Modules/PlaceholderModule';
import { ReceptionAchatsModule } from '../Modules/ReceptionAchatsModule';
import { CommandeAutoModule } from '../Modules/CommandeAutoModule';
import { CommandeManuelleModule } from '../Modules/CommandeManuelleModule';
import { ReglementsFournisseursModule } from '../Modules/ReglementsFournisseursModule';
// Fichiers (Master Data) modules
import { FichiersProduitsModule } from '../Modules/FichiersProduitsModule';
import { FichiersClientsModule } from '../Modules/FichiersClientsModule';
import { FichiersFournisseursModule } from '../Modules/FichiersFournisseursModule';
import { FichiersFamillesModule } from '../Modules/FichiersFamillesModule';
import { FichiersServicesClientsModule } from '../Modules/FichiersServicesClientsModule';
// New modules
import { EditionModule } from '../Modules/EditionModule';
import { GestionModule } from '../Modules/GestionModule';
import { StockModule } from '../Modules/StockModule';
import { SettingsModule } from '../Modules/SettingsModule';
import { ReglementsBonsModule } from '../Modules/ReglementsBonsModule';

interface WorkerLayoutProps {
  className?: string;
}

const moduleLabels: Record<WorkerModule, string> = {
  'vente-detail': 'Vente au Détail',
  'facturation-detail': 'Facturation au Détail',
  'facturation-gros': 'Facturation en Gros',
  'proforma': 'Facture Proforma',
  'fermeture-caisse': 'Fermeture de la Caisse',
  'reglements-bons': 'Règlements des Bons',
  'reception-achats': 'Réception/Achats',
  'commande-auto': 'Commande Automatique',
  'commande-manuelle': 'Commande Manuelle',
  'reglement-fournisseurs': 'Règlements Fournisseurs',
  'produits': 'Fiche Produit',
  'clients': 'Fichier Clients',
  'services-clients': 'Services Clients',
  'fournisseurs': 'Fichier Fournisseurs',
  'familles': 'Familles Produits',
  'situation-client': 'Situation Client',
  'suivi-ventes-jour': 'Ventes du Jour',
  'suivi-ventes-produit': 'Ventes par Produit',
  'suivi-ventes-factures': 'Liste des Factures',
  'situation-fournisseur': 'Situation Fournisseur',
  'suivi-achats-famille': 'Achats par Famille',
  'suivi-achats-jour': 'Achats du Jour',
  'suivi-achats-periode': 'Achats par Période',
  'consultation-caisse': 'Consultation Caisse',
  'journal-caisse': 'Journal de Caisse',
  'tableau-bord': 'Tableau de Bord',
  'statistiques': 'Statistiques',
  'sorties-pertes': 'Sortie des Pertes',
  'fiche-stock': 'Fiche Stock Produit',
  'mouvements-stock': 'Mouvements du Stock',
  'listing-stock': 'Listing du Stock',
  'regularisation-stock': 'Régularisation Stock',
  'valorisation-stock': 'Valorisation Stock',
  'inventaire-stock': 'Inventaire Stock',
  'preferences': 'Préférences',
  'programmation-touches': 'Programmation Touches',
  'mots-de-passe': 'Mots de Passe',
  'synchronisation': 'Synchronisation',
};

export function WorkerLayout({ className }: WorkerLayoutProps) {
  const { user, signOut } = useAuth();
  const [activeModule, setActiveModule] = useState<WorkerModule>('facturation-detail');
  const [storeId, setStoreId] = useState<string>('');
  const [storeName, setStoreName] = useState<string>('');

  // Fetch worker's store - works offline
  useEffect(() => {
    const fetchStore = async () => {
      if (!user) return;

      let foundStoreId = '';
      let foundStoreName = '';

      // Try online first
      if (navigator.onLine) {
        try {
          // First check user_roles for store assignment
          const { data: roleData } = await supabase
            .from('user_roles')
            .select('store_id, role')
            .eq('user_id', user.id)
            .in('role', ['worker', 'master']);

          const roleWithStore = roleData?.find(r => r.store_id);
          
          if (roleWithStore?.store_id) {
            foundStoreId = roleWithStore.store_id;
          } else {
            // If master has no store_id in user_roles, check owned stores
            const isMaster = roleData?.some(r => r.role === 'master');
            if (isMaster) {
              const { data: ownedStores } = await supabase
                .from('stores')
                .select('id, name')
                .eq('owner_id', user.id)
                .limit(1)
                .maybeSingle();

              if (ownedStores) {
                foundStoreId = ownedStores.id;
                foundStoreName = ownedStores.name;
              }
            }
          }

          // Fetch store name if we have an ID but no name yet
          if (foundStoreId && !foundStoreName) {
            const { data: storeData } = await supabase
              .from('stores')
              .select('name')
              .eq('id', foundStoreId)
              .maybeSingle();

            if (storeData) {
              foundStoreName = storeData.name;
            }
          }

          if (foundStoreId) {
            setStoreId(foundStoreId);
            setStoreName(foundStoreName);
            // Cache for offline
            localStorage.setItem('worker_store_id', foundStoreId);
            localStorage.setItem('worker_store_name', foundStoreName);
          }
        } catch (error) {
          console.log('Failed to fetch store online, using cache');
        }
      }

      // Fallback to cached values
      if (!foundStoreId) {
        const cachedStoreId = localStorage.getItem('worker_store_id');
        const cachedStoreName = localStorage.getItem('worker_store_name');
        if (cachedStoreId) {
          setStoreId(cachedStoreId);
          setStoreName(cachedStoreName || '');
        }
      }

      // Try local database for roles as last resort
      if (!foundStoreId && !localStorage.getItem('worker_store_id')) {
        try {
          const localRoles = await LocalDatabase.getRolesByUserId(user.id);
          const workerRole = localRoles.find(r => r.role === 'worker' || r.role === 'master');
          if (workerRole?.store_id) {
            setStoreId(workerRole.store_id);
          }
        } catch (error) {
          console.log('Failed to get roles from local database');
        }
      }
    };
    fetchStore();
  }, [user]);

  // Global keyboard shortcuts for modules
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'F1') {
        e.preventDefault();
        setActiveModule('vente-detail');
      } else if (e.key === 'F2' && !e.ctrlKey && !e.metaKey) {
        e.preventDefault();
        setActiveModule('facturation-detail');
      } else if (e.key === 'F3') {
        e.preventDefault();
        setActiveModule('facturation-gros');
      } else if (e.key === 'F12') {
        e.preventDefault();
        setActiveModule('fermeture-caisse');
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  const renderModule = useCallback(() => {
    switch (activeModule) {
      // Use new SalesModule for all sales flows
      case 'vente-detail':
      case 'facturation-detail':
      case 'facturation-gros':
      case 'proforma':
        return <SalesModule storeId={storeId} mode={activeModule} />;

      case 'produits':
        return <FichiersProduitsModule storeId={storeId} />;

      case 'clients':
        return <FichiersClientsModule storeId={storeId} />;

      case 'services-clients':
        return <FichiersServicesClientsModule storeId={storeId} />;

      case 'fournisseurs':
        return <FichiersFournisseursModule storeId={storeId} />;

      case 'familles':
        return <FichiersFamillesModule storeId={storeId} />;

      case 'fermeture-caisse':
      case 'consultation-caisse':
        return <FicheCaisseModule storeId={storeId} />;

      case 'listing-stock':
        return <StockListingModule storeId={storeId} />;

      case 'fiche-stock':
      case 'mouvements-stock':
      case 'regularisation-stock':
      case 'valorisation-stock':
      case 'inventaire-stock':
        return <StockModule storeId={storeId} mode={activeModule} />;

      case 'reception-achats':
        return <ReceptionAchatsModule storeId={storeId} />;

      case 'commande-auto':
        return <CommandeAutoModule storeId={storeId} />;

      case 'commande-manuelle':
        return <CommandeManuelleModule storeId={storeId} />;

      case 'reglement-fournisseurs':
        return <ReglementsFournisseursModule storeId={storeId} />;

      case 'reglements-bons':
        return <ReglementsBonsModule storeId={storeId} />;

      // Edition (Reporting) modules
      case 'situation-client':
      case 'suivi-ventes-jour':
      case 'suivi-ventes-produit':
      case 'suivi-ventes-factures':
      case 'situation-fournisseur':
      case 'suivi-achats-famille':
      case 'suivi-achats-jour':
      case 'suivi-achats-periode':
        return <EditionModule storeId={storeId} mode={activeModule} />;

      // Gestion (Management) modules
      case 'consultation-caisse':
      case 'journal-caisse':
      case 'tableau-bord':
      case 'statistiques':
      case 'sorties-pertes':
        return <GestionModule storeId={storeId} mode={activeModule} />;

      // Programme (Settings) modules
      case 'preferences':
      case 'programmation-touches':
      case 'mots-de-passe':
      case 'synchronisation':
        return <SettingsModule storeId={storeId} mode={activeModule} />;

      default:
        return (
          <PlaceholderModule
            title={moduleLabels[activeModule]}
            description="Ce module sera bientôt disponible."
          />
        );
    }
  }, [activeModule, storeId]);

  const handleLogout = async () => {
    await signOut();
  };

  return (
    <div className={cn('h-screen flex flex-col bg-background', className)}>
      {/* Top Menu Bar - Sanifere Style */}
      <header className="h-10 bg-[hsl(160,70%,35%)] flex items-center shrink-0">
        <WorkerMenuBar
          activeModule={activeModule}
          onModuleChange={setActiveModule}
        />
      </header>

      {/* Main Content Area */}
      <main className="flex-1 overflow-hidden bg-[hsl(50,90%,55%)] dark:bg-background">
        <div className="h-full p-4">
          <div className="h-full glass-card overflow-hidden flex flex-col">
            {/* Module Title Bar */}
            <div className="h-8 bg-primary/10 border-b border-primary/30 flex items-center px-4">
              <span className="text-sm font-medium text-primary">
                {moduleLabels[activeModule]}
              </span>
            </div>

            {/* Module Content */}
            <div className="flex-1 overflow-hidden">
              {renderModule()}
            </div>
          </div>
        </div>
      </main>

      {/* Bottom Status Bar */}
      <WorkerStatusBar
        storeName={storeName}
        userEmail={user?.email || ''}
        activeModule={activeModule}
        onLogout={handleLogout}
      />
    </div>
  );
}
