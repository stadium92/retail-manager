import { useState } from 'react';
import { cn } from '@/lib/utils';
import { ChevronRight } from 'lucide-react';
import {
  Menubar,
  MenubarContent,
  MenubarItem,
  MenubarMenu,
  MenubarSeparator,
  MenubarSub,
  MenubarSubContent,
  MenubarSubTrigger,
  MenubarTrigger,
} from '@/components/ui/menubar';

export type WorkerModule =
  | 'vente-detail'
  | 'facturation-detail'
  | 'facturation-gros'
  | 'proforma'
  | 'fermeture-caisse'
  | 'reglements-bons'
  | 'reception-achats'
  | 'commande-auto'
  | 'commande-manuelle'
  | 'reglement-fournisseurs'
  | 'produits'
  | 'clients'
  | 'services-clients'
  | 'fournisseurs'
  | 'familles'
  | 'situation-client'
  | 'suivi-ventes-jour'
  | 'suivi-ventes-produit'
  | 'suivi-ventes-factures'
  | 'situation-fournisseur'
  | 'suivi-achats-famille'
  | 'suivi-achats-jour'
  | 'suivi-achats-periode'
  | 'consultation-caisse'
  | 'journal-caisse'
  | 'tableau-bord'
  | 'statistiques'
  | 'sorties-pertes'
  | 'fiche-stock'
  | 'mouvements-stock'
  | 'listing-stock'
  | 'regularisation-stock'
  | 'valorisation-stock'
  | 'inventaire-stock'
  | 'preferences'
  | 'programmation-touches'
  | 'mots-de-passe'
  | 'synchronisation';

interface WorkerMenuBarProps {
  activeModule: WorkerModule;
  onModuleChange: (module: WorkerModule) => void;
  className?: string;
}

interface MenuItem {
  label: string;
  module?: WorkerModule;
  shortcut?: string;
  separator?: boolean;
  submenu?: MenuItem[];
}

interface MenuSection {
  trigger: string;
  highlight?: boolean;
  items: MenuItem[];
}

const menuStructure: MenuSection[] = [
  {
    trigger: 'Ventes',
    highlight: true,
    items: [
      { label: 'Vente au DÉTAIL', module: 'vente-detail', shortcut: 'F1' },
      { label: 'Facturation au DÉTAIL', module: 'facturation-detail', shortcut: 'F2' },
      { label: 'Facturation en GROS', module: 'facturation-gros', shortcut: 'F3' },
      { label: 'FACTURE PROFORMA', module: 'proforma' },
      { separator: true, label: '' },
      { label: 'FERMETURE DE LA CAISSE', module: 'fermeture-caisse', shortcut: 'F12' },
      { label: 'Règlements des BONS', module: 'reglements-bons' },
    ],
  },
  {
    trigger: 'Achats',
    items: [
      { label: 'Réception/Achats', module: 'reception-achats' },
      { label: 'Commande AUTOMATIQUE', module: 'commande-auto' },
      { label: 'Commande Manuelle', module: 'commande-manuelle' },
      { separator: true, label: '' },
      { label: 'Règlements FOURNISSEURS', module: 'reglement-fournisseurs' },
    ],
  },
  {
    trigger: 'Fichiers',
    items: [
      { label: 'Produits/Articles', module: 'produits' },
      { label: 'Clients', module: 'clients' },
      { label: 'Services-CLIENTS', module: 'services-clients' },
      { label: 'Fournisseurs', module: 'fournisseurs' },
      { label: 'Familles-PRODUITS', module: 'familles' },
    ],
  },
  {
    trigger: 'Edition',
    items: [
      {
        label: 'Situation CLIENT',
        submenu: [
          { label: 'Relevé de compte', module: 'situation-client' },
        ],
      },
      {
        label: 'Suivi des VENTES',
        submenu: [
          { label: 'Ventes du jour', module: 'suivi-ventes-jour' },
          { label: 'Ventes par produit', module: 'suivi-ventes-produit' },
          { label: 'Liste des factures', module: 'suivi-ventes-factures' },
        ],
      },
      {
        label: 'Situation FOURNISSEUR',
        submenu: [
          { label: 'Relevé fournisseur', module: 'situation-fournisseur' },
        ],
      },
      {
        label: 'Suivi des ACHATS',
        submenu: [
          { label: 'Achats Familles/produits', module: 'suivi-achats-famille' },
          { label: 'Achats journée/Fournisseur', module: 'suivi-achats-jour' },
          { label: 'Achats période/Fournisseur', module: 'suivi-achats-periode' },
        ],
      },
    ],
  },
  {
    trigger: 'Gestion',
    items: [
      { label: 'Consultation CAISSE', module: 'consultation-caisse' },
      { label: 'Journal CAISSE', module: 'journal-caisse' },
      { separator: true, label: '' },
      { label: 'Tableau de bord', module: 'tableau-bord' },
      { label: 'Statistiques', module: 'statistiques' },
      { separator: true, label: '' },
      { label: 'SORTIE des PERTES', module: 'sorties-pertes' },
    ],
  },
  {
    trigger: 'Stock',
    items: [
      { label: 'Fiche de stock produit', module: 'fiche-stock' },
      { label: 'Mouvements du Stock', module: 'mouvements-stock' },
      { separator: true, label: '' },
      { label: 'Listing du STOCK', module: 'listing-stock' },
      { label: 'RÉGULARISATION du STOCK', module: 'regularisation-stock' },
      { label: 'Valorisation du stock', module: 'valorisation-stock' },
      { separator: true, label: '' },
      { label: 'Inventaire du STOCK', module: 'inventaire-stock' },
    ],
  },
  {
    trigger: 'Programme',
    items: [
      { label: 'Préférences', module: 'preferences' },
      { label: 'Programmation TOUCHE', module: 'programmation-touches' },
      { separator: true, label: '' },
      { label: 'Mots de passe', module: 'mots-de-passe' },
    ],
  },
];

export function WorkerMenuBar({ activeModule, onModuleChange, className }: WorkerMenuBarProps) {
  const isModuleInSection = (section: MenuSection) => {
    return section.items.some((item) => {
      if (item.module === activeModule) return true;
      if (item.submenu) {
        return item.submenu.some((sub) => sub.module === activeModule);
      }
      return false;
    });
  };

  const renderMenuItem = (item: MenuItem, key: number) => {
    if (item.separator) {
      return <MenubarSeparator key={key} />;
    }

    if (item.submenu) {
      return (
        <MenubarSub key={key}>
          <MenubarSubTrigger className="flex items-center justify-between">
            {item.label}
            <ChevronRight className="h-4 w-4 ml-2" />
          </MenubarSubTrigger>
          <MenubarSubContent className="bg-popover border-slate-200 shadow-md min-w-[180px] z-[100]">
            {item.submenu.map((subItem, subKey) => (
              <MenubarItem
                key={subKey}
                onClick={() => subItem.module && onModuleChange(subItem.module)}
                className={cn(
                  'cursor-pointer transition-colors',
                  subItem.module === activeModule && 'bg-primary/20 text-primary'
                )}
              >
                {subItem.label}
                {subItem.shortcut && (
                  <span className="ml-auto text-xs text-muted-foreground">{subItem.shortcut}</span>
                )}
              </MenubarItem>
            ))}
          </MenubarSubContent>
        </MenubarSub>
      );
    }

    return (
      <MenubarItem
        key={key}
        onClick={() => item.module && onModuleChange(item.module)}
        className={cn(
          'cursor-pointer transition-colors',
          item.module === activeModule && 'bg-primary/20 text-primary'
        )}
      >
        <span>{item.label}</span>
        {item.shortcut && (
          <span className="ml-auto text-xs text-muted-foreground">{item.shortcut}</span>
        )}
      </MenubarItem>
    );
  };

  return (
    <Menubar className={cn('h-10 gap-0 p-0 border-none bg-transparent rounded-none', className)}>
      {menuStructure.map((section, index) => {
        const isActive = isModuleInSection(section);

        return (
          <MenubarMenu key={index}>
            <MenubarTrigger
              className={cn(
                'px-4 py-2 text-sm font-medium rounded-none transition-all cursor-pointer',
                'data-[state=open]:bg-primary data-[state=open]:text-primary-foreground',
                section.highlight && !isActive && 'bg-danger text-danger-foreground',
                isActive && 'bg-primary text-primary-foreground',
                !section.highlight && !isActive && 'hover:bg-muted'
              )}
            >
              {section.trigger}
            </MenubarTrigger>
            <MenubarContent
              className="glass-card border-primary/20 min-w-[220px] animate-spring-in"
              align="start"
              sideOffset={0}
            >
              {section.items.map((item, itemIndex) => renderMenuItem(item, itemIndex))}
            </MenubarContent>
          </MenubarMenu>
        );
      })}
    </Menubar>
  );
}
