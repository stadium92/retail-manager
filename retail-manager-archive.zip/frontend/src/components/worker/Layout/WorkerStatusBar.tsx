import { useState, useEffect } from 'react';
import { LogOut, Wifi, WifiOff, HardDrive, CloudOff, RefreshCw } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';
import { WorkerModule } from './WorkerMenuBar';
import { OfflineAuthService } from '@/services/OfflineAuthService';
import { LocalDatabase } from '@/services/LocalDatabase';

interface WorkerStatusBarProps {
  storeName: string;
  userEmail: string;
  activeModule: WorkerModule;
  onLogout: () => void;
}

export function WorkerStatusBar({ storeName, userEmail, activeModule, onLogout }: WorkerStatusBarProps) {
  const [currentTime, setCurrentTime] = useState(new Date());
  const [isOnline, setIsOnline] = useState(navigator.onLine);

  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);
    
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    
    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  const formatDate = (date: Date) => {
    return date.toLocaleDateString('fr-FR', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
    });
  };

  const formatTime = (date: Date) => {
    return date.toLocaleTimeString('fr-FR', {
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
    });
  };

  const shortcutHints: Record<string, string> = {
    'facturation-detail': 'F2/PGDN -SAUVE   Esc/Echap -Annule   +/- Quantité',
    'facturation-gros': 'F2/PGDN -SAUVE   Esc/Echap -Annule   +/- Quantité',
    'vente-detail': 'Entrée -Ajouter   F4 -Payer   Esc -Annuler',
    'produits': 'F2/PGDN -SAUVE   Esc/Echap -Annule',
    'fermeture-caisse': 'F2/PGDN -SAUVE   Esc/Echap -Annule',
  };

  return (
    <footer className="h-8 bg-[hsl(180,80%,40%)] dark:bg-card/80 border-t border-primary/30 flex items-center px-2 text-xs shrink-0">
      {/* Store Name */}
      <div className="flex items-center gap-2 min-w-[200px]">
        <HardDrive className="h-3.5 w-3.5 text-primary-foreground/70 dark:text-primary" />
        <span className="font-medium text-primary-foreground dark:text-foreground truncate">
          {storeName || 'DEPOT DE BOISSONS'}
        </span>
      </div>

      {/* Keyboard Shortcuts */}
      <div className="flex-1 text-center">
        <span className="font-mono text-primary-foreground/90 dark:text-muted-foreground">
          {shortcutHints[activeModule] || 'Utilisez le menu pour naviguer'}
        </span>
      </div>

      {/* Right Section */}
      <div className="flex items-center gap-3">
        {/* Connection Status */}
        <div className={cn(
          'flex items-center gap-1 px-2 py-0.5 rounded',
          isOnline 
            ? 'bg-success/20 text-success dark:text-success' 
            : 'bg-danger/20 text-danger dark:text-danger'
        )}>
          {isOnline ? <Wifi className="h-3 w-3" /> : <WifiOff className="h-3 w-3" />}
          <span>{isOnline ? 'En ligne' : 'Hors ligne'}</span>
        </div>

        {/* User */}
        <span className="text-primary-foreground/80 dark:text-muted-foreground truncate max-w-[150px]">
          {userEmail}
        </span>

        {/* Date/Time */}
        <div className="flex items-center gap-2 font-mono text-primary-foreground dark:text-foreground">
          <span>{formatDate(currentTime)}</span>
          <span className="text-primary-foreground/60 dark:text-muted-foreground">•</span>
          <span>{formatTime(currentTime)}</span>
        </div>

        {/* Logout */}
        <Button
          variant="ghost"
          size="sm"
          onClick={onLogout}
          className="h-6 px-2 text-primary-foreground hover:bg-primary-foreground/10 dark:text-foreground dark:hover:bg-muted"
        >
          <LogOut className="h-3.5 w-3.5" />
        </Button>
      </div>
    </footer>
  );
}
