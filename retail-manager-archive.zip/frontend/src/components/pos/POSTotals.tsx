import { usePOSStore } from '@/stores/usePOSStore';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Separator } from '@/components/ui/separator';
import { 
  CreditCard, 
  Wallet, 
  Receipt, 
  Trash2, 
  ScanBarcode,
  User
} from 'lucide-react';
import { cn } from '@/lib/utils';

interface POSTotalsProps {
  onPayment: () => void;
  onScan: () => void;
  onClear: () => void;
}

export function POSTotals({ onPayment, onScan, onClear }: POSTotalsProps) {
  const {
    cart,
    subtotal,
    totalDiscount,
    grandTotal,
    customerName,
    customerPhone,
    setCustomer,
  } = usePOSStore();

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('fr-FR', {
      style: 'currency',
      currency: 'XAF',
      minimumFractionDigits: 0,
    }).format(amount);
  };

  const itemCount = cart.reduce((sum, item) => sum + item.quantity, 0);

  return (
    <div className="glass-card p-4 space-y-4">
      {/* Customer Info */}
      <div className="space-y-3">
        <div className="flex items-center gap-2 text-sm font-medium text-muted-foreground">
          <User className="h-4 w-4" />
          <span>Client</span>
        </div>
        <div className="grid grid-cols-2 gap-2">
          <div>
            <Label htmlFor="customer-name" className="text-xs text-muted-foreground">Nom</Label>
            <Input
              id="customer-name"
              value={customerName}
              onChange={(e) => setCustomer(undefined, e.target.value, customerPhone)}
              placeholder="Nom du client"
              className="h-8 text-sm bg-muted/50 border-border/50"
            />
          </div>
          <div>
            <Label htmlFor="customer-phone" className="text-xs text-muted-foreground">Téléphone</Label>
            <Input
              id="customer-phone"
              value={customerPhone}
              onChange={(e) => setCustomer(undefined, customerName, e.target.value)}
              placeholder="Téléphone"
              className="h-8 text-sm bg-muted/50 border-border/50"
            />
          </div>
        </div>
      </div>

      <Separator className="bg-border/50" />

      {/* Totals */}
      <div className="space-y-2">
        <div className="flex items-center justify-between text-sm">
          <span className="text-muted-foreground">Articles ({itemCount})</span>
          <span>{formatCurrency(subtotal)}</span>
        </div>
        
        {totalDiscount > 0 && (
          <div className="flex items-center justify-between text-sm text-success">
            <span>Remise totale</span>
            <span>-{formatCurrency(totalDiscount)}</span>
          </div>
        )}

        <Separator className="bg-border/50" />
        
        <div className="flex items-center justify-between pt-1">
          <span className="text-lg font-semibold">Total</span>
          <span className="text-2xl font-bold text-primary text-glow-primary">
            {formatCurrency(grandTotal)}
          </span>
        </div>
      </div>

      <Separator className="bg-border/50" />

      {/* Action Buttons */}
      <div className="space-y-2">
        {/* Primary Actions */}
        <div className="grid grid-cols-2 gap-2">
          <Button
            variant="outline"
            onClick={onScan}
            className="h-12 glass-card-hover"
          >
            <ScanBarcode className="h-5 w-5 mr-2" />
            Scanner
            <kbd className="kbd-shortcut ml-auto">F2</kbd>
          </Button>
          
          <Button
            onClick={onPayment}
            disabled={cart.length === 0}
            className="h-12 btn-neon"
          >
            <CreditCard className="h-5 w-5 mr-2" />
            Payer
            <kbd className="kbd-shortcut ml-auto bg-primary-foreground/20 text-primary-foreground border-primary-foreground/30">F4</kbd>
          </Button>
        </div>

        {/* Secondary Actions */}
        <div className="flex gap-2">
          <Button
            variant="ghost"
            size="sm"
            onClick={onClear}
            disabled={cart.length === 0}
            className="flex-1 text-muted-foreground hover:text-danger hover:bg-danger/10"
          >
            <Trash2 className="h-4 w-4 mr-2" />
            Vider
          </Button>
          <Button
            variant="ghost"
            size="sm"
            disabled={cart.length === 0}
            className="flex-1 text-muted-foreground hover:text-foreground"
          >
            <Receipt className="h-4 w-4 mr-2" />
            Proforma
          </Button>
        </div>
      </div>

      {/* Keyboard Hints */}
      <div className="pt-2 border-t border-border/30">
        <p className="text-[10px] text-muted-foreground text-center">
          <kbd className="kbd-shortcut">↑↓</kbd> Navigation • 
          <kbd className="kbd-shortcut ml-1">+/-</kbd> Quantité • 
          <kbd className="kbd-shortcut ml-1">Del</kbd> Supprimer
        </p>
      </div>
    </div>
  );
}
