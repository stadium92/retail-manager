import { useEffect, useRef } from 'react';

interface UseBarcodeScannerProps {
    onScan: (barcode: string) => void;
    onError?: (error: Error) => void;
    enabled?: boolean;
}

export function useBarcodeScanner({ onScan, onError, enabled = true }: UseBarcodeScannerProps) {
    const buffer = useRef<string>('');
    const lastKeyTime = useRef<number>(0);

    // Config for HID scanners
    const SCANNER_TIMEOUT_MS = 50; // Max time between keystrokes for it to be considered a scan
    const MIN_BARCODE_LENGTH = 3;

    useEffect(() => {
        if (!enabled) return;

        const handleKeyDown = (e: KeyboardEvent) => {
            const now = Date.now();
            const isScannerInput = (now - lastKeyTime.current) <= SCANNER_TIMEOUT_MS;

            // If manually typing (slow), reset buffer unless it's the very start of a burst
            if (!isScannerInput && buffer.current.length > 0) {
                // Reset if too slow (likely manual typing), but keep current char if it starts a new burst
                // However, for robust HID handling, we mostly rely on the burst speed.
                buffer.current = '';
            }

            lastKeyTime.current = now;

            if (e.key === 'Enter') {
                if (buffer.current.length >= MIN_BARCODE_LENGTH) {
                    // It's a valid barcode scan
                    onScan(buffer.current);
                    buffer.current = '';
                    e.preventDefault(); // Prevent submitting forms
                    e.stopPropagation();
                } else {
                    // Just an enter key press, likely manual interaction
                    buffer.current = '';
                }
                return;
            }

            // Ignore non-character keys (Shift, Ctrl, etc.)
            if (e.key.length !== 1) return;

            buffer.current += e.key;
        };

        window.addEventListener('keydown', handleKeyDown);
        return () => window.removeEventListener('keydown', handleKeyDown);
    }, [enabled, onScan, onError]);
}
