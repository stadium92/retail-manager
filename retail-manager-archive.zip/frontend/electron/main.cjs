const { app, BrowserWindow } = require('electron');
const { spawn } = require('child_process');
const path = require('path');
const isDev = require('electron-is-dev');

let backendProcess = null;

function startLocalBridge() {
  if (backendProcess || process.env.LOCALBRIDGE_AUTOSTART === '0') {
    return;
  }

  const userDataDir = app.getPath('userData');
  const dataDir = path.join(userDataDir, 'local-bridge', 'data');
  const port = process.env.LOCALBRIDGE_PORT || '8787';

  if (app.isPackaged) {
    const backendRoot = path.join(process.resourcesPath, 'local-bridge');
    const backendEntry = path.join(backendRoot, 'dist', 'index.js');

    backendProcess = spawn(process.execPath, [backendEntry], {
      cwd: backendRoot,
      env: {
        ...process.env,
        ELECTRON_RUN_AS_NODE: '1',
        PORT: port,
        DATA_DIR: dataDir,
        JWT_SECRET: process.env.JWT_SECRET || 'dev-secret',
      },
      stdio: 'pipe',
    });
  } else {
    const backendRoot = path.resolve(__dirname, '..', '..', 'backend', 'local-bridge');
    backendProcess = spawn('npm', ['run', 'dev'], {
      cwd: backendRoot,
      env: {
        ...process.env,
        PORT: port,
        DATA_DIR: dataDir,
        JWT_SECRET: process.env.JWT_SECRET || 'dev-secret',
      },
      stdio: 'pipe',
      shell: true,
    });
  }

  backendProcess.on('exit', (code) => {
    backendProcess = null;
    if (code && code !== 0) {
      console.warn(`LocalBridge exited with code ${code}`);
    }
  });
}

function stopLocalBridge() {
  if (!backendProcess) return;
  try {
    backendProcess.kill();
  } catch (error) {
    console.warn('Failed to stop LocalBridge:', error);
  }
  backendProcess = null;
}

function createWindow() {
  const win = new BrowserWindow({
    width: 1280,
    height: 720,
    minWidth: 1024,
    minHeight: 600,
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
      enableRemoteModule: false,
      webSecurity: true,
    },
    // Optional: Add icon
    // icon: path.join(__dirname, '../public/icon.png'),
    show: false, // Don't show until ready
  });

  // Show window when ready
  win.once('ready-to-show', () => {
    win.show();
  });

  // Load the app
  const startUrl = isDev
    ? 'https://localhost:8080' // Your Vite dev server
    : `file://${path.join(__dirname, '../dist/index.html')}`;
  
  win.loadURL(startUrl);

  // Open DevTools in development
  if (isDev) {
    win.webContents.openDevTools();
  }

  // Handle external links
  win.webContents.setWindowOpenHandler(({ url }) => {
    require('electron').shell.openExternal(url);
    return { action: 'deny' };
  });
}

app.whenReady().then(() => {
  startLocalBridge();
  createWindow();

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) {
      createWindow();
    }
  });
});

app.on('window-all-closed', () => {
  stopLocalBridge();
  if (process.platform !== 'darwin') {
    app.quit();
  }
});

app.on('before-quit', () => {
  stopLocalBridge();
});

// Security: Prevent new window creation
app.on('web-contents-created', (event, contents) => {
  contents.on('new-window', (navigationEvent, navigationURL) => {
    navigationEvent.preventDefault();
    require('electron').shell.openExternal(navigationURL);
  });
});
